# gameBiz Design System

*The analyst's archive. A design system for an evidence-based gamification practice.*

gameBiz studies how the world's best apps and games actually build their mechanics, maintains a reference library of those implementations, and helps product teams apply what fits their own app. This design system dresses that work. It is built to look like the output of someone who studies things carefully: part field guide, part intelligence report, part well-kept research library.

The organizing idea governs every decision here. **The category's default look is playful. Ours is serious, with the play living in the subject matter.** Rigor in the substance, warmth in the telling. The test for any decision: *would a serious analyst's archive do this?* If not, cut it.

---

## Sources

This system was built from the brand documents supplied by GameBiz Consulting (June 2026). Keep them; they are the source of truth and outrank anything inferred here.

- `uploads/design-system-brief.md` — strategy, organizing idea, core principles, confirmed tokens, component list, forbidden list.
- `uploads/brand-voice-guide.md` — how we sound everywhere.
- `uploads/brandscript.md` — the story (client as hero, gameBiz as guide).
- `uploads/page-requirements-guide.md` — what each page must contain, in order. Used when UI kits are built.
- `uploads/gamebiz-logo.svg` — the original wordmark, copied into `assets/logo/`.

No codebase or Figma file was provided. The product surfaces (Homepage, Mechanics, Apps, Systems, Cheatsheets, Glossary, Reports, Work With Us, Subscribe) are described in the page-requirements guide but were not delivered as code. **UI kits are intentionally not built yet** — per the brief, the foundations and component library ship first for approval, then the product screens are recreated.

---

## Content fundamentals

The voice is the warmth in this brand. The visuals stay calm so the writing and the evidence can carry the feeling. Write like a knowledgeable friend who studies this for a living and enjoys showing you what they found.

**Person and address.** Write to one person as "you." Use "we" for gameBiz's work and opinions, and own recommendations plainly: "we suggest," not "it could perhaps be considered."

**Casing.** Sentence case everywhere: headlines, buttons, labels, nav. No Title Case, no ALL CAPS in prose. (The only uppercase is the small tracked specimen label, a typographic device, never a sentence.)

**Sentences.** Short, one idea each. Active voice. Front-load the point: the first sentence carries the meaning. Example: *"Duolingo pairs streaks with loss aversion,"* not *"streaks are paired with loss aversion."*

**Punctuation.** No em dashes and no double dashes, ever. Use commas, periods, and colons. This is a hard rule from the voice guide and it shows up in the type: the analyst's pen is the only "dash" in the system.

**Specifics over generalities.** Point at real things: this screen, this loop, this reward timing. Captions are real sentences that add something the image does not say on its own, never labels like "Figure 1."

**Numbers carry sources.** Never present a figure without saying where it came from. The `StatBlock` component enforces this: a `source` line is part of the contract. *"0.62 DAU/MAU, source: company filings, Q1 2026."*

**Respect.** We never talk down about anyone: not competitors, not teams that shipped a leaderboard that flopped. The only critique target is the shortcut itself, *pointsification*, and even there we explain why it is tempting before why it falls short.

**No corporate filler, no hype.** Banned: leverage, synergy, holistic, seamless, robust, empower, revolutionary, game-changing, unlock your potential. And "fun" is never the selling point. Engagement, retention, and conversion are.

**Interface copy.** Plain verbs. Buttons say exactly what happens ("Book a discovery call," "Explore the library"). Errors explain what went wrong and how to fix it, without apology. Locked content invites: *"This breakdown is part of the full library,"* never "Access denied."

**Emoji: never.** Not in product, not in marketing, not in decks. They read as playful and undercut the archive.

---

## Visual foundations

**The paper.** Everything sits on `#f5f4f0`. It reads as paper, not pixels. It is the single most important visual decision: a warm, low-glare ground that makes screenshots and diagrams feel like specimens laid on a desk. Cards are white sheets (`#ffffff`) on that paper. There is no dark mode and no gamer-dark surface anywhere.

**Color discipline.** The evidence is the decoration. Color, energy, and play come from the app screenshots and game material we present; the frame around them stays neutral so the material pops. The palette is therefore mostly ink on paper:
- **Ink scale** — warm near-blacks (`--ink-900: #1a1a17`) down to faint greys (`--ink-100`). Carries all text and most structure.
- **Red, the analyst's pen** (`--accent: #f03636`). It behaves like a marker in the margins: annotation pins, the one underline that says "look here," connection lines in system maps, the single most important action on a page. It appears sparingly and always means *this is the point*. Never a large surface, background, or decoration. The logo mark uses a slightly warmer red (`#e83d36`); the accent token is the canonical UI red.
- **Category colors** — Retention pine (`#2f6b57`), Monetization ochre (`#8a6322`), Social slate-indigo (`#3f5586`). Low chroma, deep, archival, like museum classification labels. They stay quiet next to the red and never compete with it. Each has a soft tint for chip grounds.

**Type.** Two families, three jobs:
- **Sora** (display & headings) carries the humanity. Sentence case, tight tracking (`-0.012em` to `-0.02em`), weights 600–700, 800 only for the largest display.
- **DM Sans** (body) carries the rigor and the legibility. 16px base, 1.6 line height, up to 1.7 for long-form reading.
- **DM Sans** also fills the utility role (data, specimen labels, captions-as-metadata, diagram labels). Uppercased and tracked at `0.09em`, the small label is the system's signature small-type device. No separate monospace face.

The full scale lives in `tokens/typography.css` with explicit sizes and composed `--type-*` roles. Minimum body type is 14px; nothing functional drops below 12px.

**Spacing & layout.** 4px base grid (`--space-1` … `--space-10`). Content maxes at **1100px** with a **24px** gutter; long-form reading narrows to 720px; the filter rail is 248px. Whitespace is generous, but this is a reference tool: density with legibility beats airy minimalism. Optimize for the return visit, not the first impression.

**Corners & cards.** Restrained radii: 3px for tags and inputs, 6px for cards and buttons, 10px for modals. A card is a white sheet defined by a **hairline border** (`--border-subtle`), not by a glossy lift. An archive is flat.

**Elevation.** Prefer the rule over the shadow. Cards use a hairline and at most `--shadow-xs`. Real shadows appear only when something genuinely floats: menus (`--shadow-md`), the screenshot viewer and modals (`--shadow-modal`). Shadows are warm-ink based, never blue-grey. No glow, no neon.

**Borders & rules.** Hairlines structure the archive. The 2px `--rule-accent` (red) is the deliberate underline that says "look here," used as sparingly as the pen.

**Backgrounds & texture.** The paper is flat color. The only textures are functional: a faint dotted ground inside system maps (a 22px radial-dot grid at low opacity, reading as graph paper), and the dashed ink band on locked content that reads as a closed archive drawer. No gradients on surfaces. No neon, no glassmorphism, no decorative blur. Transparency is used only for the red connection line at rest and focus washes.

**Imagery.** Screenshots are specimens: framed consistently, clearly labeled with a tracked sans caption, presented in full color (the app supplies the color; the frame stays calm). No stock photos of people. No 3D game assets or mascots. When a real screenshot is missing, use a labeled placeholder frame rather than a faked UI.

**Motion.** Motion only where it explains. No scroll-jacking, no hero animations, no entrance choreography, no bounce, no confetti, no celebration. Durations are short (120–240ms) with a calm easing that never overshoots (`--ease-standard`). A hover that reveals an annotation; a connection that highlights on focus. Reduced motion is respected globally in `tokens/motion.css`.

**Hover & press.** Hovers shift one step toward ink (darker fill) or reveal a hairline; they never lift dramatically or change hue. Links thicken their red underline on hover. Press states deepen the fill a further step. Nothing scales or springs.

**Focus.** Always visible, keyboard-first, red: a 2px paper offset plus a 2px red ring (`--ring`). Accessibility is not optional in a tool built for the return visit.

---

## Iconography

The system uses **[Lucide](https://lucide.dev)**, loaded from CDN (`https://cdn.jsdelivr.net/npm/lucide@latest`). Lucide's clean, even outline icons at a 1.75–2px stroke read as editorial and technical, the right register for an intelligence report. They are line icons, not filled, which keeps them quiet next to the red.

- **Stroke weight:** 1.75px in dense UI, 2px at small sizes. Match the surrounding type weight; never heavier than the text it labels.
- **Color:** ink (`--ink-700`/`--ink-800`) by default. An icon turns red only when it is itself the point being marked (e.g. the annotate/pen glyph), following the same discipline as all red.
- **Sizes:** 16px inline with text, 18–24px standalone, 24px in nav.
- **Vocabulary:** `library`, `search`, `sliders-horizontal` (filters), `layout-grid`, `file-text` (reports), `git-fork` (systems), `book-open` (glossary), `calendar-days` (dated entries), `bookmark`, `link-2` (related), `lock` (gated), `mail`, `bar-chart-3` (stats), `quote`, `pen-line` (annotate), `arrow-up-right` (go). See the Iconography specimen card.

**Forbidden, from the brief:** no trophy, badge, or medal iconography anywhere. Those signal the pointsification we argue against. **No emoji** and **no unicode glyphs used as icons.** If a needed icon is missing from Lucide, substitute the nearest Lucide match at the same stroke and flag it; do not hand-draw a one-off SVG.

The brand mark itself (the red hexagon) is available standalone in `assets/logo/gamebiz-mark.svg` for favicons and compact placements.

---

## The system diagram language (signature asset)

System maps are the most ownable visual device. Someone seeing one in a LinkedIn feed should recognize it as ours before reading a word. The language is strict and consistent, implemented in the `SystemMap` component and documented in the "System diagram language" specimen card.

- **Ground:** a faint 22px radial-dot grid at ~50% opacity on the sheet. Reads as graph paper.
- **Nodes:** white sheet cards, 1px ink-400 border, 3px radius, minimal shadow. Each node carries a small tracked category label with a quiet color dot, then the mechanic name in Sora 600. A highlighted node takes a red border.
- **Connections:** gently curved paths. At rest they are ink (`--map-line`, 1.5px). Highlighted, they turn red (`--map-line-active`, 2px): the line that says "look here." Optional relationship labels sit on the curve.
- **Data contract:** nodes carry `{ id, label, category, x, y }` where x/y are percentages; connections carry `{ from, to, label?, active? }`. This mirrors the APPS / SYSTEMS / CONNECTIONS sources named in the page-requirements guide. **Do not restructure this data shape without flagging it first.**

---

## What this system contains

### Foundations (`tokens/`, linked by `styles.css`)
- `fonts.css` — self-hosted Sora and DM Sans (woff2, latin subset, in `assets/fonts/`).
- `colors.css` — paper, ink scale, the red, category colors, status, and all semantic aliases.
- `typography.css` — families, weights, sizes, line heights, tracking, composed `--type-*` roles.
- `spacing.css` — 4px spacing scale, layout widths, radii, border widths.
- `elevation.css` — shadows, composed border/rule tokens, the focus ring.
- `motion.css` — durations, easings, the reduced-motion guard.
- `base.css` — minimal element defaults (paper background, link underline, selection, focus).

`styles.css` at the root is the single entry point consumers link. It is `@import` lines only.

### Components (`components/`)
Reusable React primitives. Each is `<Name>.jsx` + `<Name>.d.ts` + `<Name>.prompt.md`, styled only through the CSS custom properties (self-injecting CSS, React-only, no other dependencies). Read them on `window.GameBizDesignSystem_1aad9e`.

| Component | Group | What it is |
|---|---|---|
| `Button` | core | The action. Five variants; red `accent` reserved for the one key action per view. |
| `Tag` | core | Specimen-label classification chip for the three categories. |
| `Badge` | core | Small status marker: "Updated weekly," "Free," "New this week." |
| `Input` | forms | Single-line text field with label, hint, and error. |
| `Card` | content | The base specimen sheet everything composes. |
| `MechanicCard` | content | One of the 22 mechanics as a browsable card. |
| `StatBlock` | content | A number with its required source line. |
| `LockedNotice` | content | The freemium gate as an invitation, not a wall. |
| `AnnotatedScreenshot` | evidence | The signature evidence device: framed specimen, red pins, real-sentence caption. |
| `SystemMap` | diagram | The signature diagram language: nodes and red connections. |

### Specimen cards (`guidelines/cards/`)
21 small HTML cards that populate the Design System tab, grouped Colors / Type / Spacing / Brand / Components. Each links the real `styles.css` so it always reflects live tokens.

### Assets (`assets/`)
- `logo/gamebiz-logo.svg` (original), `gamebiz-logo-reverse.svg` (white wordmark, red mark, for ink grounds), `gamebiz-logo-ink.svg` (single-color), `gamebiz-mark.svg` (the red hexagon alone).
- `fonts/` — the 12 self-hosted woff2 files.

---

## Using the system

1. Link `styles.css` once. You get every token, font, and base style.
2. Reach for the semantic aliases (`--text-secondary`, `--surface-card`, `--accent`), not the raw scale, so themes stay coherent.
3. Compose components from `window.GameBizDesignSystem_1aad9e`; see each `*.prompt.md` for usage and variants.
4. Apply the voice. The visuals are calm on purpose; the writing and the evidence carry the warmth.

## The forbidden list (from the brief, do not violate)

Never use: trophy, badge, or medal iconography; neon gradients; mascots; 3D game assets; dark "gamer" aesthetics; confetti or celebration effects; stock photos of people; the word "fun" as a selling point; em dashes; emoji; gamified elements on our own surfaces (no streaks, points, or badges for subscribers). Knowing when mechanics belong and when they don't is what we sell, so our own surfaces stay un-gamified.

---

## Status & next steps

**Built and ready for review:** the full token foundation, the component library, the system-diagram language, iconography, logo treatments, and all specimen cards.

**Held for approval (per the brief):** the product UI kits and page recreations (Homepage, Work With Us, Mechanic detail, App case study, Reports, and the rest). These follow once the foundations are approved, and they will reuse these components rather than reinvent them.

**One substitution to confirm:** the brief named Sora and Inter, but per your direction the system uses **Sora and DM Sans only** (DM Sans replaces Inter for body and also takes the utility/label role the mono used to fill). No font binaries were provided, so both are self-hosted from Google Fonts. If you have licensed/hinted versions, send them and they will be swapped in place.

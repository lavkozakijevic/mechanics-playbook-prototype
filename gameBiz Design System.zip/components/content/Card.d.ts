import * as React from "react";

/**
 * Card — the base specimen sheet. A hairline-bordered container that every
 * other library surface composes. Set `interactive` to make it a hover-able link.
 */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  /** Apply default interior padding. @default true */
  pad?: boolean;
  /** Hover/focus affordance; renders as <a> unless `as` overrides. @default false */
  interactive?: boolean;
  /** `flat` removes the shadow; `sunken` is an inset well. @default "default" */
  variant?: "default" | "flat" | "sunken";
  /** Override the element. Defaults to "a" when interactive, else "div". */
  as?: keyof JSX.IntrinsicElements;
  children?: React.ReactNode;
}

export function Card(props: CardProps): JSX.Element;

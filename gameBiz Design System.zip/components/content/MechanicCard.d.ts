import * as React from "react";

/**
 * MechanicCard — one of the 22 mechanics as a browsable specimen card, for the
 * Mechanics index grid. Composes Card and Tag.
 */
export interface MechanicCardProps {
  /** Mechanic index in the 22-mechanic framework, e.g. 2 renders as "02". */
  number?: number | string;
  /** Quiet category classification. @default "neutral" */
  category?: "retention" | "monetization" | "social" | "neutral";
  /** Mechanic name, e.g. "Streaks". */
  name: string;
  /** One-sentence, plain-language definition. */
  definition: string;
  /** Context tags rendered as working filter links (ignored when locked). */
  contextTags?: string[];
  /** Gated state: hides tags and shows the quiet "In the full library" note. */
  locked?: boolean;
  /** Destination for the whole card. */
  href?: string;
}

export function MechanicCard(props: MechanicCardProps): JSX.Element;

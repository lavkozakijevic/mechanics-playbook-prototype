import * as React from "react";

/**
 * LockedNotice — the freemium gate as an invitation, not a paywall. Reads like a
 * closed archive drawer; copy invites rather than blocks.
 */
export interface LockedNoticeProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Invitation headline. @default "This breakdown is part of the full library" */
  title?: React.ReactNode;
  /** Body copy: what subscribers get, stated plainly. */
  children?: React.ReactNode;
  primaryLabel?: string;
  primaryHref?: string;
  /** Pass empty to hide the secondary action. @default "Log in" */
  secondaryLabel?: string;
  secondaryHref?: string;
}

export function LockedNotice(props: LockedNoticeProps): JSX.Element;

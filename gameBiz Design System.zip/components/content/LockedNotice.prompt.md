LockedNotice — the freemium gate as an invitation, not a paywall. A closed archive drawer.

```jsx
<LockedNotice />
<LockedNotice
  title="The full Royal Match map is in the library"
  primaryLabel="Subscribe"
  secondaryLabel="Log in">
  Subscribers see every connection in this system, plus the requirements behind each mechanic.
</LockedNotice>
```

Props: `title`, `children` (body), `primaryLabel`/`primaryHref`, `secondaryLabel`/`secondaryHref`.
Copy invites, never blocks. Pair it with a visible preview of the gated content above, never a hard wall.

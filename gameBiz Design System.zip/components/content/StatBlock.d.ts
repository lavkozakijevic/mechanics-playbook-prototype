import * as React from "react";

/**
 * StatBlock — a number with its provenance. The `source` line is part of the
 * contract: the brand never presents a figure without saying where it came from.
 */
export interface StatBlockProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The figure itself, e.g. "22" or "0.62". */
  value: React.ReactNode;
  /** Optional unit appended at a smaller size, e.g. "apps", "%". */
  unit?: React.ReactNode;
  /** What the number measures, plainly. */
  label?: React.ReactNode;
  /** Provenance. Rendered as "Source: …". Strongly encouraged on every stat. */
  source?: React.ReactNode;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
}

export function StatBlock(props: StatBlockProps): JSX.Element;

StatBlock — a number with its provenance. The brand never shows a figure without a source.

```jsx
<StatBlock value="22" unit="mechanics" label="Mapped in the framework" source="GameBiz library, June 2026" />
<StatBlock value="148" unit="apps" label="Analyzed and growing weekly" source="GameBiz library" size="lg" />
<StatBlock value="0.62" label="Royal Match DAU/MAU" source="company filings, Q1 2026" size="sm" />
```

Props: `value`, `unit`, `label`, `source` (required by convention), `size` ("sm" | "md" | "lg").
Always pass `source`. A stat without provenance does not ship.

Card — the base specimen sheet that every other library surface composes.

```jsx
<Card>Plain padded sheet.</Card>
<Card interactive href="/mechanics/streaks">A whole card that links somewhere.</Card>
<Card variant="sunken" pad>An inset well for secondary content.</Card>
```

Props: `pad` (default true), `interactive` (hover + renders as link), `variant` ("default" | "flat" | "sunken"), `as`.
Defined by a hairline border on the sheet, not a glossy shadow.

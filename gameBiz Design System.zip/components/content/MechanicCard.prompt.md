MechanicCard — one of the 22 mechanics as a browsable specimen card for the Mechanics index.

```jsx
<MechanicCard
  number={2}
  category="retention"
  name="Streaks"
  definition="A count of consecutive days a user returns, framed so the count itself feels worth protecting."
  contextTags={["Banking", "Achiever"]}
  href="/mechanics/streaks"
/>
<MechanicCard number={14} category="monetization" name="Loss-framed offers"
  definition="Time-boxed deals framed as something the user already has and might lose." locked />
```

Props: `number`, `category`, `name`, `definition`, `contextTags[]`, `locked`, `href`. Composes Card + Tag.
When `locked`, tags are replaced by the quiet "In the full library" note, never a hard wall.

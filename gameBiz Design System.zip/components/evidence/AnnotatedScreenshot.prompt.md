AnnotatedScreenshot — the brand's signature evidence device: a framed, labeled app screenshot with numbered red annotation pins and a real-sentence caption.

```jsx
<AnnotatedScreenshot
  src="/specimens/royal-match-reward.png"
  appName="Royal Match"
  screenLabel="Daily reward modal"
  date="Analyzed Jun 2026"
  caption="The reward lands before the player asks for it, so the next session already has a reason to start."
  annotations={[
    { x: 50, y: 32, n: 1, note: "The reward animates in on open, before any tap." },
    { x: 78, y: 70, n: 2, note: "The claim button is the only path forward, framed as a gift." },
  ]}
/>
```

Props: `src` (omit for a labeled placeholder), `appName`, `screenLabel`, `date`, `caption`, `annotations[]` ({x, y, n?, note?}), `aspectRatio`.
Pins are positioned by percent over the image. Keep the frame calm; the screenshot supplies the color. Captions are full sentences.

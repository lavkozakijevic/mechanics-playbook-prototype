import * as React from "react";

/**
 * AnnotatedScreenshot — the brand's signature evidence device. A consistently
 * framed, clearly labeled app screenshot with numbered red annotation pins and a
 * real-sentence caption.
 *
 * @startingPoint section="Evidence" subtitle="Framed, labeled specimen with red annotation pins" viewport="700x520"
 */
export interface AnnotatedScreenshotProps extends React.HTMLAttributes<HTMLElement> {
  /** Screenshot source. Omit to render a labeled specimen placeholder. */
  src?: string;
  alt?: string;
  /** App the specimen is from, e.g. "Royal Match". */
  appName?: string;
  /** Which screen, e.g. "Daily reward modal". */
  screenLabel?: string;
  /** Date of capture/analysis, shown in the specimen label. */
  date?: string;
  /** Caption as a real sentence that adds something the image doesn't say alone. */
  caption?: React.ReactNode;
  /** Red annotation pins positioned over the image, with optional notes. */
  annotations?: Annotation[];
  /** Frame aspect ratio (CSS aspect-ratio value). @default "16 / 10" */
  aspectRatio?: string;
}

export interface Annotation {
  /** Horizontal position over the specimen, 0–100 (percent). */
  x: number;
  /** Vertical position over the specimen, 0–100 (percent). */
  y: number;
  /** Pin number. Defaults to its index + 1. */
  n?: number;
  /** Real-sentence note explaining what this mark points at. */
  note?: React.ReactNode;
}

export function AnnotatedScreenshot(props: AnnotatedScreenshotProps): JSX.Element;

Input — a single-line text field on the sheet with optional label, hint, and error.

```jsx
<Input label="Email" type="email" placeholder="you@company.com" required
       hint="One email a week. The new entries, nothing else." />
<Input leadingIcon={<i data-lucide="search" />} placeholder="Search 22 mechanics" />
<Input label="Work email" error="Enter a valid work email so we can reach you." />
```

Sizes: `sm` · `md` · `lg`. Slots: `leadingIcon`, `trailingIcon`. Pass `error` to turn the field red and replace the hint.
Error copy says what went wrong and how to fix it, plainly, no apology.

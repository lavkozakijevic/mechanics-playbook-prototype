import * as React from "react";

/**
 * Input — a single-line text field on the sheet, with optional label, hint, and
 * error. Used for search, newsletter, and request forms.
 *
 * @startingPoint section="Forms" subtitle="Labelled text field with hint and error states" viewport="700x140"
 */
export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  /** Field label, sentence case. */
  label?: React.ReactNode;
  /** Helper text below the field. */
  hint?: React.ReactNode;
  /** Error message. Replaces hint and turns the field red. */
  error?: React.ReactNode;
  required?: boolean;
  /** Control height. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Icon element inside the field, leading (e.g. a search glyph). */
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  disabled?: boolean;
}

export function Input(props: InputProps): JSX.Element;

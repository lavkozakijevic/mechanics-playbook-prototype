SystemMap — the signature diagram language: mechanic nodes and red connection lines over a faint dotted ground.

```jsx
<SystemMap
  nodes={[
    { id: "streak", label: "Streaks", category: "retention", x: 20, y: 30, href: "#" },
    { id: "loss", label: "Loss aversion", category: "retention", x: 55, y: 18, active: true },
    { id: "reward", label: "Daily reward", category: "monetization", x: 50, y: 70 },
    { id: "leaderboard", label: "Leaderboards", category: "social", x: 82, y: 50 },
  ]}
  connections={[
    { from: "streak", to: "loss", label: "feeds", active: true },
    { from: "loss", to: "reward" },
    { from: "reward", to: "leaderboard" },
  ]}
/>
```

Props: `nodes[]` ({id, label, category, x, y, active?, href?}), `connections[]` ({from, to, label?, active?}), `width`, `height`.
Positions are percentages (0–100). Set `active` on a node or connection to mark it red, "look here." The data shape matches the APPS / SYSTEMS / CONNECTIONS sources; do not restructure it without flagging.

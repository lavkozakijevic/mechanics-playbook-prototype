import * as React from "react";

/**
 * SystemMap — the signature diagram language: mechanic nodes and red connection
 * lines over a faint dotted ground. Positions are percentages, so the same data
 * (APPS / SYSTEMS / CONNECTIONS) renders at any size without restructuring.
 *
 * @startingPoint section="Diagram" subtitle="The signature system map: nodes and red connections" viewport="700x420"
 */
export interface SystemMapProps extends React.HTMLAttributes<HTMLDivElement> {
  nodes?: SystemNode[];
  connections?: SystemConnection[];
  /** Intrinsic aspect width used for the line viewBox. @default 640 */
  width?: number;
  /** Intrinsic aspect height used for the line viewBox. @default 360 */
  height?: number;
}

export interface SystemNode {
  /** Stable id referenced by connections. */
  id: string;
  /** Node title, e.g. "Streaks". */
  label: string;
  /** Category, drives the quiet dot color. @default "neutral" */
  category?: "retention" | "monetization" | "social" | "neutral";
  /** Horizontal center, 0–100 (percent of the map width). */
  x: number | string;
  /** Vertical center, 0–100 (percent of the map height). */
  y: number | string;
  /** Highlight this node with the red accent border. */
  active?: boolean;
  /** Make the node a link to its mechanic page. */
  href?: string;
}

export interface SystemConnection {
  /** Source node id. */
  from: string;
  /** Target node id. */
  to: string;
  /** Optional relationship label on the line (mono). */
  label?: string;
  /** Highlight this connection in red: "look here". */
  active?: boolean;
}

export function SystemMap(props: SystemMapProps): JSX.Element;

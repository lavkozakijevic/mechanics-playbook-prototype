import * as React from "react";

/**
 * Tag — a specimen-label classification chip for the three mechanic categories
 * or neutral context tags. Uppercased and tracked, low chroma, never loud.
 */
export interface TagProps extends React.HTMLAttributes<HTMLElement> {
  /** Classification. Drives the quiet category color. @default "neutral" */
  category?: "retention" | "monetization" | "social" | "neutral";
  /** Soft tint ground or outline on the sheet. @default "soft" */
  variant?: "soft" | "outline";
  /** Show the leading category dot. @default false */
  dot?: boolean;
  /** Render as "a" to make the tag a working filter link. @default "span" */
  as?: "span" | "a";
  children?: React.ReactNode;
}

export function Tag(props: TagProps): JSX.Element;

import * as React from "react";

/**
 * Badge — a small status marker for freshness, access, and provenance signals
 * ("Updated weekly", "Free", "New this week"). Quiet utility, never celebratory.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Color role. @default "neutral" */
  tone?: "neutral" | "accent" | "ok" | "info" | "warn";
  /** Fill treatment. `solid` is rare; `outline` is the quietest. @default "soft" */
  variant?: "soft" | "solid" | "outline";
  /** Leading status dot, e.g. for the "Updated weekly" freshness signal. */
  pip?: boolean;
  /** Optional leading icon element. */
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;

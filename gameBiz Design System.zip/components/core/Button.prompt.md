Button — the brand's action; editorial ink by default, red reserved for the one key action per view.

```jsx
<Button variant="accent">Subscribe</Button>
<Button variant="primary">Explore the library</Button>
<Button variant="secondary" leadingIcon={<i data-lucide="sliders-horizontal" />}>Filter</Button>
<Button variant="ghost" size="sm">Clear</Button>
<Button variant="link" as="a" href="#">Read the breakdown</Button>
```

Variants: `primary` (ink), `accent` (red, sparing), `secondary` (bordered sheet), `ghost`, `link`.
Sizes: `sm` · `md` · `lg`. Slots: `leadingIcon`, `trailingIcon`. Use `as="a"` for link-buttons.
Rule: at most one `accent` button per view. It is the pen pointing at the action.

import * as React from "react";

/**
 * Button — the brand's action. Editorial by default, red only for the single
 * most important action on a page.
 *
 * @startingPoint section="Core" subtitle="Five variants, three sizes, icon slots" viewport="700x200"
 */
export interface ButtonProps extends React.HTMLAttributes<HTMLElement> {
  /** Visual role. `accent` (red) is reserved for the one key action per view. */
  variant?: "primary" | "accent" | "secondary" | "ghost" | "link";
  /** Control height. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Icon element rendered before the label (e.g. a Lucide <i> or <svg>). */
  leadingIcon?: React.ReactNode;
  /** Icon element rendered after the label. */
  trailingIcon?: React.ReactNode;
  disabled?: boolean;
  /** Render as a different element, e.g. "a" for a link-button. @default "button" */
  as?: "button" | "a";
  type?: "button" | "submit" | "reset";
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;

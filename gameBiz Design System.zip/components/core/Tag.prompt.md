Tag — a specimen-label classification chip for the three mechanic categories or neutral context tags.

```jsx
<Tag category="retention" dot>Retention</Tag>
<Tag category="monetization">Monetization</Tag>
<Tag category="social" variant="outline">Social</Tag>
<Tag as="a" href="?context=banking">Banking</Tag>
```

Categories: `retention` · `monetization` · `social` · `neutral`. Variants: `soft` (tint) · `outline`.
Use `dot` for the leading category dot, `as="a"` to make a working filter link. Uppercased and tracked, intentionally quiet.

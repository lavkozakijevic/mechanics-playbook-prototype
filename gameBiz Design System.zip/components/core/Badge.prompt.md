Badge — a small status marker for freshness, access, and provenance signals.

```jsx
<Badge tone="ok" pip>Updated weekly</Badge>
<Badge tone="accent" variant="solid">Free</Badge>
<Badge tone="neutral" variant="outline">New this week</Badge>
<Badge tone="info" icon={<i data-lucide="lock" />}>Subscribers</Badge>
```

Tones: `neutral` · `accent` · `ok` · `info` · `warn`. Variants: `soft` · `solid` (rare) · `outline` (quietest).
`pip` adds the live freshness dot. Keep copy plain and literal, never celebratory.

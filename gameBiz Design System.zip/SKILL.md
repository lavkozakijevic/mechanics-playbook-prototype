---
name: gamebiz-design
description: Use this skill to generate well-branded interfaces and assets for gameBiz, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## The one thing to get right

gameBiz is an evidence-based gamification practice. The category's default look is playful; ours is serious, with the play living in the subject matter. The organizing idea is **the analyst's archive**: part field guide, part intelligence report, part well-kept research library. Before any decision, ask: *would a serious analyst's archive do this?* If not, cut it.

## Where things are

- `README.md` — the full design guide: content fundamentals (voice), visual foundations, iconography, the system-diagram language, and the component manifest. Read it first.
- `styles.css` — the single CSS entry point. Link it and you get every token, font, and base style. It is `@import` lines only.
- `tokens/` — colors, typography, spacing, elevation, motion, base. CSS custom properties; use the semantic aliases (`--text-secondary`, `--surface-card`, `--accent`).
- `components/` — React primitives (`Button`, `Tag`, `Badge`, `Input`, `Card`, `MechanicCard`, `StatBlock`, `LockedNotice`, `AnnotatedScreenshot`, `SystemMap`). Each has a `.prompt.md` with usage. They self-inject their CSS and depend only on React.
- `guidelines/cards/` — visual specimen cards for every foundation.
- `assets/logo/` — logo variants (original, reverse, ink, mark-only). `assets/fonts/` — self-hosted woff2.

## Non-negotiables

- Paper background `#f5f4f0`, ink text, white sheet cards with hairline borders. Flat, not glossy.
- Red `#f03636` is the analyst's pen: marks, the one underline, connection lines, the single key action per view. Never a large surface or decoration.
- Type: Sora for display and headings, DM Sans for everything else (body, plus the uppercased specimen label and data). Two families only. Sentence case everywhere.
- Numbers always carry a source. Motion only where it explains. Keyboard focus always visible.
- **Forbidden:** trophy/badge/medal icons, neon gradients, mascots, 3D game assets, dark "gamer" looks, confetti, stock photos of people, the word "fun" as a sell, em dashes, emoji, and any gamified element on gameBiz's own surfaces.

## Voice in one line

Write like a knowledgeable friend who studies this for a living and enjoys showing you what they found. Short sentences, active voice, front-loaded point, no hype, everyone respected.

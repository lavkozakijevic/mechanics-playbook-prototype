/* @ds-bundle: {"format":3,"namespace":"GameBizDesignSystem_1aad9e","components":[{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"LockedNotice","sourcePath":"components/content/LockedNotice.jsx"},{"name":"MechanicCard","sourcePath":"components/content/MechanicCard.jsx"},{"name":"StatBlock","sourcePath":"components/content/StatBlock.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"SystemMap","sourcePath":"components/diagram/SystemMap.jsx"},{"name":"AnnotatedScreenshot","sourcePath":"components/evidence/AnnotatedScreenshot.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"}],"sourceHashes":{"components/content/Card.jsx":"530d91bf2068","components/content/LockedNotice.jsx":"7fc8d77e8cbe","components/content/MechanicCard.jsx":"c2c59da27038","components/content/StatBlock.jsx":"760dc0fa1225","components/core/Badge.jsx":"0f4d6a8ca2d5","components/core/Button.jsx":"1a0848ee67f9","components/core/Tag.jsx":"b2d36b0e23a3","components/diagram/SystemMap.jsx":"991f16266695","components/evidence/AnnotatedScreenshot.jsx":"267657baf6e0","components/forms/Input.jsx":"fbdca4ac3142","ui_kits/website/CaseStudies.jsx":"042a393edea5","ui_kits/website/CaseStudyDetail.jsx":"720b80191a46","ui_kits/website/CheatsheetDetail.jsx":"dd2fac667c06","ui_kits/website/Cheatsheets.jsx":"8bc28123a58e","ui_kits/website/Glossary.jsx":"394043241527","ui_kits/website/GlossaryDetail.jsx":"6f04991810e5","ui_kits/website/HomeBottom.jsx":"f7864523bf5c","ui_kits/website/HomeTop.jsx":"3c36f074f2af","ui_kits/website/IndustryReport.jsx":"a107fd0f8a73","ui_kits/website/LockedState.jsx":"44122affbfcf","ui_kits/website/Login.jsx":"2c5187ed1fd3","ui_kits/website/MechanicDetail.jsx":"103e48dbdb05","ui_kits/website/MechanicsLibrary.jsx":"9a17aadb9861","ui_kits/website/Report.jsx":"77673e5f17db","ui_kits/website/SiteChrome.jsx":"34b1ac486bfd","ui_kits/website/Subscribe.jsx":"6b7248fc9039","ui_kits/website/SystemDetail.jsx":"61d6fabbee58","ui_kits/website/Systems.jsx":"d4e9ad7b91db","ui_kits/website/WorkWithUs.jsx":"fbc0f8b01f2f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.GameBizDesignSystem_1aad9e = window.GameBizDesignSystem_1aad9e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-card-css", `
.gb-card {
  background: var(--surface-card); border: 1px solid var(--border-subtle);
  border-radius: var(--radius-md); box-shadow: var(--shadow-xs);
  transition: var(--transition-base); position: relative;
}
.gb-card--pad { padding: var(--space-5); }
.gb-card--interactive { cursor: pointer; text-decoration: none; color: inherit; display: block; }
.gb-card--interactive:hover { border-color: var(--border-strong); box-shadow: var(--shadow-sm); }
.gb-card--interactive:focus-visible { outline: none; box-shadow: var(--ring); }
.gb-card--flat { box-shadow: none; }
.gb-card--sunken { background: var(--surface-sunken); border-color: transparent; box-shadow: none; }
`);

/**
 * Card — the base specimen sheet. Defined by a hairline border on the sheet,
 * not by a glossy lift. Everything else in the library composes this.
 */
function Card({
  pad = true,
  interactive = false,
  variant = "default",
  as,
  className = "",
  children,
  ...rest
}) {
  const Tag = as || (interactive ? "a" : "div");
  const cls = ["gb-card", pad ? "gb-card--pad" : "", interactive ? "gb-card--interactive" : "", variant === "flat" ? "gb-card--flat" : "", variant === "sunken" ? "gb-card--sunken" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-stat-css", `
.gb-stat { display: flex; flex-direction: column; gap: 4px; }
.gb-stat__value { font-family: var(--font-display); font-weight: var(--weight-bold);
  font-size: var(--_sz, 40px); line-height: 1; letter-spacing: -0.02em; color: var(--ink-900);
  display: flex; align-items: baseline; gap: 4px; }
.gb-stat__unit { font-size: 0.5em; font-weight: var(--weight-semibold); color: var(--text-secondary); }
.gb-stat__label { font-family: var(--font-body); font-size: 14px; font-weight: var(--weight-medium); color: var(--ink-700); }
.gb-stat__source { font-family: var(--font-mono); font-size: 11px; letter-spacing: 0.02em;
  color: var(--text-faint); margin-top: 2px; }
.gb-stat--sm { --_sz: 28px; }
.gb-stat--lg { --_sz: 56px; }
`);

/**
 * StatBlock — a number with its provenance. We never show a figure without
 * saying where it came from; the `source` line is required, not optional.
 */
function StatBlock({
  value,
  unit,
  label,
  source,
  size = "md",
  className = "",
  ...rest
}) {
  const cls = ["gb-stat", size !== "md" ? `gb-stat--${size}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "gb-stat__value"
  }, value, unit && /*#__PURE__*/React.createElement("span", {
    className: "gb-stat__unit"
  }, unit)), label && /*#__PURE__*/React.createElement("div", {
    className: "gb-stat__label"
  }, label), source && /*#__PURE__*/React.createElement("div", {
    className: "gb-stat__source"
  }, "Source: ", source));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-badge-css", `
.gb-badge {
  display: inline-flex; align-items: center; gap: 5px;
  height: 22px; padding: 0 8px;
  font-family: var(--font-body); font-size: 12px; font-weight: var(--weight-semibold);
  line-height: 1; border-radius: var(--radius-sm); border: 1px solid transparent;
  white-space: nowrap;
}
.gb-badge svg { width: 12px; height: 12px; stroke-width: 2.25; flex: none; }
.gb-badge__pip { width: 6px; height: 6px; border-radius: 50%; flex: none; }

.gb-badge--neutral { background: var(--ink-100); color: var(--ink-700); }
.gb-badge--accent  { background: var(--red-wash); color: var(--red-600); }
.gb-badge--ok      { background: var(--ok-tint); color: var(--ok); }
.gb-badge--info    { background: var(--info-tint); color: var(--info); }
.gb-badge--warn    { background: var(--warn-tint); color: var(--warn); }

/* solid: rare, for "Free" style call-outs */
.gb-badge--solid.gb-badge--neutral { background: var(--ink-900); color: var(--paper); }
.gb-badge--solid.gb-badge--accent  { background: var(--accent); color: #fff; }

/* outline: hairline only, the quietest badge */
.gb-badge--outline { background: transparent; border-color: var(--border-default); color: var(--ink-600); }
`);
const PIP = {
  neutral: "var(--ink-500)",
  accent: "var(--accent)",
  ok: "var(--ok)",
  info: "var(--info)",
  warn: "var(--warn)"
};

/**
 * Badge — a small status marker. "Free", "Updated weekly", "New this week".
 * Quiet utility, never a celebration. Use `pip` for the live freshness dot.
 */
function Badge({
  tone = "neutral",
  variant = "soft",
  pip = false,
  icon = null,
  className = "",
  children,
  ...rest
}) {
  const cls = ["gb-badge", `gb-badge--${tone}`, variant !== "soft" ? `gb-badge--${variant}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), pip && /*#__PURE__*/React.createElement("span", {
    className: "gb-badge__pip",
    style: {
      background: PIP[tone]
    }
  }), icon, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Inject component CSS once at module load. Keeps the component self-contained
   (React only) while giving real :hover / :focus-visible states. */
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-button-css", `
.gb-btn {
  --_h: 40px; --_px: 18px; --_fs: 15px;
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  height: var(--_h); padding: 0 var(--_px);
  font-family: var(--font-body); font-size: var(--_fs); font-weight: var(--weight-semibold);
  line-height: 1; letter-spacing: 0.005em; white-space: nowrap;
  border: 1px solid transparent; border-radius: var(--radius-md);
  cursor: pointer; user-select: none; text-decoration: none;
  transition: var(--transition-base); position: relative;
}
.gb-btn:focus-visible { outline: none; box-shadow: var(--ring); }
.gb-btn:disabled, .gb-btn[aria-disabled="true"] { cursor: not-allowed; opacity: 0.45; }
.gb-btn svg { width: 1.1em; height: 1.1em; stroke-width: 2; flex: none; }

.gb-btn--sm { --_h: 32px; --_px: 12px; --_fs: 13px; }
.gb-btn--lg { --_h: 48px; --_px: 24px; --_fs: 16px; }

/* primary: serious ink CTA */
.gb-btn--primary { background: var(--ink-900); color: var(--paper); }
.gb-btn--primary:hover:not(:disabled) { background: var(--ink-800); }
.gb-btn--primary:active:not(:disabled) { background: #000; }

/* accent: the one red action. used sparingly. */
.gb-btn--accent { background: var(--accent); color: var(--text-on-accent); }
.gb-btn--accent:hover:not(:disabled) { background: var(--accent-hover); }
.gb-btn--accent:active:not(:disabled) { background: var(--accent-press); }

/* secondary: bordered sheet */
.gb-btn--secondary { background: var(--sheet); color: var(--ink-900); border-color: var(--border-default); }
.gb-btn--secondary:hover:not(:disabled) { background: var(--paper); border-color: var(--border-strong); }
.gb-btn--secondary:active:not(:disabled) { background: var(--paper-deep); }

/* ghost: chromeless */
.gb-btn--ghost { background: transparent; color: var(--ink-800); }
.gb-btn--ghost:hover:not(:disabled) { background: var(--paper-edge); }
.gb-btn--ghost:active:not(:disabled) { background: var(--paper-deep); }

/* link: text with the red underline */
.gb-btn--link { background: transparent; color: var(--ink-900); height: auto; padding: 0;
  border-radius: var(--radius-sm); text-decoration: underline;
  text-decoration-color: var(--accent); text-underline-offset: 3px; text-decoration-thickness: 1.5px; }
.gb-btn--link:hover:not(:disabled) { text-decoration-thickness: 2px; }
`);

/**
 * Button — the brand's action. Five variants: primary (serious ink), accent
 * (the one red action, used sparingly), secondary, ghost, link.
 */
function Button({
  variant = "primary",
  size = "md",
  leadingIcon = null,
  trailingIcon = null,
  disabled = false,
  type = "button",
  as = "button",
  className = "",
  children,
  ...rest
}) {
  const cls = ["gb-btn", `gb-btn--${variant}`, size !== "md" ? `gb-btn--${size}` : "", className].filter(Boolean).join(" ");
  const Tag = as;
  const tagProps = Tag === "button" ? {
    type,
    disabled
  } : {
    "aria-disabled": disabled || undefined
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, tagProps, rest), leadingIcon, children, trailingIcon);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/content/LockedNotice.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-locked-css", `
.gb-locked {
  display: flex; flex-direction: column; align-items: center; text-align: center; gap: 12px;
  padding: var(--space-6) var(--space-5);
  background: var(--surface-card);
  border: 1px solid var(--border-default); border-radius: var(--radius-md);
  position: relative; overflow: hidden;
}
/* a closed archive drawer: a quiet ink band, not an alarm */
.gb-locked::before {
  content: ""; position: absolute; inset: 0 0 auto 0; height: 3px;
  background: repeating-linear-gradient(90deg, var(--ink-300) 0 10px, transparent 10px 20px);
  opacity: 0.7;
}
.gb-locked__icon {
  width: 38px; height: 38px; display: grid; place-items: center;
  border-radius: var(--radius-md); background: var(--paper-deep); color: var(--ink-600);
}
.gb-locked__icon svg { width: 18px; height: 18px; stroke-width: 2; }
.gb-locked__title { font-family: var(--font-display); font-size: 17px; font-weight: var(--weight-semibold);
  color: var(--ink-900); margin: 0; letter-spacing: var(--tracking-heading); }
.gb-locked__body { font-family: var(--font-body); font-size: 14px; line-height: 1.55;
  color: var(--text-secondary); margin: 0; max-width: 42ch; text-wrap: pretty; }
.gb-locked__actions { display: flex; gap: 10px; margin-top: 4px; }
`);

/**
 * LockedNotice — the freemium gate as an invitation, not a wall. Reads like a
 * closed archive drawer. Copy invites ("This breakdown is part of the full
 * library"); one click to Subscribe.
 */
function LockedNotice({
  title = "This breakdown is part of the full library",
  children = "Subscribers see every annotated screenshot, the system map, and the requirements behind this mechanic. New entries land every week.",
  primaryLabel = "Subscribe",
  primaryHref = "/subscribe",
  secondaryLabel = "Log in",
  secondaryHref = "/login",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["gb-locked", className].filter(Boolean).join(" ")
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "gb-locked__icon"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "lock"
  })), /*#__PURE__*/React.createElement("h3", {
    className: "gb-locked__title"
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "gb-locked__body"
  }, children), /*#__PURE__*/React.createElement("div", {
    className: "gb-locked__actions"
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "accent",
    as: "a",
    href: primaryHref
  }, primaryLabel), secondaryLabel && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "ghost",
    as: "a",
    href: secondaryHref
  }, secondaryLabel)));
}
Object.assign(__ds_scope, { LockedNotice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/LockedNotice.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-tag-css", `
.gb-tag {
  display: inline-flex; align-items: center; gap: 6px;
  height: 24px; padding: 0 9px;
  font-family: var(--font-mono); font-size: 11px; font-weight: var(--weight-medium);
  letter-spacing: 0.06em; text-transform: uppercase; line-height: 1;
  border-radius: var(--radius-sm); border: 1px solid transparent;
  white-space: nowrap; text-decoration: none; transition: var(--transition-base);
}
a.gb-tag:hover { filter: brightness(0.97); text-decoration: none; }
.gb-tag__dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }

.gb-tag--neutral { background: var(--ink-100); color: var(--ink-700); }
.gb-tag--retention { background: var(--cat-retention-tint); color: var(--cat-retention); }
.gb-tag--monetization { background: var(--cat-monetization-tint); color: var(--cat-monetization); }
.gb-tag--social { background: var(--cat-social-tint); color: var(--cat-social); }

/* outline reading: a quieter classification on the sheet */
.gb-tag--outline { background: transparent; }
.gb-tag--outline.gb-tag--neutral { border-color: var(--border-default); }
.gb-tag--outline.gb-tag--retention { border-color: var(--cat-retention); }
.gb-tag--outline.gb-tag--monetization { border-color: var(--cat-monetization); }
.gb-tag--outline.gb-tag--social { border-color: var(--cat-social); }
`);
const DOT = {
  retention: "var(--cat-retention)",
  monetization: "var(--cat-monetization)",
  social: "var(--cat-social)",
  neutral: "var(--ink-500)"
};

/**
 * Tag — a specimen-label classification chip. Carries one of the three mechanic
 * categories (or neutral context tags). Quiet by design; never competes with red.
 */
function Tag({
  category = "neutral",
  variant = "soft",
  dot = false,
  as = "span",
  className = "",
  children,
  ...rest
}) {
  const cls = ["gb-tag", `gb-tag--${category}`, variant === "outline" ? "gb-tag--outline" : "", className].filter(Boolean).join(" ");
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: "gb-tag__dot",
    style: {
      background: DOT[category]
    }
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/content/MechanicCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-mechanic-css", `
.gb-mechanic { display: flex; flex-direction: column; gap: 12px; min-height: 168px; }
.gb-mechanic__top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.gb-mechanic__num { font-family: var(--font-mono); font-size: 12px; font-weight: var(--weight-medium);
  letter-spacing: 0.08em; color: var(--text-faint); }
.gb-mechanic__name { font-family: var(--font-display); font-size: 19px; font-weight: var(--weight-semibold);
  letter-spacing: var(--tracking-heading); color: var(--ink-900); line-height: 1.25; margin: 0; }
.gb-mechanic__def { font-family: var(--font-body); font-size: 14px; line-height: 1.55; color: var(--text-secondary);
  margin: 0; text-wrap: pretty; }
.gb-mechanic__tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: auto; padding-top: 4px; }
.gb-mechanic__lock { display: inline-flex; align-items: center; gap: 5px; font-family: var(--font-mono);
  font-size: 11px; letter-spacing: 0.04em; color: var(--text-muted); }
.gb-mechanic__lock svg { width: 13px; height: 13px; stroke-width: 2; }
.gb-card--interactive:hover .gb-mechanic__name { text-decoration: underline;
  text-decoration-color: var(--accent); text-underline-offset: 3px; text-decoration-thickness: 2px; }
`);
const LABEL = {
  retention: "Retention",
  monetization: "Monetization",
  social: "Social",
  neutral: "Mechanic"
};

/**
 * MechanicCard — one of the 22 mechanics as a browsable specimen. Number,
 * category, name, one-sentence definition, and context tags as filter links.
 */
function MechanicCard({
  number,
  category = "neutral",
  name,
  definition,
  contextTags = [],
  locked = false,
  href,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, _extends({
    interactive: true,
    href: href
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "gb-mechanic"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-mechanic__top"
  }, /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    category: category,
    dot: true
  }, LABEL[category]), number != null && /*#__PURE__*/React.createElement("span", {
    className: "gb-mechanic__num"
  }, String(number).padStart(2, "0"))), /*#__PURE__*/React.createElement("h3", {
    className: "gb-mechanic__name"
  }, name), /*#__PURE__*/React.createElement("p", {
    className: "gb-mechanic__def"
  }, definition), /*#__PURE__*/React.createElement("div", {
    className: "gb-mechanic__tags"
  }, locked ? /*#__PURE__*/React.createElement("span", {
    className: "gb-mechanic__lock"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "lock"
  }), "In the full library") : contextTags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t,
    category: "neutral"
  }, t)))));
}
Object.assign(__ds_scope, { MechanicCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/MechanicCard.jsx", error: String((e && e.message) || e) }); }

// components/diagram/SystemMap.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-map-css", `
.gb-map { position: relative; width: 100%; background: var(--surface-card);
  border: 1px solid var(--border-subtle); border-radius: var(--radius-md); overflow: hidden; }
.gb-map__paper { position: absolute; inset: 0;
  background-image: radial-gradient(var(--ink-200) 1px, transparent 1px);
  background-size: 22px 22px; opacity: 0.5; }
.gb-map__lines { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }
.gb-map__line { fill: none; stroke: var(--map-line); stroke-width: 1.5; transition: stroke var(--duration-base) var(--ease-standard), stroke-width var(--duration-base) var(--ease-standard); }
.gb-map__line--active { stroke: var(--map-line-active); stroke-width: 2; }
.gb-map__linelabel { font-family: var(--font-mono); font-size: 10px; fill: var(--text-muted); letter-spacing: 0.04em; }

.gb-node {
  position: absolute; transform: translate(-50%, -50%);
  min-width: 116px; max-width: 168px; padding: 9px 12px;
  background: var(--node-fill); border: 1px solid var(--node-border);
  border-radius: var(--radius-sm); box-shadow: var(--shadow-xs);
  z-index: 2; transition: var(--transition-base); cursor: default; text-decoration: none;
}
a.gb-node:hover { border-color: var(--ink-900); box-shadow: var(--shadow-sm); }
.gb-node__cat { display: inline-flex; align-items: center; gap: 5px;
  font-family: var(--font-mono); font-size: 9px; font-weight: var(--weight-medium);
  text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: 3px; }
.gb-node__dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.gb-node__label { font-family: var(--font-display); font-size: 13px; font-weight: var(--weight-semibold);
  color: var(--ink-900); line-height: 1.2; letter-spacing: -0.01em; }
.gb-node--accent { border-color: var(--accent); }
`);
const CAT_COLOR = {
  retention: "var(--cat-retention)",
  monetization: "var(--cat-monetization)",
  social: "var(--cat-social)",
  neutral: "var(--ink-500)"
};
const CAT_LABEL = {
  retention: "Retention",
  monetization: "Monetization",
  social: "Social",
  neutral: "Mechanic"
};

/**
 * SystemMap — the signature diagram language. Renders mechanic nodes and the red
 * connection lines between them over a faint dotted ground. Strict, consistent,
 * recognizable as ours before a word is read.
 */
function SystemMap({
  nodes = [],
  connections = [],
  width = 640,
  height = 360,
  className = "",
  ...rest
}) {
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
  const px = v => typeof v === "number" ? v : parseFloat(v);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["gb-map", className].filter(Boolean).join(" "),
    style: {
      aspectRatio: `${width} / ${height}`
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "gb-map__paper"
  }), /*#__PURE__*/React.createElement("svg", {
    className: "gb-map__lines",
    viewBox: `0 0 ${width} ${height}`,
    preserveAspectRatio: "none"
  }, connections.map((c, i) => {
    const a = byId[c.from],
      b = byId[c.to];
    if (!a || !b) return null;
    const x1 = px(a.x) / 100 * width,
      y1 = px(a.y) / 100 * height;
    const x2 = px(b.x) / 100 * width,
      y2 = px(b.y) / 100 * height;
    const mx = (x1 + x2) / 2,
      my = (y1 + y2) / 2;
    const cx = mx,
      cy = my - Math.min(40, Math.abs(x2 - x1) * 0.18);
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("path", {
      className: `gb-map__line ${c.active ? "gb-map__line--active" : ""}`,
      d: `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`
    }), c.label && /*#__PURE__*/React.createElement("text", {
      className: "gb-map__linelabel",
      x: mx,
      y: cy - 4,
      textAnchor: "middle"
    }, c.label));
  })), nodes.map(n => {
    const Tag = n.href ? "a" : "div";
    return /*#__PURE__*/React.createElement(Tag, {
      key: n.id,
      href: n.href,
      className: `gb-node ${n.active ? "gb-node--accent" : ""}`,
      style: {
        left: `${px(n.x)}%`,
        top: `${px(n.y)}%`
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "gb-node__cat"
    }, /*#__PURE__*/React.createElement("span", {
      className: "gb-node__dot",
      style: {
        background: CAT_COLOR[n.category || "neutral"]
      }
    }), CAT_LABEL[n.category || "neutral"]), /*#__PURE__*/React.createElement("div", {
      className: "gb-node__label"
    }, n.label));
  }));
}
Object.assign(__ds_scope, { SystemMap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/diagram/SystemMap.jsx", error: String((e && e.message) || e) }); }

// components/evidence/AnnotatedScreenshot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-evidence-css", `
.gb-evidence { display: flex; flex-direction: column; gap: 10px; }
.gb-evidence__label { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
.gb-evidence__title { font-family: var(--font-mono); font-size: 11px; font-weight: var(--weight-medium);
  text-transform: uppercase; letter-spacing: 0.09em; color: var(--ink-700); }
.gb-evidence__date { font-family: var(--font-mono); font-size: 11px; color: var(--text-faint); white-space: nowrap; }

.gb-evidence__frame {
  position: relative; background: var(--surface-sunken);
  border: 1px solid var(--border-default); border-radius: var(--radius-md);
  padding: 10px; overflow: hidden;
}
.gb-evidence__media {
  position: relative; border-radius: var(--radius-sm); overflow: hidden;
  background: var(--sheet); aspect-ratio: var(--_ar, 16 / 10);
  display: grid; place-items: center;
}
.gb-evidence__media img { width: 100%; height: 100%; object-fit: cover; display: block; }
.gb-evidence__placeholder {
  width: 100%; height: 100%; display: grid; place-items: center;
  font-family: var(--font-mono); font-size: 11px; letter-spacing: 0.06em; color: var(--text-faint);
  background:
    linear-gradient(135deg, transparent 46%, var(--ink-200) 46% 54%, transparent 54%) 0 0 / 16px 16px,
    var(--paper-deep);
}

/* the analyst's pen: numbered red annotation pins over the specimen */
.gb-pin {
  position: absolute; transform: translate(-50%, -50%);
  width: 22px; height: 22px; border-radius: 50%;
  background: var(--accent); color: #fff; border: 2px solid #fff;
  display: grid; place-items: center;
  font-family: var(--font-mono); font-size: 11px; font-weight: var(--weight-semibold);
  box-shadow: 0 1px 4px rgba(240,54,54,0.45); z-index: 2;
}

.gb-evidence__caption { font-family: var(--font-body); font-size: 14px; line-height: 1.55;
  color: var(--text-secondary); margin: 0; text-wrap: pretty; }
.gb-evidence__caption b { color: var(--ink-900); font-weight: var(--weight-semibold); }

.gb-evidence__notes { list-style: none; margin: 4px 0 0; padding: 0; display: flex; flex-direction: column; gap: 7px; }
.gb-evidence__note { display: flex; gap: 9px; align-items: baseline;
  font-family: var(--font-body); font-size: 13px; line-height: 1.5; color: var(--text-secondary); }
.gb-evidence__note .n { font-family: var(--font-mono); font-size: 10px; font-weight: var(--weight-semibold);
  color: #fff; background: var(--accent); width: 16px; height: 16px; border-radius: 50%;
  display: grid; place-items: center; flex: none; position: relative; top: 2px; }
`);

/**
 * AnnotatedScreenshot — the brand's standard way to present evidence. A
 * consistently framed specimen, clearly labeled, with numbered red annotation
 * pins and a real-sentence caption. The screenshot is the color; the frame stays calm.
 */
function AnnotatedScreenshot({
  src,
  alt = "",
  appName,
  screenLabel,
  date,
  caption,
  annotations = [],
  aspectRatio = "16 / 10",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("figure", _extends({
    className: ["gb-evidence", className].filter(Boolean).join(" "),
    style: {
      margin: 0
    }
  }, rest), (appName || screenLabel || date) && /*#__PURE__*/React.createElement("figcaption", {
    className: "gb-evidence__label"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gb-evidence__title"
  }, [appName, screenLabel].filter(Boolean).join(" · ")), date && /*#__PURE__*/React.createElement("span", {
    className: "gb-evidence__date"
  }, date)), /*#__PURE__*/React.createElement("div", {
    className: "gb-evidence__frame"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-evidence__media",
    style: {
      "--_ar": aspectRatio
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt
  }) : /*#__PURE__*/React.createElement("div", {
    className: "gb-evidence__placeholder"
  }, alt || "app screenshot"), annotations.map((a, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "gb-pin",
    style: {
      left: `${a.x}%`,
      top: `${a.y}%`
    }
  }, a.n != null ? a.n : i + 1)))), caption && /*#__PURE__*/React.createElement("p", {
    className: "gb-evidence__caption"
  }, caption), annotations.some(a => a.note) && /*#__PURE__*/React.createElement("ul", {
    className: "gb-evidence__notes"
  }, annotations.filter(a => a.note).map((a, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    className: "gb-evidence__note"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n"
  }, a.n != null ? a.n : i + 1), /*#__PURE__*/React.createElement("span", null, a.note)))));
}
Object.assign(__ds_scope, { AnnotatedScreenshot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/AnnotatedScreenshot.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
injectOnce("gb-input-css", `
.gb-field { display: flex; flex-direction: column; gap: 6px; }
.gb-field__label { font-family: var(--font-body); font-size: 13px; font-weight: var(--weight-semibold); color: var(--ink-800); }
.gb-field__req { color: var(--accent); margin-left: 2px; }
.gb-field__hint { font-family: var(--font-body); font-size: 12px; color: var(--text-muted); }
.gb-field__hint--error { color: var(--red-600); }

.gb-input {
  display: flex; align-items: center; gap: 8px;
  height: 40px; padding: 0 12px;
  background: var(--sheet); border: 1px solid var(--border-default);
  border-radius: var(--radius-md); transition: var(--transition-base);
}
.gb-input:hover { border-color: var(--border-strong); }
.gb-input:focus-within { border-color: var(--accent); box-shadow: 0 0 0 3px var(--red-wash); }
.gb-input--sm { height: 32px; }
.gb-input--lg { height: 48px; }
.gb-input--error { border-color: var(--red-500); }
.gb-input--error:focus-within { box-shadow: 0 0 0 3px var(--red-wash); }
.gb-input--disabled { background: var(--paper-deep); border-color: var(--border-subtle); cursor: not-allowed; }

.gb-input svg { width: 17px; height: 17px; stroke-width: 2; color: var(--ink-500); flex: none; }
.gb-input input {
  flex: 1; min-width: 0; border: none; outline: none; background: transparent;
  font-family: var(--font-body); font-size: 15px; color: var(--ink-900);
}
.gb-input input::placeholder { color: var(--text-faint); }
.gb-input input:disabled { cursor: not-allowed; }
`);

/**
 * Input — a single-line text field on the sheet. Hairline border, red focus.
 * Errors explain what went wrong, plainly, without apology.
 */
function Input({
  label,
  hint,
  error,
  required = false,
  size = "md",
  leadingIcon = null,
  trailingIcon = null,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  const fieldId = id || `gb-input-${Math.random().toString(36).slice(2, 8)}`;
  const boxCls = ["gb-input", size !== "md" ? `gb-input--${size}` : "", error ? "gb-input--error" : "", disabled ? "gb-input--disabled" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: ["gb-field", className].filter(Boolean).join(" ")
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "gb-field__label",
    htmlFor: fieldId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "gb-field__req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    className: boxCls
  }, leadingIcon, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    disabled: disabled,
    "aria-invalid": !!error
  }, rest)), trailingIcon), (error || hint) && /*#__PURE__*/React.createElement("span", {
    className: `gb-field__hint ${error ? "gb-field__hint--error" : ""}`
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CaseStudies.jsx
try { (() => {
/* Website kit — Case studies (apps index). Title block defining a "system",
   then a 3-up grid of system cards, one per analyzed app/game.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Tag,
    Badge
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};

  /* Lucide-style inline glyphs (created inline so they render before the CDN
     pass and never turn red). */
  const LockIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "4",
    y: "11",
    width: "16",
    height: "10",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V8a4 4 0 0 1 8 0v3"
  }));
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));

  /* Apps and games studied as systems. `locked` = behind the subscription
     (a dimmed preview, not a wall); Royal Match stays open to everyone.
     `tags` are a few of the mechanics from the 22-mechanic framework;
     `mechanics` is the full count. */
  const STUDIES = [{
    id: "RM",
    name: "Royal Match",
    type: "Game",
    locked: false,
    mechanics: 9,
    desc: "Royal Match keeps a saga puzzle moving with lives that meter each session and limited-time events that concentrate spend.",
    tags: ["Energy / Lives", "Limited-Time Events", "Season Pass", "Daily Reward"],
    href: "#royal-match"
  }, {
    id: "Du",
    name: "Duolingo",
    type: "App",
    locked: true,
    mechanics: 11,
    desc: "Duolingo pairs a visible streak with loss aversion, so a single missed day reads as real ground given up.",
    tags: ["Streak", "Loss Aversion", "Leaderboards", "Quests"]
  }, {
    id: "MG",
    name: "Monopoly Go",
    type: "Game",
    locked: true,
    mechanics: 10,
    desc: "Monopoly Go runs on dice as a spendable resource, with collections and timed events pulling players back between refills.",
    tags: ["Energy / Lives", "Collections / Sets", "Limited-Time Events", "Teams / Guilds"]
  }, {
    id: "St",
    name: "Strava",
    type: "App",
    locked: true,
    mechanics: 8,
    desc: "Strava turns solo workouts into standing, ranking segments against peers and tying milestones to the people you follow.",
    tags: ["Leaderboards", "Milestone Rewards", "Social Challenges", "Badges"]
  }, {
    id: "CC",
    name: "Candy Crush Saga",
    type: "Game",
    locked: true,
    mechanics: 9,
    desc: "Candy Crush paces play with lives and a long progress map, so the next level always sits one short session away.",
    tags: ["Energy / Lives", "Progress Bar", "Daily Reward", "Limited-Time Events"]
  }, {
    id: "Hs",
    name: "Headspace",
    type: "App",
    locked: true,
    mechanics: 7,
    desc: "Headspace protects a meditation habit with a run streak and milestone markers that make consistency visible.",
    tags: ["Streak", "Milestone Rewards", "Progress Bar", "Onboarding Goal"]
  }, {
    id: "CoC",
    name: "Clash of Clans",
    type: "Game",
    locked: true,
    mechanics: 12,
    desc: "Clash of Clans anchors retention in clans, where shared goals make a player's return owed partly to teammates.",
    tags: ["Teams / Guilds", "Tiers / Levels", "Season Pass", "Social Challenges"]
  }, {
    id: "Sb",
    name: "Starbucks",
    type: "App",
    locked: true,
    mechanics: 8,
    desc: "Starbucks Rewards converts everyday purchases into tiers and limited offers that make the next order worth tracking.",
    tags: ["Tiers / Levels", "Milestone Rewards", "Limited-Time Events", "Referral Rewards"]
  }, {
    id: "CM",
    name: "Coin Master",
    type: "Game",
    locked: true,
    mechanics: 10,
    desc: "Coin Master builds sessions on a spin with variable rewards, then collections and gifting keep the social loop turning.",
    tags: ["Variable Rewards", "Collections / Sets", "Gifting", "Daily Reward"]
  }];
  function SystemCard({
    s
  }) {
    return /*#__PURE__*/React.createElement("a", {
      className: "csc" + (s.locked ? " csc--locked" : ""),
      href: s.href || "#subscribe"
    }, /*#__PURE__*/React.createElement("div", {
      className: "csc__top"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: "neutral",
      variant: "outline"
    }, s.type), /*#__PURE__*/React.createElement("span", {
      className: "csc__badge"
    }, s.locked ? /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      variant: "outline",
      icon: LockIcon
    }, "For subscribers") : /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      variant: "soft"
    }, "Free"))), /*#__PURE__*/React.createElement("h3", {
      className: "csc__name"
    }, s.name), /*#__PURE__*/React.createElement("p", {
      className: "csc__desc"
    }, s.desc), /*#__PURE__*/React.createElement("div", {
      className: "csc__tags"
    }, s.tags.map(t => /*#__PURE__*/React.createElement("span", {
      className: "pillchip",
      key: t
    }, t))), /*#__PURE__*/React.createElement("div", {
      className: "csc__foot"
    }, /*#__PURE__*/React.createElement("span", {
      className: "csc__count"
    }, /*#__PURE__*/React.createElement("b", null, s.mechanics), " mechanics mapped"), /*#__PURE__*/React.createElement("span", {
      className: "csc__go"
    }, s.locked ? "Subscribe to read" : "View case study", " ", ArrowIcon)));
  }

  /** Case studies: the apps index, each app studied as a system. */
  function CaseStudiesPage() {
    const free = STUDIES.filter(s => !s.locked).length;
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "cs-head",
      "aria-labelledby": "cs-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#library"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Case studies")), /*#__PURE__*/React.createElement("div", {
      className: "eyebrow cs-head__eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", {
      id: "cs-h"
    }, "Case studies"), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def"
    }, "Every app here is studied as a ", /*#__PURE__*/React.createElement("b", null, "system"), ": the set of mechanics it runs and the way they feed each other, like a streak that protects a daily reward, or a leaderboard that fuels a season pass. We take each one apart, map it against the 22-mechanic framework, and show how the parts hold together."))), /*#__PURE__*/React.createElement("div", {
      className: "container cs-wrap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-bar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__count"
    }, /*#__PURE__*/React.createElement("b", null, STUDIES.length), " systems in the library"), /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__hint"
    }, free, " free to read \xB7 updated weekly")), /*#__PURE__*/React.createElement("div", {
      className: "csgrid"
    }, STUDIES.map(s => /*#__PURE__*/React.createElement(SystemCard, {
      key: s.id,
      s: s
    })))));
  }
  Object.assign(GBSite, {
    CaseStudiesPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CaseStudies.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CaseStudyDetail.jsx
try { (() => {
/* Website kit — Case study detail (Royal Match, full breakdown). A long-form,
   single-app breakdown: header, mechanics-observed chips, the core loop, a section
   per mechanic (observed / presented / worth noting / key findings / screenshots),
   how the mechanics connect, the key insight, numbered takeaways, and a sticky
   table-of-contents sidebar with scroll-spy.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    useState,
    useEffect
  } = React;
  const {
    Tag
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const CAT_COLOR = {
    retention: "var(--cat-retention)",
    monetization: "var(--cat-monetization)",
    social: "var(--cat-social)"
  };
  const CAT_LABEL = {
    retention: "Retention",
    monetization: "Monetization",
    social: "Social"
  };
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  const LinkIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"
  }));
  const PairIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "13 6 19 12 13 18"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "11 6 5 12 11 18"
  }));
  const APP = {
    name: "Royal Match",
    category: "Casual game",
    icon: "RM",
    overview: "Royal Match is a match-3 saga puzzle that has stayed near the top of the casual charts by being unusually disciplined about its loop. This breakdown takes the live game apart mechanic by mechanic: what each one does, how it is presented to the player, and how the four core mechanics are sequenced so the next session always has a reason to start. The throughline is restraint — nothing here is novel, but the order in which it arrives is."
  };
  const MECHANICS = [{
    id: "lives",
    cat: "monetization",
    name: "Energy / Lives",
    href: "mechanics.html",
    observed: "The player begins with five lives and loses one each time a board is failed. When the meter empties, play stops until a life regenerates on a fixed timer, or the player refills early. The resource governs how long a single sitting can run before the game asks something of the player.",
    presented: "The lives meter is pinned to the top bar at all times, with a live countdown to the next refill. The out-of-lives moment is handled as a modal rather than a dead end, offering three paths in a deliberate order: wait, ask friends, or buy.",
    noting: "The regeneration timer is tuned to feel survivable yet long enough that a refill is tempting at the exact moment motivation peaks — immediately after a loss, when the player most wants one more try.",
    findings: ["Lives turn a difficulty spike into a pricing moment without touching the puzzle itself.", "The wait is always visible, so the cost of stopping stays concrete.", "Wait, ask, buy are ordered to surface the social option before the paid one."],
    shots: ["Lives meter in top bar", "Out-of-lives modal", "Early-refill offer"]
  }, {
    id: "daily-reward",
    cat: "retention",
    name: "Daily Reward",
    href: "mechanics.html",
    observed: "Opening the app on a new day surfaces a reward before the player has done anything to earn it. The bonus escalates across consecutive days and resets to the start if a day is missed.",
    presented: "The reward animates onto a calendar overlay the instant the home screen loads. The days ahead are visible in the same view, showing both what an unbroken streak is worth and what a skipped day would forfeit.",
    noting: "The reward is given, not earned — no task gates it. The pull lives entirely in the escalation and the visible forfeit, not in the size of any single day's gift.",
    findings: ["The reward precedes the ask, so the session opens in credit.", "A visible escalating row makes skipping read as a loss, not a neutral choice.", "Nothing gates the bonus, which lowers the bar to re-engage after a lapse."],
    shots: ["Daily bonus calendar", "Seven-day reward", "Streak reset prompt"]
  }, {
    id: "limited-time-events",
    cat: "monetization",
    name: "Limited-Time Events",
    href: "mechanics.html",
    observed: "Short, themed events run for a few days on top of the base game, each with its own boards, a leaderboard, and rewards that vanish when the timer ends. They appear and disappear on a cadence rather than running continuously.",
    presented: "A countdown frames the whole event as already expiring. A tiered reward track shows the next prize sitting just beyond the player's current progress, so there is always a near target.",
    noting: "Events are spaced to punctuate the steady loop rather than replace it. The scarcity reads as genuinely special precisely because the rest of the game is always available.",
    findings: ["A defined window concentrates attention and spend into a burst.", "The tiered track keeps a reward within reach at every moment.", "Spacing protects the events from fatiguing into background noise."],
    shots: ["Event hub", "Tiered reward track", "Final-hours banner"]
  }, {
    id: "season-pass",
    cat: "monetization",
    name: "Season Pass",
    href: "mechanics.html",
    observed: "A multi-week pass offers two parallel reward tracks: a free track earned through ordinary play and a paid track that rewards the same play with more. Progress on both is driven by the same in-game actions.",
    presented: "Both tracks are shown side by side, with the paid track's richer rewards visible but locked. The player earns on the free track first, well before any prompt to upgrade appears.",
    noting: "The upgrade is offered only after the free track has already paid out, so the decision is framed as keeping value the player can see rather than gambling on value they cannot.",
    findings: ["Free-track rewards prove the system works before any spend is asked.", "The visible locked track frames the upgrade as keeping value, not unlocking a gate.", "A single purchase converts the whole loop's effort into a richer return."],
    shots: ["King's Pass tracks", "Locked paid tier", "Upgrade prompt"]
  }];
  const CONNECTIONS = [{
    a: "Energy / Lives",
    b: "Daily Reward",
    desc: "The daily reward frequently hands out lives or a refill, so the bonus that pulls the player back also tops up the very resource the session will spend. The return is rewarded with exactly the fuel the next sitting needs.",
    label: "These two mechanics share the same activation moment."
  }, {
    a: "Limited-Time Events",
    b: "Season Pass",
    desc: "Event play feeds pass progress, so the burst of a timed event also advances the slow track of the season. A short-term reason to play doubles as long-term progress without the player having to choose between them.",
    label: "The event is a fast loop nested inside the pass's slow loop."
  }, {
    a: "Energy / Lives",
    b: "Limited-Time Events",
    desc: "Events draw on the same life meter as the base game, so heightened event motivation raises the value of every refill. The scarcity of a closing window meets the scarcity of lives at the moment the player least wants to stop.",
    label: "Two kinds of scarcity stack on a single shared resource."
  }];
  const INSIGHT = {
    observation: "Royal Match never asks for anything before it has given something. Every spend moment is preceded by a mechanic that has already delivered visible value, so a purchase reads as protecting what the player holds rather than acquiring what they don't.",
    works: "The four mechanics share one resource and one action. Lives meter the puzzle, the daily reward refills lives, events raise the value of lives, and the pass collects all of it into a single upgrade. No mechanic stands alone, and the puzzle sits at the center of every loop."
  };
  const TAKEAWAYS = ["Meter the core experience with a single, visible resource before layering anything else on top of it.", "Give value before asking for it — the daily reward and the free pass track both pay out first.", "Use scarcity in bursts against a steady baseline, so timed events feel special instead of constant.", "Connect mechanics through a shared resource, so each one quietly raises the value of the others."];

  /* Table-of-contents sections, in document order. */
  const TOC = [{
    id: "overview",
    label: "Overview"
  }, {
    id: "mechanics-observed",
    label: "Mechanics observed"
  }, {
    id: "how-it-works",
    label: "How it works"
  }, ...MECHANICS.map(m => ({
    id: `m-${m.id}`,
    label: m.name,
    sub: true
  })), {
    id: "how-they-connect",
    label: "How they connect"
  }, {
    id: "key-insight",
    label: "Key insight"
  }, {
    id: "key-takeaways",
    label: "Key takeaways"
  }];
  function Shot({
    label
  }) {
    return /*#__PURE__*/React.createElement("figure", {
      className: "shot"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shot__frame"
    }, /*#__PURE__*/React.createElement("span", {
      className: "shot__ph"
    }, "screenshot")), /*#__PURE__*/React.createElement("figcaption", {
      className: "shot__cap"
    }, label));
  }
  function Toc({
    active
  }) {
    return /*#__PURE__*/React.createElement("aside", {
      className: "cs-toc",
      "aria-label": "On this page"
    }, /*#__PURE__*/React.createElement("a", {
      className: "cs-toc__back",
      href: "case-studies.html"
    }, "\u2190", " All case studies"), /*#__PURE__*/React.createElement("div", {
      className: "cs-toc__label"
    }, "On this page"), /*#__PURE__*/React.createElement("nav", {
      className: "cs-toc__nav"
    }, TOC.map(t => /*#__PURE__*/React.createElement("a", {
      key: t.id,
      href: `#${t.id}`,
      className: "cs-toc__link" + (t.sub ? " cs-toc__link--sub" : "") + (active === t.id ? " is-active" : "")
    }, t.label))));
  }
  function MechanicSection({
    m
  }) {
    return /*#__PURE__*/React.createElement("section", {
      className: "cs-msec",
      id: `m-${m.id}`,
      "aria-labelledby": `m-${m.id}-h`
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-msec__head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-msec__meta"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: m.cat,
      dot: true
    }, CAT_LABEL[m.cat]), /*#__PURE__*/React.createElement("h2", {
      className: "cs-msec__name",
      id: `m-${m.id}-h`
    }, m.name)), /*#__PURE__*/React.createElement("a", {
      className: "cs-msec__link",
      href: m.href
    }, "Full mechanic page ", ArrowIcon)), /*#__PURE__*/React.createElement("div", {
      className: "cs-msec__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-sub"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-sub__h"
    }, "What was observed"), /*#__PURE__*/React.createElement("p", null, m.observed)), /*#__PURE__*/React.createElement("div", {
      className: "cs-sub"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-sub__h"
    }, "How it is presented"), /*#__PURE__*/React.createElement("p", null, m.presented)), /*#__PURE__*/React.createElement("div", {
      className: "cs-sub"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-sub__h"
    }, "What is worth noting"), /*#__PURE__*/React.createElement("p", null, m.noting)), /*#__PURE__*/React.createElement("div", {
      className: "cs-sub"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-sub__h"
    }, "Key findings"), /*#__PURE__*/React.createElement("ul", {
      className: "cs-findings"
    }, m.findings.map((f, i) => /*#__PURE__*/React.createElement("li", {
      key: i
    }, f))))), /*#__PURE__*/React.createElement("div", {
      className: "shotgallery"
    }, m.shots.map(s => /*#__PURE__*/React.createElement(Shot, {
      key: s,
      label: s
    }))));
  }

  /** Case study full-breakdown page body. */
  function CaseStudyDetailPage() {
    const [active, setActive] = useState("overview");
    useEffect(() => {
      const ids = TOC.map(t => t.id);
      const onScroll = () => {
        const line = window.innerHeight * 0.3;
        let current = ids[0];
        for (const id of ids) {
          const el = document.getElementById(id);
          if (el && el.getBoundingClientRect().top - line <= 0) current = id;
        }
        setActive(current);
      };
      onScroll();
      window.addEventListener("scroll", onScroll, {
        passive: true
      });
      window.addEventListener("resize", onScroll);
      return () => {
        window.removeEventListener("scroll", onScroll);
        window.removeEventListener("resize", onScroll);
      };
    }, []);
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-layout"
    }, /*#__PURE__*/React.createElement(Toc, {
      active: active
    }), /*#__PURE__*/React.createElement("div", {
      className: "cs-main"
    }, /*#__PURE__*/React.createElement("header", {
      className: "cs-hd",
      id: "overview"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "case-studies.html"
    }, "Case studies"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, APP.name), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Full breakdown")), /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__icon",
      "aria-hidden": "true"
    }, APP.icon), /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__heads"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: "neutral",
      variant: "outline"
    }, APP.category), /*#__PURE__*/React.createElement("h1", {
      className: "cs-hd__title"
    }, APP.name, " ", "\u2014", " Full Breakdown"))), /*#__PURE__*/React.createElement("p", {
      className: "cs-hd__overview"
    }, APP.overview)), /*#__PURE__*/React.createElement("section", {
      className: "cs-sec",
      id: "mechanics-observed",
      "aria-labelledby": "mo-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Mechanics observed"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "mo-h"
    }, "Four mechanics carry the loop"), /*#__PURE__*/React.createElement("div", {
      className: "cs-chips"
    }, MECHANICS.map(m => /*#__PURE__*/React.createElement("a", {
      className: "cs-chip",
      href: `#m-${m.id}`,
      key: m.id
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-chip__dot",
      style: {
        background: CAT_COLOR[m.cat]
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "cs-chip__name"
    }, m.name), /*#__PURE__*/React.createElement("span", {
      className: "cs-chip__cat"
    }, CAT_LABEL[m.cat]))))), /*#__PURE__*/React.createElement("section", {
      className: "cs-sec",
      id: "how-it-works",
      "aria-labelledby": "hiw-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "How it works"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "hiw-h"
    }, "The core loop"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose cs-prose"
    }, /*#__PURE__*/React.createElement("p", null, "The loop starts and ends with the puzzle. A board costs a life to attempt; clearing it advances the map and pays out small rewards, while failing it spends the life and nudges the player toward a refill. The daily reward tops the meter back up on the next open, events raise the stakes of every board for a few days at a time, and the season pass quietly banks all of that play toward a larger reward."), /*#__PURE__*/React.createElement("p", null, "Every mechanic routes back to the same action: open the game and play a board. Lives decide the pace, the daily reward supplies the reason to return, events supply intensity, and the pass supplies a destination. None of them changes the puzzle \u2014 they change what the puzzle is worth, and when."))), MECHANICS.map(m => /*#__PURE__*/React.createElement(MechanicSection, {
      key: m.id,
      m: m
    })), /*#__PURE__*/React.createElement("section", {
      className: "cs-sec",
      id: "how-they-connect",
      "aria-labelledby": "htc-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "How they connect"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "htc-h"
    }, "Where the mechanics meet"), /*#__PURE__*/React.createElement("div", {
      className: "cs-conns"
    }, CONNECTIONS.map((c, i) => /*#__PURE__*/React.createElement("div", {
      className: "cs-conn",
      key: i
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-conn__h"
    }, c.a, " ", /*#__PURE__*/React.createElement("span", {
      className: "cs-conn__x",
      "aria-hidden": "true"
    }, "\u00d7"), " ", c.b), /*#__PURE__*/React.createElement("p", {
      className: "cs-conn__d"
    }, c.desc), /*#__PURE__*/React.createElement("div", {
      className: "cs-conn__label"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-conn__icon",
      "aria-hidden": "true"
    }, PairIcon), c.label))))), /*#__PURE__*/React.createElement("section", {
      className: "cs-sec",
      id: "key-insight",
      "aria-labelledby": "ki-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Key insight"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "ki-h"
    }, "What the system teaches"), /*#__PURE__*/React.createElement("div", {
      className: "cs-insight"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-insight__part"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-insight__h"
    }, "The single most instructive observation"), /*#__PURE__*/React.createElement("p", null, INSIGHT.observation)), /*#__PURE__*/React.createElement("div", {
      className: "cs-insight__part"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "cs-insight__h"
    }, "What makes the system work"), /*#__PURE__*/React.createElement("p", null, INSIGHT.works)))), /*#__PURE__*/React.createElement("section", {
      className: "cs-sec",
      id: "key-takeaways",
      "aria-labelledby": "kt-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "For your product"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "kt-h"
    }, "Key takeaways"), /*#__PURE__*/React.createElement("ol", {
      className: "cs-takelist"
    }, TAKEAWAYS.map((t, i) => /*#__PURE__*/React.createElement("li", {
      className: "cs-take",
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-take__n"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("p", null, t)))))))));
  }
  Object.assign(GBSite, {
    CaseStudyDetailPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CaseStudyDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CheatsheetDetail.jsx
try { (() => {
/* Website kit — Cheatsheet detail page ("Adding a streak without punishing lapses").
   Title block, five numbered steps (each with a guidance paragraph that names
   real apps inline plus a row of linked app references), and a sidebar with
   related mechanics and the apps featured, linked to their case studies.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Badge
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const IconArrow = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }));

  /* App reference targets. Every app named in the guide resolves through here so
     inline mentions and the sidebar both point at the same case study. */
  const APPS = {
    Duolingo: {
      cat: "Education",
      href: "case-studies.html#duolingo"
    },
    Headspace: {
      cat: "Health",
      href: "case-studies.html#headspace"
    },
    Finch: {
      cat: "Health",
      href: "case-studies.html#finch"
    },
    Calm: {
      cat: "Health",
      href: "case-studies.html#calm"
    },
    Snapchat: {
      cat: "Social",
      href: "case-studies.html#snapchat"
    }
  };

  /* An inline app mention — a quiet link that resolves to the app's case study. */
  function App({
    name
  }) {
    const a = APPS[name];
    return /*#__PURE__*/React.createElement("a", {
      className: "applink",
      href: a ? a.href : "case-studies.html"
    }, name);
  }
  const SHEET = {
    n: 2,
    category: "retention",
    title: "Adding a streak without punishing lapses",
    intro: "A streak is one of the most reliable ways to turn a product into a daily habit — and one of the easiest to get wrong. Push too hard on the reset and a single missed day reads as failure, and the user who cared most is the one who leaves. This guide walks through building a streak that earns the return without making one bad day a reason to quit.",
    steps: [{
      title: "Start the count only after the first real win",
      body: /*#__PURE__*/React.createElement("p", null, "A streak is only worth protecting once there is something to protect. Wait until a user has felt the core value before the counter appears \u2014 ", /*#__PURE__*/React.createElement(App, {
        name: "Duolingo"
      }), " holds its streak back until the first lesson is complete, and ", /*#__PURE__*/React.createElement(App, {
        name: "Headspace"
      }), " begins a run streak the day a user finishes their first session, not the day they sign up. Introduce it too early and the number means nothing; the user has invested nothing yet, so there is no loss in walking away."),
      apps: ["Duolingo", "Headspace"]
    }, {
      title: "Set a daily target low enough to keep on a bad day",
      body: /*#__PURE__*/React.createElement("p", null, "The streak survives on the days a user almost skips. Pick a target they can clear in a minute or two, even when motivation is gone. ", /*#__PURE__*/React.createElement(App, {
        name: "Duolingo"
      }), " keeps lessons short enough that protecting the count feels nearly free, and ", /*#__PURE__*/React.createElement(App, {
        name: "Calm"
      }), " counts any session \u2014 a meditation, a Sleep Story, a single breathing exercise \u2014 so the bar to keep the streak alive is whatever the user has time for tonight."),
      apps: ["Duolingo", "Calm"]
    }, {
      title: "Build the safety net before the streak gets long",
      body: /*#__PURE__*/React.createElement("p", null, "The longer a streak runs, the more a reset hurts \u2014 and the more likely it is to end the habit for good. Ship a forgiveness mechanic before users have months on the line.", " ", /*#__PURE__*/React.createElement(App, {
        name: "Duolingo"
      }), "'s Streak Freeze quietly spends to cover a missed day, and its weekend amnesty forgives the occasional slip without the user ever asking. The freeze is not a leak in the system; it is what lets a streak survive real life."),
      apps: ["Duolingo"]
    }, {
      title: "Frame a miss as a pause, not a failure",
      body: /*#__PURE__*/React.createElement("p", null, "When a streak does break, the words around it decide whether the user comes back. Avoid language that scolds. ", /*#__PURE__*/React.createElement(App, {
        name: "Finch"
      }), " wraps the whole loop in care for a virtual pet, so a missed day reads as the pet needing attention rather than the user failing a test, and ", /*#__PURE__*/React.createElement(App, {
        name: "Headspace"
      }), " keeps its tone encouraging even at zero. The same reset, framed kindly, is the difference between a guilty return and no return at all."),
      apps: ["Finch", "Headspace"]
    }, {
      title: "Reward the milestones, not just the daily tick",
      body: /*#__PURE__*/React.createElement("p", null, "A streak that only ever increments by one gets quiet over time. Give the count fresh meaning at thresholds. ", /*#__PURE__*/React.createElement(App, {
        name: "Headspace"
      }), " marks 10, 30, and 100 days with milestones that make the journey visible, while ", /*#__PURE__*/React.createElement(App, {
        name: "Snapchat"
      }), " escalates the flame and emoji beside a Snapstreak as it grows. Each marker is a small new reason to keep going, layered on top of the habit the streak already built."),
      apps: ["Headspace", "Snapchat"]
    }],
    relatedMechanics: [{
      name: "Streak / Streak Bonus",
      cat: "retention",
      href: "mechanic-streak.html"
    }, {
      name: "Loss Aversion",
      cat: "retention",
      href: "mechanics.html"
    }, {
      name: "Daily Reward",
      cat: "retention",
      href: "mechanics.html"
    }, {
      name: "Login Calendar",
      cat: "retention",
      href: "mechanics.html"
    }]
  };

  /* The featured apps, in the order they first appear, for the sidebar list. */
  const FEATURED = ["Duolingo", "Headspace", "Calm", "Finch", "Snapchat"];
  function TitleBlock() {
    return /*#__PURE__*/React.createElement("section", {
      className: "cs-head sheet-head",
      "aria-labelledby": "sheet-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("a", {
      href: "cheatsheets.html"
    }, "Cheatsheets"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Streaks without punishing lapses")), /*#__PURE__*/React.createElement("div", {
      className: "sheet-head__slug"
    }, /*#__PURE__*/React.createElement("span", {
      className: "eyebrow"
    }, "Cheatsheet ", String(SHEET.n).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
      className: "sheet-head__dot",
      "aria-hidden": "true"
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      className: "eyebrow eyebrow--muted"
    }, "Retention")), /*#__PURE__*/React.createElement("h1", {
      id: "sheet-h"
    }, SHEET.title), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def"
    }, SHEET.intro), /*#__PURE__*/React.createElement("div", {
      className: "sheet-head__meta"
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      variant: "soft"
    }, "Free guide"), /*#__PURE__*/React.createElement("span", {
      className: "sheet-head__count"
    }, /*#__PURE__*/React.createElement("b", null, SHEET.steps.length), " steps"))));
  }
  function Steps() {
    return /*#__PURE__*/React.createElement("section", {
      "aria-labelledby": "steps-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "The guide"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "steps-h"
    }, "Five steps to a forgiving streak"), /*#__PURE__*/React.createElement("ol", {
      className: "steps"
    }, SHEET.steps.map((s, i) => /*#__PURE__*/React.createElement("li", {
      className: "step",
      key: s.title
    }, /*#__PURE__*/React.createElement("span", {
      className: "step__n"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("div", {
      className: "step__main"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "step__title"
    }, s.title), /*#__PURE__*/React.createElement("div", {
      className: "step__body"
    }, s.body), /*#__PURE__*/React.createElement("div", {
      className: "step__refs"
    }, /*#__PURE__*/React.createElement("span", {
      className: "step__refs-label"
    }, "Seen in"), s.apps.map(a => /*#__PURE__*/React.createElement("a", {
      className: "refchip",
      href: APPS[a] ? APPS[a].href : "case-studies.html",
      key: a
    }, a))))))));
  }
  function Sidebar() {
    return /*#__PURE__*/React.createElement("aside", {
      className: "mech-aside",
      "aria-label": "Related"
    }, /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Related mechanics"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, SHEET.relatedMechanics.map(m => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: m.href,
      key: m.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__dot",
      style: {
        background: `var(--cat-${m.cat})`
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, m.name))))), /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Apps in this cheatsheet"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, FEATURED.map(a => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: APPS[a].href,
      key: a
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, a), /*#__PURE__*/React.createElement("span", {
      className: "amod__meta"
    }, APPS[a].cat))))));
  }

  /** Cheatsheet detail page body. */
  function CheatsheetDetailPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement(TitleBlock, null), /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-main"
    }, /*#__PURE__*/React.createElement(Steps, null)), /*#__PURE__*/React.createElement(Sidebar, null))));
  }
  Object.assign(GBSite, {
    CheatsheetDetailPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CheatsheetDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Cheatsheets.jsx
try { (() => {
/* Website kit — Cheatsheets index. Title block, six cheatsheet cards (each with
   an access badge, description, related mechanic tags, and a step count), and a
   "more coming" notice listing planned topics.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Badge
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  const LockIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "4",
    y: "11",
    width: "16",
    height: "10",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V8a4 4 0 0 1 8 0v3"
  }));

  /* The six cheatsheets. `access`: "free" is open to everyone; "full" needs the
     library subscription. `steps` is the number of steps in the guide. */
  const SHEETS = [{
    n: 1,
    title: "Choosing the right mechanic for your goal",
    access: "full",
    steps: 6,
    desc: "A short decision guide that maps a goal, like activation or retention, to the mechanics worth trying first.",
    tags: ["Onboarding Goal", "Streak", "Leaderboards"],
    href: "#cheatsheet-choosing"
  }, {
    n: 2,
    title: "Adding a streak without punishing lapses",
    access: "free",
    steps: 5,
    desc: "How to build a streak that earns the return without making a single missed day feel like a reason to quit.",
    tags: ["Streak", "Loss Aversion", "Login Calendar"],
    href: "cheatsheet-streak.html"
  }, {
    n: 3,
    title: "Designing a season pass that converts",
    access: "full",
    steps: 9,
    desc: "The structure of a free and paid track that rewards play first and asks for the upgrade once the value is clear.",
    tags: ["Season Pass", "Milestone Rewards", "Cosmetics"]
  }, {
    n: 4,
    title: "Setting up leaderboards people actually use",
    access: "full",
    steps: 7,
    desc: "How to size leagues, set the reset cadence, and tier players so competition stays motivating instead of discouraging.",
    tags: ["Leaderboards", "Tiers / Levels", "Social Challenges"]
  }, {
    n: 5,
    title: "Building a daily reward loop",
    access: "full",
    steps: 6,
    desc: "An escalating reward for opening the app each day, paced so the next session always has a reason to start.",
    tags: ["Daily Reward", "Login Calendar", "Variable Rewards"]
  }, {
    n: 6,
    title: "Running a limited-time event",
    access: "full",
    steps: 8,
    desc: "How to use a short, themed window to concentrate attention and spend without burning out your players.",
    tags: ["Limited-Time Events", "Quests", "Energy / Lives"]
  }];

  /* Planned cheatsheets, shown in the "more coming" notice. */
  const UPCOMING = ["Gifting loops that grow without spam", "Onboarding goals that reach value fast", "Pricing energy and lives fairly", "Referral rewards that pay both sides", "Collections that pull players back", "Quests that point to the right actions"];
  function SheetCard({
    s
  }) {
    const locked = s.access !== "free";
    return /*#__PURE__*/React.createElement("a", {
      className: "csc" + (locked ? " csc--locked" : ""),
      href: locked ? "#subscribe" : s.href || "#subscribe"
    }, /*#__PURE__*/React.createElement("div", {
      className: "csc__top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "csc__index"
    }, "Cheatsheet ", String(s.n).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
      className: "csc__badge"
    }, locked ? /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      variant: "outline",
      icon: LockIcon
    }, "For subscribers") : /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      variant: "soft"
    }, "Free"))), /*#__PURE__*/React.createElement("h3", {
      className: "csc__name"
    }, s.title), /*#__PURE__*/React.createElement("p", {
      className: "csc__desc"
    }, s.desc), /*#__PURE__*/React.createElement("div", {
      className: "csc__tags"
    }, s.tags.map(t => /*#__PURE__*/React.createElement("span", {
      className: "pillchip",
      key: t
    }, t))), /*#__PURE__*/React.createElement("div", {
      className: "csc__foot"
    }, /*#__PURE__*/React.createElement("span", {
      className: "csc__count"
    }, /*#__PURE__*/React.createElement("b", null, s.steps), " steps"), /*#__PURE__*/React.createElement("span", {
      className: "csc__go"
    }, s.access === "free" ? "Open the guide" : "Subscribe to read", " ", ArrowIcon)));
  }

  /** Cheatsheets index: the practitioner's quick reference, six guides plus what's next. */
  function CheatsheetsPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "cs-head",
      "aria-labelledby": "cheat-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#library"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Cheatsheets")), /*#__PURE__*/React.createElement("div", {
      className: "eyebrow cs-head__eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", {
      id: "cheat-h"
    }, "Cheatsheets"), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def"
    }, "Quick, practical guides for putting a mechanic into your product. Each one is a short sequence of steps, drawn from the apps in the library, that takes you from the idea to a version your team can build. Start with the free guide, the rest come with the full library."))), /*#__PURE__*/React.createElement("div", {
      className: "container cs-wrap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-bar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__count"
    }, /*#__PURE__*/React.createElement("b", null, SHEETS.length), " cheatsheets"), /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__hint"
    }, "Updated weekly")), /*#__PURE__*/React.createElement("div", {
      className: "csgrid"
    }, SHEETS.map(s => /*#__PURE__*/React.createElement(SheetCard, {
      key: s.n,
      s: s
    })))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight",
      style: {
        paddingTop: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "comingnote"
    }, /*#__PURE__*/React.createElement("div", {
      className: "comingnote__head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "comingnote__k"
    }, "More coming"), /*#__PURE__*/React.createElement("h2", null, "The next cheatsheets in the queue"), /*#__PURE__*/React.createElement("p", null, "We add guides as the library grows. These are the topics we are writing next, each built the same way, from real implementations.")), /*#__PURE__*/React.createElement("ul", {
      className: "comingnote__list"
    }, UPCOMING.map(t => /*#__PURE__*/React.createElement("li", {
      className: "comingitem",
      key: t
    }, /*#__PURE__*/React.createElement("span", {
      className: "comingitem__soon"
    }, "Planned"), t)))))));
  }
  Object.assign(GBSite, {
    CheatsheetsPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Cheatsheets.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Glossary.jsx
try { (() => {
/* Website kit — Glossary index. Title block plus a grid of term cards, each with
   a term name, a truncated definition, and the mechanics it relates to. Cards
   link to individual glossary item detail pages.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const GBSite = window.GBSite = window.GBSite || {};
  const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));

  /* The 15 terms, alphabetical. `cat` colours the letter marker; `mechanics` are
     the related mechanic tags; the card links to glossary-<slug>.html. */
  const TERMS = [{
    term: "Anchoring",
    cat: "monetization",
    def: "The first number a user sees becomes the reference every later price is judged against. Show the higher tier first and the one you want them to pick reads as a deal.",
    mechanics: ["Season Pass", "Cosmetics"]
  }, {
    term: "Commitment & Consistency",
    cat: "retention",
    def: "Once a user takes a small, visible step, they act to stay consistent with it. A tiny first commitment makes the larger one that follows feel like keeping their word.",
    mechanics: ["Onboarding Goal", "Streak"]
  }, {
    term: "Endowed Progress",
    cat: "retention",
    def: "People work harder toward a goal when handed a head start. A loyalty card stamped twice on day one feels closer to finished than an identical empty one.",
    mechanics: ["Progress Bar", "Login Calendar"]
  }, {
    term: "Flow State",
    cat: "retention",
    def: "The absorbed focus that arrives when challenge and skill stay in balance. Tune difficulty to the user and the next action pulls them along without friction.",
    mechanics: ["Quests / Missions", "Tiers / Levels"]
  }, {
    term: "FOMO",
    cat: "monetization",
    def: "The fear of missing out: the unease that others are getting a reward you won't. A countdown or a limited drop turns idle interest into a reason to act now.",
    mechanics: ["Limited-Time Events", "Daily Reward"]
  }, {
    term: "Fresh Start Effect",
    cat: "retention",
    def: "People are most motivated to pursue goals at temporal landmarks — a Monday, a birthday, a new month. Time a prompt to one and the intent is already there.",
    mechanics: ["Streak", "Season Pass"]
  }, {
    term: "Goal Gradient",
    cat: "retention",
    def: "Effort accelerates as a goal draws closer. The nearer the finish line appears, the faster users move toward it, so make the final stretch feel within reach.",
    mechanics: ["Progress Bar", "Milestone Rewards"]
  }, {
    term: "Loss Aversion",
    cat: "retention",
    def: "A loss hurts about twice as much as the same-size gain feels good. Framing progress as already earned and at risk makes users act to keep it rather than chase more.",
    mechanics: ["Streak", "Energy / Lives"]
  }, {
    term: "Operant Conditioning",
    cat: "retention",
    def: "Behaviour followed by a reward repeats; behaviour followed by nothing fades. The timing and pattern of rewards shape the habit more than their size.",
    mechanics: ["Variable Rewards", "Daily Reward"]
  }, {
    term: "Reciprocity",
    cat: "social",
    def: "A gift creates a quiet pull to give something back. Offer real value first and users grow more willing to subscribe, refer a friend, or return the favour.",
    mechanics: ["Gifting", "Referral Rewards"]
  }, {
    term: "Scarcity",
    cat: "monetization",
    def: "Limited supply or a closing window raises perceived value. When something might run out, users weigh it more heavily and decide faster than they otherwise would.",
    mechanics: ["Limited-Time Events", "Energy / Lives"]
  }, {
    term: "Social Proof",
    cat: "social",
    def: "People read others' behaviour to decide their own. Showing what peers are doing — counts, streaks, leaderboards — lowers the bar to follow along.",
    mechanics: ["Leaderboards", "Social Challenges"]
  }, {
    term: "Sunk Cost",
    cat: "retention",
    def: "The more a user has invested, the harder it becomes to walk away. Visible accumulated progress makes quitting feel like throwing that investment out.",
    mechanics: ["Streak", "Collections / Sets"]
  }, {
    term: "Variable Reward",
    cat: "retention",
    def: "Rewards that vary in size and timing keep the next outcome uncertain. That uncertainty is exactly what makes checking one more time feel worth it.",
    mechanics: ["Mystery Reward", "Variable Rewards"]
  }, {
    term: "Zeigarnik Effect",
    cat: "retention",
    def: "Unfinished tasks linger in the mind more than finished ones. A half-complete profile or progress bar creates a small tension users feel compelled to resolve.",
    mechanics: ["Progress Bar", "Onboarding Goal"]
  }];
  function TermCard({
    t
  }) {
    return /*#__PURE__*/React.createElement("a", {
      className: "gcard",
      href: `glossary-${slug(t.term)}.html`
    }, /*#__PURE__*/React.createElement("div", {
      className: "gcard__top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "gcard__letter",
      style: {
        color: `var(--cat-${t.cat})`
      }
    }, t.term.charAt(0)), /*#__PURE__*/React.createElement("span", {
      className: "gcard__go",
      "aria-hidden": "true"
    }, ArrowIcon)), /*#__PURE__*/React.createElement("h3", {
      className: "gcard__name"
    }, t.term), /*#__PURE__*/React.createElement("p", {
      className: "gcard__def"
    }, t.def), /*#__PURE__*/React.createElement("div", {
      className: "gcard__tags"
    }, t.mechanics.map(m => /*#__PURE__*/React.createElement("span", {
      className: "pillchip",
      key: m
    }, m))));
  }

  /** Glossary index: plain-language definitions, each linked to its mechanics. */
  function GlossaryPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "cs-head",
      "aria-labelledby": "gloss-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Glossary")), /*#__PURE__*/React.createElement("div", {
      className: "eyebrow cs-head__eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", {
      id: "gloss-h"
    }, "Glossary"), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def"
    }, "Plain-language definitions for the psychology behind the mechanics. Every term is the", /*#__PURE__*/React.createElement("i", null, " why"), " under a pattern you'll meet across the library \u2014 the reason a streak holds or a price reads as a deal \u2014 and links straight to the mechanics that put it to work."))), /*#__PURE__*/React.createElement("div", {
      className: "container cs-wrap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-bar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__count"
    }, /*#__PURE__*/React.createElement("b", null, TERMS.length), " terms"), /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__hint"
    }, "Updated weekly")), /*#__PURE__*/React.createElement("div", {
      className: "glossgrid"
    }, TERMS.map(t => /*#__PURE__*/React.createElement(TermCard, {
      key: t.term,
      t: t
    })))));
  }
  Object.assign(GBSite, {
    GlossaryPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Glossary.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/GlossaryDetail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Website kit — Glossary item detail (Loss Aversion). Title block with slug and
   full definition, a "Where you see this in practice" section of linked mechanic
   cards, and a sidebar with related mechanics, more terms, and an export action.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    MechanicCard
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const TERM = {
    term: "Loss Aversion",
    category: "retention",
    categoryLabel: "Retention",
    definition: "Loss aversion is the finding that a loss feels roughly twice as powerful as an equivalent gain — losing ten dollars stings more than finding ten pleases. People will work harder to avoid giving something up than to acquire something of the same value. In products, the lever is framing: once progress, status, or a resource is presented as already belonging to the user, the prospect of losing it becomes a stronger motivator than the promise of more. A streak isn't compelling because of what the next day adds; it's compelling because a missed day takes the whole count away.",
    /* Mechanics that put the principle to work. */
    practice: [{
      number: 1,
      category: "retention",
      name: "Streak / Streak Bonus",
      definition: "The count is framed as something already earned, so a missed day reads as ground given up rather than a reward skipped.",
      contextTags: ["Habit", "Retention"],
      href: "mechanic-streak.html"
    }, {
      number: 9,
      category: "monetization",
      name: "Energy / Lives",
      definition: "Once the resource runs low, users act to avoid losing access to play — fear of being locked out drives the refill.",
      contextTags: ["Pacing", "Games"],
      href: "mechanics.html"
    }, {
      number: 22,
      category: "retention",
      name: "Login Calendar",
      definition: "A grid that fills with each visit turns attendance into a record, and a single gap breaks something the user can see they built.",
      contextTags: ["Habit", "Retention"],
      href: "mechanics.html"
    }],
    relatedMechanics: [{
      name: "Streak / Streak Bonus",
      cat: "retention",
      href: "mechanic-streak.html"
    }, {
      name: "Energy / Lives",
      cat: "monetization",
      href: "mechanics.html"
    }, {
      name: "Login Calendar",
      cat: "retention",
      href: "mechanics.html"
    }, {
      name: "Season Pass",
      cat: "monetization",
      href: "mechanics.html"
    }],
    moreTerms: [{
      name: "Sunk Cost",
      href: "glossary-sunk-cost.html"
    }, {
      name: "Scarcity",
      href: "glossary-scarcity.html"
    }, {
      name: "FOMO",
      href: "glossary-fomo.html"
    }, {
      name: "Endowed Progress",
      href: "glossary-endowed-progress.html"
    }]
  };
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  function TitleBlock() {
    return /*#__PURE__*/React.createElement("section", {
      className: "cs-head sheet-head",
      "aria-labelledby": "term-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("a", {
      href: "glossary.html"
    }, "Glossary"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, TERM.term)), /*#__PURE__*/React.createElement("div", {
      className: "sheet-head__slug"
    }, /*#__PURE__*/React.createElement("span", {
      className: "eyebrow"
    }, "Glossary term"), /*#__PURE__*/React.createElement("span", {
      className: "sheet-head__dot",
      "aria-hidden": "true"
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      className: "eyebrow eyebrow--muted"
    }, TERM.categoryLabel)), /*#__PURE__*/React.createElement("h1", {
      id: "term-h"
    }, TERM.term), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def term-def"
    }, TERM.definition)));
  }
  function Practice() {
    return /*#__PURE__*/React.createElement("section", {
      "aria-labelledby": "practice-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Where you see this in practice"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "practice-h"
    }, "The mechanics that lean on it"), /*#__PURE__*/React.createElement("div", {
      className: "practice-grid"
    }, TERM.practice.map(m => /*#__PURE__*/React.createElement(MechanicCard, _extends({
      key: m.name
    }, m)))));
  }
  function Sidebar() {
    return /*#__PURE__*/React.createElement("aside", {
      className: "mech-aside",
      "aria-label": "Related"
    }, /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Related mechanics"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, TERM.relatedMechanics.map(m => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: m.href,
      key: m.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__dot",
      style: {
        background: `var(--cat-${m.cat})`
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, m.name))))), /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "More terms"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, TERM.moreTerms.map(t => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: t.href,
      key: t.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, t.name)))), /*#__PURE__*/React.createElement("a", {
      className: "amod__viewall",
      href: "glossary.html"
    }, "View all terms ", ArrowIcon)));
  }

  /** Glossary item detail page body. */
  function GlossaryDetailPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement(TitleBlock, null), /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-main"
    }, /*#__PURE__*/React.createElement(Practice, null)), /*#__PURE__*/React.createElement(Sidebar, null))));
  }
  Object.assign(GBSite, {
    GlossaryDetailPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/GlossaryDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeBottom.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Website kit — bottom homepage sections. Loaded as a Babel script; reads DS
   primitives from the namespace, attaches sections to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Button,
    MechanicCard
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const FEATURED = [{
    number: 2,
    category: "retention",
    name: "Streaks",
    definition: "A count of consecutive days a user returns, framed so the count itself feels worth protecting.",
    contextTags: ["Banking", "Health"],
    href: "#"
  }, {
    number: 7,
    category: "social",
    name: "Gifting",
    definition: "Letting users send small, free value to each other, so the app's growth runs on goodwill.",
    contextTags: ["Social", "Commerce"],
    href: "#"
  }, {
    number: 14,
    category: "monetization",
    name: "Cosmetics",
    definition: "Optional visual items players buy to express themselves, with no effect on gameplay balance.",
    contextTags: ["Games", "Social"],
    href: "#"
  }];

  /** Value proposition 1 — the mechanics library: featured mechanics with real
   *  titles, working as a teaser for the full index. */
  function LibraryPreview() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band band--sheet",
      id: "mechanics",
      "aria-labelledby": "lib-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sec-head"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "sec-head__t",
      id: "lib-h"
    }, "Start with the mechanics"), /*#__PURE__*/React.createElement("span", {
      className: "sec-head__aside"
    }, "Each mechanic comes with the psychology behind it, the players it fits, and what your app needs in place to use it well.")), /*#__PURE__*/React.createElement("div", {
      className: "cardgrid"
    }, FEATURED.map(m => /*#__PURE__*/React.createElement(MechanicCard, _extends({
      key: m.name
    }, m)))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 28
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      as: "a",
      href: "#mechanics-index",
      trailingIcon: /*#__PURE__*/React.createElement("i", {
        "data-lucide": "arrow-right"
      })
    }, "Browse all mechanics"))));
  }
  const REPORT_ROWS = [{
    name: "Daily streaks",
    state: "common",
    label: "Common"
  }, {
    name: "Milestone rewards",
    state: "common",
    label: "Common"
  }, {
    name: "Social challenges",
    state: "untapped",
    label: "Untapped"
  }, {
    name: "Loss-framed nudges",
    state: "recommend",
    label: "Try first"
  }, {
    name: "Team leaderboards",
    state: "recommend",
    label: "Try first"
  }];

  /** Value proposition 2 — a custom category report with recommendations for the
   *  visitor's own app. */
  function CategoryReport() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band",
      id: "reports",
      "aria-labelledby": "report-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "showcase"
    }, /*#__PURE__*/React.createElement("div", {
      className: "showcase__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "Custom report"), /*#__PURE__*/React.createElement("h2", {
      id: "report-h"
    }, "Get a report built for your category"), /*#__PURE__*/React.createElement("p", null, "Tell us your app and your industry. We'll show you which mechanics your category already relies on, which ones are still open, and the few worth trying first, each with a recommendation for your product."), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      as: "a",
      href: "#reports-index",
      trailingIcon: /*#__PURE__*/React.createElement("i", {
        "data-lucide": "arrow-right"
      })
    }, "Get your category report")), /*#__PURE__*/React.createElement("div", {
      className: "showcase__map"
    }, /*#__PURE__*/React.createElement("div", {
      className: "report"
    }, /*#__PURE__*/React.createElement("div", {
      className: "report__head"
    }, /*#__PURE__*/React.createElement("span", {
      className: "report__kicker"
    }, "Category report"), /*#__PURE__*/React.createElement("span", {
      className: "report__app"
    }, "Fitness \xB7 your app")), /*#__PURE__*/React.createElement("ul", {
      className: "report__rows"
    }, REPORT_ROWS.map(r => /*#__PURE__*/React.createElement("li", {
      className: "report__row",
      key: r.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "report__name"
    }, r.name), /*#__PURE__*/React.createElement("span", {
      className: `report__pill report__pill--${r.state}`
    }, r.label)))))))));
  }
  const NEW_ITEMS = [{
    title: "Monopoly Go: event pacing breakdown",
    date: "Jun 6, 2026"
  }, {
    title: "Finch: gentle self-care streaks",
    date: "Jun 4, 2026"
  }, {
    title: "BeReal: the social window",
    date: "Jun 2, 2026"
  }, {
    title: "Strava: segment leaderboards",
    date: "May 30, 2026"
  }];

  /** New this week: the latest case study entries, dated. Proves the cadence. */
  function NewThisWeek() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band",
      "aria-labelledby": "new-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sec-head"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "sec-head__t",
      id: "new-h"
    }, "Latest entries")), /*#__PURE__*/React.createElement("div", {
      className: "feed"
    }, NEW_ITEMS.map(it => /*#__PURE__*/React.createElement("a", {
      className: "feed__row",
      href: "#",
      key: it.title
    }, /*#__PURE__*/React.createElement("span", {
      className: "feed__main"
    }, /*#__PURE__*/React.createElement("span", {
      className: "feed__title"
    }, it.title)), /*#__PURE__*/React.createElement("span", {
      className: "feed__date"
    }, it.date))))));
  }
  const ENGAGEMENT = [{
    h: "Discovery",
    p: "We learn your product, your users, and your goals."
  }, {
    h: "Analysis",
    p: "We review your app and your category to find the best openings."
  }, {
    h: "Gamification recommendations for your app",
    p: "An evidence-backed roadmap your team can ship."
  }];

  /** Work with us bridge: short, what the engagement is, one action, with the
   *  three steps numbered on the right. */
  function WorkWithUsBridge() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band band--ink",
      id: "work",
      "aria-labelledby": "work-h",
      style: {
        borderTop: "none"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "workbridge"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "Work with us"), /*#__PURE__*/React.createElement("h2", {
      id: "work-h"
    }, "A practice you can hire, not just a library you can read"), /*#__PURE__*/React.createElement("p", null, "We start from the features you already have, then find the mechanics that fit your app and your users."), /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      as: "a",
      href: "#discovery",
      trailingIcon: /*#__PURE__*/React.createElement("i", {
        "data-lucide": "arrow-up-right"
      })
    }, "Book a discovery call")), /*#__PURE__*/React.createElement("ol", {
      className: "worklist",
      style: {
        listStyle: "none",
        margin: 0,
        padding: 0
      }
    }, ENGAGEMENT.map((t, i) => /*#__PURE__*/React.createElement("li", {
      className: "worklist__item",
      key: t.h
    }, /*#__PURE__*/React.createElement("span", {
      className: "worklist__num",
      "aria-hidden": "true"
    }, i + 1), /*#__PURE__*/React.createElement("span", {
      className: "worklist__text"
    }, /*#__PURE__*/React.createElement("b", null, t.h), /*#__PURE__*/React.createElement("span", null, t.p))))))));
  }
  Object.assign(GBSite, {
    LibraryPreview,
    CategoryReport,
    NewThisWeek,
    WorkWithUsBridge
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeBottom.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeTop.jsx
try { (() => {
/* Website kit — top homepage sections. Loaded as a Babel script; reads DS
   primitives from the namespace, attaches sections to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Button,
    Badge,
    Tag,
    Card,
    AnnotatedScreenshot
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const CAROUSEL = [{
    app: "Duolingo",
    mechanic: "Streaks",
    cat: "retention",
    screen: "Streak screen",
    title: "How Duolingo applies streaks to make returning feel worth it"
  }, {
    app: "Royal Match",
    mechanic: "Daily reward",
    cat: "monetization",
    screen: "Daily reward modal",
    title: "How Royal Match applies daily rewards to open every session"
  }, {
    app: "Monopoly Go",
    mechanic: "Event pacing",
    cat: "monetization",
    screen: "Live event board",
    title: "How Monopoly Go applies timed events to keep momentum up"
  }, {
    app: "Finch",
    mechanic: "Gentle streaks",
    cat: "retention",
    screen: "Daily check-in",
    title: "How Finch applies gentle streaks to build a kind habit"
  }, {
    app: "BeReal",
    mechanic: "Social window",
    cat: "social",
    screen: "Daily window prompt",
    title: "How BeReal applies a daily window to spark posting"
  }, {
    app: "Strava",
    mechanic: "Leaderboards",
    cat: "social",
    screen: "Segment leaderboard",
    title: "How Strava applies leaderboards to turn routes into a friendly race"
  }];

  /** Hero: the promise, in the visitor's language, beside a self-sliding carousel
   *  of real mechanics drawn from the library. */
  function Hero() {
    const loop = CAROUSEL.concat(CAROUSEL);
    return /*#__PURE__*/React.createElement("section", {
      className: "hero",
      id: "top",
      "aria-labelledby": "hero-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container hero__grid"
    }, /*#__PURE__*/React.createElement("div", {
      className: "hero__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow hero__eyebrow"
    }, "Explore gamification options for your app"), /*#__PURE__*/React.createElement("h1", {
      id: "hero-h"
    }, "Power up your app with proven game mechanics"), /*#__PURE__*/React.createElement("p", {
      className: "hero__sub"
    }, "See how the best apps and games turn everyday features into habits. We break down each mechanic, map how they fit together, and help your team apply the ones that suit your product."), /*#__PURE__*/React.createElement("div", {
      className: "hero__cta"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      as: "a",
      href: "#mechanics"
    }, "Explore the library"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      as: "a",
      href: "#work"
    }, "Work with us"))), /*#__PURE__*/React.createElement("div", {
      className: "hero__evidence"
    }, /*#__PURE__*/React.createElement("div", {
      className: "carousel",
      "aria-label": "Mechanics from the library"
    }, /*#__PURE__*/React.createElement("div", {
      className: "carousel__track"
    }, loop.map((m, i) => /*#__PURE__*/React.createElement("article", {
      className: "mcard",
      key: i,
      "aria-hidden": i >= CAROUSEL.length ? "true" : undefined
    }, /*#__PURE__*/React.createElement("div", {
      className: "mcard__shot"
    }, m.app, " \xB7 ", m.screen), /*#__PURE__*/React.createElement("div", {
      className: "mcard__body"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: m.cat,
      dot: true
    }, m.mechanic), /*#__PURE__*/React.createElement("p", {
      className: "mcard__title"
    }, m.title)))))))));
  }
  const APPS = [{
    name: "Duolingo",
    mark: "Du"
  }, {
    name: "Royal Match",
    mark: "RM"
  }, {
    name: "Monopoly Go",
    mark: "MG"
  }, {
    name: "Finch",
    mark: "Fi"
  }, {
    name: "BeReal",
    mark: "Be"
  }, {
    name: "Strava",
    mark: "St"
  }, {
    name: "Headspace",
    mark: "Hs"
  }, {
    name: "Revolut",
    mark: "Re"
  }, {
    name: "Calm",
    mark: "Ca"
  }, {
    name: "Notion",
    mark: "No"
  }];

  /** Logo strip: a sample of the apps studied in the library, as 60×60 marks. */
  function LogoStrip() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band band--tight band--sheet",
      "aria-label": "Apps in the library"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("p", {
      className: "logostrip__lead"
    }, "A few of the apps in the library"), /*#__PURE__*/React.createElement("div", {
      className: "logostrip"
    }, APPS.map(a => /*#__PURE__*/React.createElement("span", {
      className: "applogo",
      key: a.name,
      role: "img",
      "aria-label": a.name,
      title: a.name
    }, a.mark)))));
  }
  const LIB = [{
    count: "25",
    h: "Case studies",
    p: "Full breakdowns of how real apps build engagement, mechanic by mechanic.",
    link: "Browse case studies",
    href: "#case-studies"
  }, {
    count: "25",
    h: "Systems",
    p: "How mechanics combine into the loops that keep players coming back.",
    link: "Explore systems",
    href: "#systems"
  }, {
    count: "6",
    h: "Cheatsheets",
    p: "Practical implementation guides your team can build straight from.",
    link: "Open cheatsheets",
    href: "#cheatsheets"
  }];

  /** Library contents: what's inside, as three counted cards. */
  function LibraryContents() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band",
      id: "library",
      "aria-labelledby": "lib-contents-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sec-head"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "sec-head__t",
      id: "lib-contents-h"
    }, "What's inside the library")), /*#__PURE__*/React.createElement("div", {
      className: "libgrid"
    }, LIB.map(c => /*#__PURE__*/React.createElement(Card, {
      key: c.h,
      className: "libcard"
    }, /*#__PURE__*/React.createElement("div", {
      className: "libcard__count"
    }, c.count), /*#__PURE__*/React.createElement("h3", null, c.h), /*#__PURE__*/React.createElement("p", null, c.p), /*#__PURE__*/React.createElement("a", {
      className: "libcard__link",
      href: c.href
    }, c.link, " ", /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right"
    })))))));
  }

  /** Free case study spotlight: Royal Match, open to everyone. The transitional
   *  call to action, with a screenshot and a line describing it. */
  function CaseStudySpotlight() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band band--sunken",
      id: "case-studies",
      "aria-labelledby": "spot-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "spotlight"
    }, /*#__PURE__*/React.createElement("div", {
      className: "spotlight__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "Free case study"), /*#__PURE__*/React.createElement("h2", {
      id: "spot-h"
    }, "See exactly what a full breakdown looks like"), /*#__PURE__*/React.createElement("div", {
      className: "spotlight__meta"
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "accent",
      variant: "solid"
    }, "Free"), /*#__PURE__*/React.createElement(Tag, {
      category: "monetization",
      dot: true
    }, "Monetization"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data)",
        fontSize: 12,
        color: "var(--text-muted)"
      }
    }, "Royal Match \xB7 analyzed Jun 2026")), /*#__PURE__*/React.createElement("p", null, "Royal Match keeps players coming back without a single leaderboard. We mapped every mechanic it uses, why each one works, and what your app needs in place to borrow it well. The whole breakdown is open, no account required."), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      as: "a",
      href: "#royal-match",
      trailingIcon: /*#__PURE__*/React.createElement("i", {
        "data-lucide": "arrow-up-right"
      })
    }, "Read the Royal Match breakdown")), /*#__PURE__*/React.createElement("div", {
      className: "spotlight__evidence"
    }, /*#__PURE__*/React.createElement(AnnotatedScreenshot, {
      appName: "Royal Match",
      screenLabel: "Daily reward modal",
      date: "Analyzed Jun 2026",
      alt: "Royal Match daily reward",
      caption: "The daily reward lands the moment the screen opens, so the next session already has a reason to start."
    })))));
  }
  Object.assign(GBSite, {
    Hero,
    LogoStrip,
    LibraryContents,
    CaseStudySpotlight
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeTop.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/IndustryReport.jsx
try { (() => {
/* Website kit — Industry report intro chapter (Finance Apps). The opening chapter
   of a multi-part report: a floating chapter nav, the header and overview, the ten
   apps analyzed, the headline findings, per-mechanic observations, two short
   narrative sections, the five goal chapters as cards, and next-chapter nav.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const GBSite = window.GBSite = window.GBSite || {};
  const CAT_COLOR = {
    retention: "var(--cat-retention)",
    monetization: "var(--cat-monetization)",
    social: "var(--cat-social)"
  };
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  const RightIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }));
  const APPS = [{
    ab: "Rv",
    name: "Revolut",
    cat: "Neobank"
  }, {
    ab: "Mo",
    name: "Monzo",
    cat: "Neobank"
  }, {
    ab: "Ch",
    name: "Chime",
    cat: "Neobank"
  }, {
    ab: "Nu",
    name: "Nubank",
    cat: "Neobank"
  }, {
    ab: "Ac",
    name: "Acorns",
    cat: "Micro-investing"
  }, {
    ab: "Rb",
    name: "Robinhood",
    cat: "Investing"
  }, {
    ab: "Cl",
    name: "Cleo",
    cat: "Budgeting assistant"
  }, {
    ab: "Pl",
    name: "Plum",
    cat: "Savings"
  }, {
    ab: "YN",
    name: "YNAB",
    cat: "Expense tracker"
  }, {
    ab: "Sp",
    name: "Step",
    cat: "Teen banking"
  }];
  const STATS = [{
    value: "10",
    label: "Apps analyzed"
  }, {
    value: "14",
    label: "Mechanics observed"
  }, {
    value: "6",
    label: "Used by the majority"
  }, {
    value: "3",
    label: "Barely touched"
  }];
  const OBSERVATIONS = [{
    name: "Progress Bar",
    cat: "retention",
    prevalence: "9 of 10 apps",
    desc: "Almost every app visualizes a savings goal or a budget as a bar. It is the category's default way to make an abstract balance feel close enough to act on."
  }, {
    name: "Milestone Rewards",
    cat: "retention",
    prevalence: "7 of 10 apps",
    desc: "Goal thresholds, round-number balances, and the first thousand saved are marked with a small celebration that gives the number meaning beyond the figure itself."
  }, {
    name: "Streak / Streak Bonus",
    cat: "retention",
    prevalence: "5 of 10 apps",
    desc: "Half the set rewards consecutive days of saving or logging a transaction, borrowing the daily-habit loop almost directly from consumer apps outside finance."
  }, {
    name: "Loss Aversion",
    cat: "retention",
    prevalence: "4 of 10 apps",
    desc: "A few apps frame a broken streak or a missed round-up as something already earned and given up, rather than a neutral action simply skipped."
  }, {
    name: "Variable Rewards",
    cat: "monetization",
    prevalence: "3 of 10 apps",
    desc: "Surprise cashback and randomized boosts appear in a handful of apps, concentrated around deposits and referrals where the uncertainty does the most work."
  }, {
    name: "Leaderboards",
    cat: "social",
    prevalence: "2 of 10 apps",
    desc: "Rare, and used cautiously. Ranking money behaviour against peers sits uneasily in a category built on privacy, so where it appears it is opt-in and anonymized."
  }];
  const GOALS = [{
    n: 1,
    title: "Activation",
    desc: "Get a nervous first-time user to their first meaningful action.",
    href: "report-finance-goal-1.html"
  }, {
    n: 2,
    title: "Habit",
    desc: "Turn an occasional check-in into a daily or weekly routine.",
    href: "report-finance-goal-2.html"
  }, {
    n: 3,
    title: "Saving",
    desc: "Make putting money aside feel rewarding rather than restrictive.",
    href: "report-finance-goal-3.html"
  }, {
    n: 4,
    title: "Engagement",
    desc: "Keep users exploring features beyond the balance screen.",
    href: "report-finance-goal-4.html"
  }, {
    n: 5,
    title: "Advocacy",
    desc: "Turn satisfied users into referrers and reviewers.",
    href: "report-finance-goal-5.html"
  }];

  /* Floating chapter nav: intro (current), the five goal chapters, takeaways. */
  const NAV = [{
    label: "Introduction",
    href: "#intro",
    current: true
  }, ...GOALS.map(g => ({
    n: String(g.n).padStart(2, "0"),
    label: g.title,
    href: g.href,
    sub: true
  })), {
    label: "Takeaways",
    href: "report-finance-takeaways.html"
  }];
  function ChapterNav() {
    return /*#__PURE__*/React.createElement("aside", {
      className: "cs-toc",
      "aria-label": "Report chapters"
    }, /*#__PURE__*/React.createElement("a", {
      className: "cs-toc__back",
      href: "index.html#reports"
    }, "\u2190", " All reports"), /*#__PURE__*/React.createElement("div", {
      className: "cs-toc__label"
    }, "Finance Apps ", "\u00b7", " 2026"), /*#__PURE__*/React.createElement("nav", {
      className: "cs-toc__nav"
    }, NAV.map(t => /*#__PURE__*/React.createElement("a", {
      key: t.label,
      href: t.href,
      className: "cs-toc__link" + (t.sub ? " cs-toc__link--sub" : "") + (t.current ? " is-active" : "")
    }, t.n ? /*#__PURE__*/React.createElement("span", {
      className: "cs-toc__n"
    }, t.n) : null, t.label))));
  }

  /** Industry report intro chapter body. */
  function IndustryReportPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-layout"
    }, /*#__PURE__*/React.createElement(ChapterNav, null), /*#__PURE__*/React.createElement("div", {
      className: "cs-main"
    }, /*#__PURE__*/React.createElement("header", {
      className: "ir-hd",
      id: "intro"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html#reports"
    }, "Reports"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Finance Apps")), /*#__PURE__*/React.createElement("div", {
      className: "rpt-label"
    }, "Industry Report ", "\u00b7", " 2026"), /*#__PURE__*/React.createElement("h1", {
      className: "ir-hd__title"
    }, "Gamification across finance apps"), /*#__PURE__*/React.createElement("div", {
      className: "ir-overview"
    }, /*#__PURE__*/React.createElement("p", null, "We pulled apart ten of the finance apps people open most and read each one against the twenty-two-mechanic framework. This opening chapter sets out what the category looks like as a whole: which mechanics have become table stakes, which remain rare, and where the honest openings are for a product willing to move first."), /*#__PURE__*/React.createElement("p", null, "The rest of the report is organized by goal rather than by app. Each chapter takes one thing a finance product is usually trying to do, from activating a nervous newcomer to earning a referral, and shows the mechanics that serve it best, with examples drawn from the apps below."))), /*#__PURE__*/React.createElement("section", {
      className: "ir-sec",
      "aria-labelledby": "apps-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "The 10 apps we analyzed"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "apps-h"
    }, "A cross-section of the category"), /*#__PURE__*/React.createElement("div", {
      className: "ir-apps"
    }, APPS.map(a => /*#__PURE__*/React.createElement("div", {
      className: "ir-appcard",
      key: a.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "ir-appcard__icon",
      "aria-hidden": "true"
    }, a.ab), /*#__PURE__*/React.createElement("span", {
      className: "ir-appcard__name"
    }, a.name), /*#__PURE__*/React.createElement("span", {
      className: "ir-appcard__cat"
    }, a.cat))))), /*#__PURE__*/React.createElement("section", {
      className: "ir-sec",
      "aria-labelledby": "found-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What we found"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "found-h"
    }, "The shape of the category"), /*#__PURE__*/React.createElement("div", {
      className: "ir-stats"
    }, STATS.map(s => /*#__PURE__*/React.createElement("div", {
      className: "rpt-stat",
      key: s.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__num"
    }, s.value), /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__label"
    }, s.label)))), /*#__PURE__*/React.createElement("div", {
      className: "ir-obs"
    }, OBSERVATIONS.map(o => /*#__PURE__*/React.createElement("div", {
      className: "ir-ob",
      key: o.name
    }, /*#__PURE__*/React.createElement("div", {
      className: "ir-ob__head"
    }, /*#__PURE__*/React.createElement("span", {
      className: "ir-ob__dot",
      style: {
        background: CAT_COLOR[o.cat]
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "ir-ob__name"
    }, o.name), /*#__PURE__*/React.createElement("span", {
      className: "ir-ob__prev"
    }, o.prevalence)), /*#__PURE__*/React.createElement("p", {
      className: "ir-ob__desc"
    }, o.desc))))), /*#__PURE__*/React.createElement("section", {
      className: "ir-sec",
      "aria-labelledby": "mean-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What this means"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "mean-h"
    }, "A category that gamifies progress, not competition"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose ir-prose"
    }, /*#__PURE__*/React.createElement("p", null, "Finance apps have settled on a narrow, comfortable slice of the framework. The mechanics that show progress \u2014 bars, milestones, the occasional streak \u2014 are everywhere, because they map cleanly onto money goals and carry no real risk to trust. The mechanics that involve other people, or chance, are treated with caution."), /*#__PURE__*/React.createElement("p", null, "That caution is mostly warranted, but it has left real ground unused. Social and variable-reward mechanics are rare precisely because they are hard to do tastefully in finance, which is exactly why an app that gets them right has so little company."))), /*#__PURE__*/React.createElement("section", {
      className: "ir-sec",
      "aria-labelledby": "how-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "How to read this report"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "how-h"
    }, "Start with your goal, not your roadmap"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose ir-prose"
    }, /*#__PURE__*/React.createElement("p", null, "Each of the five chapters ahead is built around a single goal. Find the one closest to what your product is trying to do right now, and read that chapter first. Every mechanic in it is rated for how well it fits the goal and how novel it would feel in finance, with a real example from one of the ten apps."))), /*#__PURE__*/React.createElement("section", {
      className: "ir-sec",
      "aria-labelledby": "chapters-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "The chapters"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "chapters-h"
    }, "Five goals"), /*#__PURE__*/React.createElement("div", {
      className: "ir-goals"
    }, GOALS.map(g => /*#__PURE__*/React.createElement("a", {
      className: "ir-goalcard",
      href: g.href,
      key: g.n
    }, /*#__PURE__*/React.createElement("span", {
      className: "ir-goalcard__k"
    }, "Goal ", g.n), /*#__PURE__*/React.createElement("span", {
      className: "ir-goalcard__t"
    }, g.title), /*#__PURE__*/React.createElement("span", {
      className: "ir-goalcard__d"
    }, g.desc), /*#__PURE__*/React.createElement("span", {
      className: "ir-goalcard__go",
      "aria-hidden": "true"
    }, ArrowIcon))))), /*#__PURE__*/React.createElement("a", {
      className: "ir-next",
      href: GOALS[0].href
    }, /*#__PURE__*/React.createElement("span", {
      className: "ir-next__k"
    }, "Next chapter"), /*#__PURE__*/React.createElement("span", {
      className: "ir-next__t"
    }, "Goal 1: ", GOALS[0].title, " ", RightIcon))))));
  }
  Object.assign(GBSite, {
    IndustryReportPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/IndustryReport.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/LockedState.jsx
try { (() => {
/* Website kit — Locked-content state. The treatment a free visitor meets at gated
   content anywhere in the library: a real preview that fades out, then an
   invitation (never a wall). Reuses the DS LockedNotice. Never says "locked",
   "denied", or "premium". The visitor can always keep browsing what's free.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Tag,
    LockedNotice
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};

  /** Locked-content state, shown as it appears in context (a Duolingo breakdown). */
  function LockedStatePage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "lock-wrap"
    }, /*#__PURE__*/React.createElement("header", {
      className: "cs-hd"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "case-studies.html"
    }, "Case studies"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Duolingo"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Full breakdown")), /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__icon",
      "aria-hidden": "true"
    }, "Du"), /*#__PURE__*/React.createElement("div", {
      className: "cs-hd__heads"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: "neutral",
      variant: "outline"
    }, "Language app"), /*#__PURE__*/React.createElement("h1", {
      className: "cs-hd__title"
    }, "Duolingo ", "\u2014", " Full Breakdown"))), /*#__PURE__*/React.createElement("p", {
      className: "cs-hd__overview"
    }, "Duolingo turns a daily lesson into a habit almost no other app sustains, and it does it with a handful of mechanics working in close concert. This breakdown takes the live app apart piece by piece: the streak and the loss aversion that protects it, the hearts that meter practice, the leagues that turn solo study into standing.")), /*#__PURE__*/React.createElement("div", {
      className: "lock-preview"
    }, /*#__PURE__*/React.createElement("section", {
      className: "lock-sec"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Mechanic 01"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title"
    }, "The streak, and what holds it up"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose lock-prose"
    }, /*#__PURE__*/React.createElement("p", null, "The streak is the most visible thing in the app, and deliberately so. It sits at the top of the home screen as a single number with a flame beside it, and that number is framed not as something you are building but as something you already have. The distinction matters: a count you have earned is a count you can lose, and Duolingo leans on exactly that."), /*#__PURE__*/React.createElement("p", null, "Each completed lesson ticks the streak forward by one. Miss a day and the whole count resets to zero, a consequence the app makes sure you understand well before you are at risk of it. The result is that the cost of skipping a day rises with every day you practice, so the longer your streak, the harder it becomes to break."), /*#__PURE__*/React.createElement("p", null, "Underneath the streak sits a quieter mechanic doing most of the work: loss aversion. The streak would be far weaker if it only promised a reward for returning. What makes it effective is that it frames a missed day as a loss of something concrete and already yours, and a loss looms larger than an equivalent gain."))), /*#__PURE__*/React.createElement("div", {
      className: "lock-fade",
      "aria-hidden": "true"
    })), /*#__PURE__*/React.createElement("div", {
      className: "lock-invite"
    }, /*#__PURE__*/React.createElement(LockedNotice, {
      title: "This breakdown is part of the full library",
      primaryLabel: "Subscribe for full access",
      primaryHref: "subscribe.html",
      secondaryLabel: "Read the free case study first",
      secondaryHref: "case-study-royal-match.html"
    }, "The rest of this breakdown walks every mechanic in the Duolingo system, with annotated screenshots, the connections between them, and what your product needs in place to borrow each one. New breakdowns land every week.")))));
  }
  Object.assign(GBSite, {
    LockedStatePage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/LockedState.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Login.jsx
try { (() => {
/* Website kit — Log in page. Minimal to the point of austerity: email + password,
   a Log in button, a forgot-password link, and one quiet line for non-members.
   No imagery, no marketing copy. Email-based entry only (no third-party login).
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Button,
    Input
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const LOGO_INK = "../../assets/logo/gamebiz-logo-ink.svg";
  const MailIcon = /*#__PURE__*/React.createElement("i", {
    "data-lucide": "mail"
  });
  const LockIcon = /*#__PURE__*/React.createElement("i", {
    "data-lucide": "lock"
  });

  /** Log in page — a returning subscriber coming back to a tool. */
  function LoginPage() {
    return /*#__PURE__*/React.createElement("main", {
      className: "login",
      id: "main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "login__card"
    }, /*#__PURE__*/React.createElement("a", {
      className: "login__brand",
      href: "index.html",
      "aria-label": "GameBiz home"
    }, /*#__PURE__*/React.createElement("img", {
      src: window.__resources && window.__resources.gbLogoInk || LOGO_INK,
      alt: "GameBiz",
      width: "124",
      height: "25"
    })), /*#__PURE__*/React.createElement("form", {
      className: "login__form",
      onSubmit: e => e.preventDefault()
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Email",
      size: "lg",
      type: "email",
      required: true,
      placeholder: "you@company.com",
      leadingIcon: MailIcon,
      autoComplete: "email"
    }), /*#__PURE__*/React.createElement("div", {
      className: "login__pw"
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Password",
      size: "lg",
      type: "password",
      required: true,
      placeholder: "Your password",
      leadingIcon: LockIcon,
      autoComplete: "current-password"
    }), /*#__PURE__*/React.createElement("a", {
      className: "login__forgot",
      href: "#reset"
    }, "Forgot password")), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      type: "submit",
      className: "login__submit"
    }, "Log in"))), /*#__PURE__*/React.createElement("p", {
      className: "login__alt"
    }, "Not a subscriber yet? ", /*#__PURE__*/React.createElement("a", {
      href: "subscribe.html"
    }, "See what's inside")));
  }
  Object.assign(GBSite, {
    LoginPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MechanicDetail.jsx
try { (() => {
/* Website kit — Mechanic detail page (Streak / Streak Bonus).
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Tag
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

  /* ---- inline icons (static page, but inline SVG is re-render safe) ---- */
  const IconKey = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "7.5",
    cy: "15.5",
    r: "4.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10.7 12.3 21 2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m16 7 3 3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m18 5 3 3"
  }));
  const IconAlert = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "9",
    x2: "12",
    y2: "13"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "17",
    x2: "12.01",
    y2: "17"
  }));
  const IconArrow = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }));

  /* ---- mechanic content ---- */
  const MECH = {
    n: 1,
    name: "Streak / Streak Bonus",
    category: "retention",
    categoryLabel: "Retention",
    definition: "A counter that increments each time a user completes a defined action within a set time window, typically once per day. Miss the window and the count resets.",
    bestFor: [{
      label: "Achiever",
      color: "var(--cat-social)"
    }, {
      label: "Competitor",
      color: "var(--red-600)"
    }],
    context: ["Activation", "Retention", "Habit"],
    drivers: ["Consistency", "Loss aversion", "Progress"],
    how: "A streak turns a string of repeated actions into a single number worth protecting. Each day a user completes the target action, the count climbs; miss the window and it resets to zero. The mechanic works because the growing number reframes a daily choice as something the user has already invested in — the longer the streak, the more there is to keep by continuing, and the easier it is to justify one more day.",
    principle: "The value isn't a reward at the end — it's the count itself. Once a streak is long enough to feel earned, protecting it becomes its own motivation.",
    watch: "A reset that feels unfair can end the habit for good. Without a freeze or repair option, one missed day can turn a committed user into a churned one.",
    variants: [{
      name: "Simple streak",
      desc: "A single consecutive-day counter tied to one core action. The clearest version, and the easiest to grasp at a glance."
    }, {
      name: "Streak freeze / repair",
      desc: "A safety net that pauses or restores a streak after a miss, protecting the user's investment when life gets in the way."
    }, {
      name: "Streak milestones",
      desc: "Rewards or new visuals unlocked at thresholds like 7, 30, and 100 days, giving the count fresh meaning as it grows."
    }, {
      name: "Per-habit streaks",
      desc: "Separate streaks for each tracked activity, so progress in one area never depends on another."
    }],
    lifecycle: "Streaks earn their keep just after activation — once a user has felt the core value, but before the habit is set. Introduce one too early and there's nothing to protect; too late and the routine is already formed.",
    pairedWith: [{
      name: "Daily Reward",
      cat: "retention"
    }, {
      name: "Loss Aversion",
      cat: "retention"
    }, {
      name: "Milestone Rewards",
      cat: "retention"
    }, {
      name: "Login Calendar",
      cat: "retention"
    }],
    playerTypes: [{
      label: "Achiever",
      color: "var(--cat-social)",
      note: "primary fit"
    }, {
      label: "Competitor",
      color: "var(--red-600)",
      note: "with leaderboards"
    }]
  };
  const NARR = ["How they use it", "Why it works", "The detail", "Takeaway"];
  const STUDIES = [{
    app: "Duolingo",
    cat: "Education",
    screens: ["Streak counter", "Streak freeze", "Day 365"],
    body: ["The streak counter sits in the corner of every screen and fires a celebration the moment a lesson is finished.", "Lessons are short, so the bar to keep a streak alive is low — which makes the growing count feel almost free to protect.", "Streak Freeze and a weekend amnesty quietly forgive the occasional miss, keeping long streaks from collapsing on one bad day.", "Pair an easy daily target with a forgiving safety net, and a streak can run for years."]
  }, {
    app: "Snapchat",
    cat: "Social",
    screens: ["Friend flames", "Streak count", "Expiry timer"],
    body: ["Snapstreaks count the consecutive days two friends exchange snaps, shown as a flame and a number beside a name.", "The streak belongs to a relationship, not one person — so social obligation, not just habit, keeps it alive.", "An hourglass warns when a streak is about to expire, prompting a last-minute snap to save it.", "Tie a streak to another person and you add accountability the app never has to enforce itself."]
  }, {
    app: "Headspace",
    cat: "Health",
    screens: ["Home streak", "Milestone", "Run streak"],
    body: ["A run streak counts consecutive days a user completes any meditation, surfaced on the home tab.", "It reframes a calm, optional practice as a commitment worth keeping, nudging the next session.", "Milestones at 10, 30 and 100 days mark the journey without punishing a missed day too harshly.", "Even gentle, wellbeing-first products can use streaks — as long as the tone stays encouraging."]
  }, {
    app: "Finch",
    cat: "Health",
    screens: ["Pet home", "Daily goals", "Streak summary"],
    body: ["Daily self-care goals build a streak that helps a virtual pet grow, tying the count to a character.", "Caring for the pet, not raw discipline, carries the habit — the streak feels like nurture, not pressure.", "Missed days are framed kindly, with no harsh reset language, protecting users having a hard week.", "A streak wrapped in care can motivate the exact users a competitive streak would scare off."]
  }, {
    app: "Strava",
    cat: "Fitness",
    screens: ["Weekly streak", "Activity log", "Challenge"],
    body: ["Weekly and monthly activity streaks reward athletes for logging a minimum amount of training.", "For committed athletes the streak aligns with goals they already hold — it amplifies intent rather than inventing it.", "Streaks live alongside challenges and kudos, so social proof reinforces the personal count.", "When users already want the behavior, a streak turns motivation into measurable momentum."]
  }, {
    app: "Apple Fitness",
    cat: "Health",
    screens: ["Activity rings", "Awards", "Perfect month"],
    body: ["Closing all three activity rings every day builds a streak, with awards for perfect weeks and months.", "The rings make the daily goal visual and unambiguous — you can see at a glance whether today counts.", "Monthly and special-event awards give the streak fresh targets beyond the daily close.", "A clear, visual daily goal makes the streak self-explanatory and hard to ignore."]
  }, {
    app: "Habitica",
    cat: "Productivity",
    screens: ["Dailies", "Character", "Streak count"],
    body: ["Habits and dailies build streaks that feed an RPG character's stats, health and gold.", "Breaking a streak costs the character real in-game health, making the stakes feel tangible.", "Players can buy back missed days or schedule rest, softening the penalty for planned breaks.", "Attach a streak to something the user has invested in, and a miss carries genuine weight."]
  }, {
    app: "BeReal",
    cat: "Social",
    screens: ["Daily prompt", "Profile streak", "Calendar"],
    body: ["Posting every day when the notification fires builds a streak shown on the profile.", "The single daily window makes the action specific and shared — everyone's streak ticks at once.", "Miss the window and the streak ends, keeping the once-a-day promise honest.", "A fixed daily moment turns a streak into a shared ritual rather than a private grind."]
  }, {
    app: "Calm",
    cat: "Health",
    screens: ["Daily streak", "Session list", "Reminder"],
    body: ["A daily streak tracks consecutive days with any session — a meditation, a Sleep Story, or a breathe exercise.", "Counting any session, not one specific act, keeps the streak easy to maintain and low-pressure.", "Gentle reminders and a visible count nudge the next session without nagging.", "Broaden what counts toward a streak and more users keep it alive."]
  }, {
    app: "Forest",
    cat: "Productivity",
    screens: ["Focus timer", "Forest view", "Streak stats"],
    body: ["Consecutive days of focused sessions grow a streak alongside a forest of planted trees.", "The streak and the growing forest are two views of the same effort, doubling the sense of progress.", "Leaving a focus session early withers a tree, making the cost of breaking concentration visible.", "Visualize the streak as something that accumulates, and the progress becomes its own reward."]
  }, {
    app: "WaterMinder",
    cat: "Health",
    screens: ["Daily goal", "Hydration log", "Streak ring"],
    body: ["Meeting a daily hydration goal builds a streak shown beside the day's water total.", "A concrete, measurable goal makes 'did today count?' a simple yes or no.", "Reminders through the day keep the goal — and the streak — top of mind.", "Clear, quantifiable daily goals make even the simplest streak effective."]
  }];
  function Overview() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band--tight mech-head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html"
    }, "Home"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep"
    }, "/"), /*#__PURE__*/React.createElement("a", {
      href: "mechanics.html"
    }, "Mechanics"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep"
    }, "/"), /*#__PURE__*/React.createElement("span", null, MECH.name)), /*#__PURE__*/React.createElement("div", {
      className: "mech-head__tagrow"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mech-head__num"
    }, String(MECH.n).padStart(2, "0")), /*#__PURE__*/React.createElement(Tag, {
      category: MECH.category
    }, MECH.categoryLabel)), /*#__PURE__*/React.createElement("h1", null, MECH.name), /*#__PURE__*/React.createElement("p", {
      className: "mech-head__def"
    }, MECH.definition), /*#__PURE__*/React.createElement("div", {
      className: "metarow"
    }, /*#__PURE__*/React.createElement("div", {
      className: "metacol"
    }, /*#__PURE__*/React.createElement("span", {
      className: "metacol__label"
    }, "Best for"), /*#__PURE__*/React.createElement("div", {
      className: "metachips"
    }, MECH.bestFor.map(p => /*#__PURE__*/React.createElement("span", {
      className: "metachip",
      key: p.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "metachip__dot",
      style: {
        background: p.color
      }
    }), p.label)))), /*#__PURE__*/React.createElement("div", {
      className: "metacol"
    }, /*#__PURE__*/React.createElement("span", {
      className: "metacol__label"
    }, "Context"), /*#__PURE__*/React.createElement("div", {
      className: "metachips"
    }, MECH.context.map(c => /*#__PURE__*/React.createElement("span", {
      className: "metachip",
      key: c
    }, c)))), /*#__PURE__*/React.createElement("div", {
      className: "metacol"
    }, /*#__PURE__*/React.createElement("span", {
      className: "metacol__label"
    }, "Motivation drivers"), /*#__PURE__*/React.createElement("div", {
      className: "metachips"
    }, MECH.drivers.map(d => /*#__PURE__*/React.createElement("span", {
      className: "metachip",
      key: d
    }, d)))))));
  }
  function HowItWorks() {
    return /*#__PURE__*/React.createElement("section", {
      "aria-labelledby": "how-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "How it works"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "how-h"
    }, "One number, worth protecting"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose"
    }, /*#__PURE__*/React.createElement("p", null, MECH.how)), /*#__PURE__*/React.createElement("div", {
      className: "callouts"
    }, /*#__PURE__*/React.createElement("div", {
      className: "callout callout--principle"
    }, /*#__PURE__*/React.createElement("span", {
      className: "callout__label"
    }, IconKey, " Core principle"), /*#__PURE__*/React.createElement("p", null, MECH.principle)), /*#__PURE__*/React.createElement("div", {
      className: "callout callout--watch"
    }, /*#__PURE__*/React.createElement("span", {
      className: "callout__label"
    }, IconAlert, " Watch out for"), /*#__PURE__*/React.createElement("p", null, MECH.watch))));
  }
  function Variants() {
    return /*#__PURE__*/React.createElement("section", {
      "aria-labelledby": "var-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Structural variants"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "var-h"
    }, "Four ways to build it"), /*#__PURE__*/React.createElement("div", {
      className: "variants"
    }, MECH.variants.map((v, i) => /*#__PURE__*/React.createElement("div", {
      className: "variant",
      key: v.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "variant__n"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, v.name), /*#__PURE__*/React.createElement("p", null, v.desc))))));
  }
  function Lifecycle() {
    return /*#__PURE__*/React.createElement("section", {
      className: "lifecycle",
      "aria-label": "Lifecycle placement"
    }, /*#__PURE__*/React.createElement("div", {
      className: "lifecycle__label"
    }, "Lifecycle placement"), /*#__PURE__*/React.createElement("p", null, MECH.lifecycle));
  }
  function CaseStudies() {
    return /*#__PURE__*/React.createElement("section", {
      "aria-labelledby": "cs-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Case studies \xB7 ", STUDIES.length), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "cs-h"
    }, "Seen in the wild"), /*#__PURE__*/React.createElement("div", {
      className: "cstudies"
    }, STUDIES.map(s => /*#__PURE__*/React.createElement("article", {
      className: "cstudy",
      id: `cstudy-${slug(s.app)}`,
      key: s.app
    }, /*#__PURE__*/React.createElement("div", {
      className: "cstudy__head"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cstudy__app"
    }, s.app), /*#__PURE__*/React.createElement(Tag, {
      category: "neutral"
    }, s.cat)), /*#__PURE__*/React.createElement("div", {
      className: "cstudy__thumbs"
    }, s.screens.map(sc => /*#__PURE__*/React.createElement("div", {
      className: "cthumb",
      key: sc
    }, sc))), /*#__PURE__*/React.createElement("div", {
      className: "cstudy__narr"
    }, s.body.map((b, i) => /*#__PURE__*/React.createElement("div", {
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      className: "narr__label"
    }, NARR[i]), /*#__PURE__*/React.createElement("p", null, b)))), /*#__PURE__*/React.createElement("div", {
      className: "cstudy__foot"
    }, /*#__PURE__*/React.createElement("a", {
      className: "cstudy__link",
      href: `#cstudy-${slug(s.app)}`
    }, "View full case study ", IconArrow))))));
  }
  function Sidebar() {
    return /*#__PURE__*/React.createElement("aside", {
      className: "mech-aside",
      "aria-label": "Related"
    }, /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Often paired with"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, MECH.pairedWith.map(m => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: "mechanics.html",
      key: m.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__dot",
      style: {
        background: `var(--cat-${m.cat})`
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, m.name))))), /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Player types"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, MECH.playerTypes.map(p => /*#__PURE__*/React.createElement("div", {
      className: "amod__item",
      key: p.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__dot",
      style: {
        background: p.color
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, p.label), /*#__PURE__*/React.createElement("span", {
      className: "amod__meta"
    }, p.note))))), /*#__PURE__*/React.createElement("div", {
      className: "amod"
    }, /*#__PURE__*/React.createElement("h3", null, "Seen in"), /*#__PURE__*/React.createElement("div", {
      className: "amod__list"
    }, STUDIES.map(s => /*#__PURE__*/React.createElement("a", {
      className: "amod__item",
      href: `#cstudy-${slug(s.app)}`,
      key: s.app
    }, /*#__PURE__*/React.createElement("span", {
      className: "amod__name"
    }, s.app), /*#__PURE__*/React.createElement("span", {
      className: "amod__meta"
    }, s.cat))))));
  }

  /** Mechanic detail page body. */
  function MechanicDetailPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement(Overview, null), /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-main"
    }, /*#__PURE__*/React.createElement(HowItWorks, null), /*#__PURE__*/React.createElement(Variants, null), /*#__PURE__*/React.createElement(Lifecycle, null), /*#__PURE__*/React.createElement(CaseStudies, null)), /*#__PURE__*/React.createElement(Sidebar, null))));
  }
  Object.assign(GBSite, {
    MechanicDetailPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MechanicDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MechanicsLibrary.jsx
try { (() => {
/* Website kit — Mechanics Library page. Floating filters + 2-up card grid.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    useState,
    useMemo
  } = React;
  const {
    Tag,
    Input,
    Badge
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const CATS = {
    retention: {
      label: "Retention",
      color: "var(--cat-retention)"
    },
    monetization: {
      label: "Monetization",
      color: "var(--cat-monetization)"
    },
    social: {
      label: "Social",
      color: "var(--cat-social)"
    }
  };

  /* Player types (Bartle). Dot colors drawn from existing DS tokens. */
  const USER_TYPES = {
    achiever: {
      label: "Achiever",
      color: "var(--cat-social)"
    },
    explorer: {
      label: "Explorer",
      color: "var(--cat-monetization)"
    },
    socializer: {
      label: "Socializer",
      color: "var(--cat-retention)"
    },
    competitor: {
      label: "Competitor",
      color: "var(--red-600)"
    }
  };

  /* Product-context filters (a curated subset of the tag vocabulary). */
  const CONTEXTS = ["activation", "onboarding", "retention", "habit", "progression", "monetization", "growth", "status"];
  const MECHANICS = [{
    n: 1,
    name: "Streak / Streak Bonus",
    cats: ["retention"],
    desc: "A counter that increments each time a user completes a defined action within a set time window, typically once per day.",
    tags: ["activation", "retention", "habit"],
    users: ["achiever"],
    examples: 11,
    access: "free",
    href: "mechanic-streak.html"
  }, {
    n: 2,
    name: "Daily Reward",
    cats: ["retention", "monetization"],
    desc: "A small, escalating gift handed out for opening the app each day, giving the next session a reason to start.",
    tags: ["habit", "retention"],
    users: ["achiever"],
    examples: 14
  }, {
    n: 3,
    name: "Leaderboards",
    cats: ["social"],
    desc: "A ranked list that places a user's performance next to their peers, turning effort into visible standing.",
    tags: ["competition", "social", "status"],
    users: ["competitor"],
    examples: 9
  }, {
    n: 4,
    name: "Loss Aversion",
    cats: ["retention"],
    desc: "Framing progress as something already earned and at risk, so users act to keep it rather than to chase more.",
    tags: ["retention", "urgency"],
    users: ["achiever"],
    examples: 8
  }, {
    n: 5,
    name: "Gifting",
    cats: ["social"],
    desc: "Letting users send small, free value to one another, so the product's growth runs on everyday goodwill.",
    tags: ["social", "growth"],
    users: ["socializer"],
    examples: 7
  }, {
    n: 6,
    name: "Milestone Rewards",
    cats: ["retention"],
    desc: "Rewards tied to cumulative progress, marking how far a user has come and what the next marker is worth.",
    tags: ["progression", "retention"],
    users: ["achiever"],
    examples: 10
  }, {
    n: 7,
    name: "Mystery Reward",
    cats: ["monetization"],
    desc: "A reward whose contents are revealed only on open, using anticipation to make the moment worth repeating.",
    tags: ["surprise", "monetization"],
    users: ["explorer"],
    examples: 6
  }, {
    n: 8,
    name: "Season Pass",
    cats: ["monetization", "retention"],
    desc: "A time-boxed track of rewards unlocked through play, pairing a free tier with a paid one alongside it.",
    tags: ["monetization", "progression"],
    users: ["achiever", "competitor"],
    examples: 12
  }, {
    n: 9,
    name: "Energy / Lives",
    cats: ["monetization"],
    desc: "A spendable resource that meters how much a user can play at once, then refills over time or for a fee.",
    tags: ["pacing", "monetization"],
    users: ["achiever"],
    examples: 9
  }, {
    n: 10,
    name: "Onboarding Goal",
    cats: ["retention"],
    desc: "A clear first objective set in the opening minutes, giving a new user one obvious thing to accomplish.",
    tags: ["onboarding", "activation"],
    users: ["achiever", "explorer"],
    examples: 13
  }, {
    n: 11,
    name: "Quests / Missions",
    cats: ["retention"],
    desc: "Short, named tasks that point users toward valuable actions and pay out the moment each one is complete.",
    tags: ["engagement", "progression"],
    users: ["achiever", "explorer"],
    examples: 11
  }, {
    n: 12,
    name: "Social Challenges",
    cats: ["social"],
    desc: "Time-bound goals pursued with or against friends, where the company of others is the reason to keep going.",
    tags: ["social", "competition"],
    users: ["socializer", "competitor"],
    examples: 7
  }, {
    n: 13,
    name: "Cosmetics",
    cats: ["monetization"],
    desc: "Optional visual items players buy to express themselves, with no effect on the balance of play.",
    tags: ["monetization", "status"],
    users: ["explorer", "socializer"],
    examples: 8
  }, {
    n: 14,
    name: "Limited-Time Events",
    cats: ["monetization", "retention"],
    desc: "A themed mode available only for a short window, using scarcity to concentrate attention and spend.",
    tags: ["urgency", "monetization"],
    users: ["competitor", "achiever"],
    examples: 10
  }, {
    n: 15,
    name: "Progress Bar",
    cats: ["retention"],
    desc: "A visible measure of how close a user is to a goal, where the gap left to fill is itself the motivation.",
    tags: ["progression", "activation"],
    users: ["achiever"],
    examples: 12
  }, {
    n: 16,
    name: "Badges / Achievements",
    cats: ["retention"],
    desc: "Collectible markers awarded for specific feats, giving lasting proof of effort users can display.",
    tags: ["progression", "status"],
    users: ["achiever"],
    examples: 9
  }, {
    n: 17,
    name: "Referral Rewards",
    cats: ["social"],
    desc: "A two-sided incentive that pays both the inviter and the invited, turning users into a growth channel.",
    tags: ["growth", "social"],
    users: ["socializer"],
    examples: 8
  }, {
    n: 18,
    name: "Variable Rewards",
    cats: ["retention"],
    desc: "Payouts that vary in size and timing, keeping the next outcome uncertain enough to be worth checking.",
    tags: ["habit", "retention"],
    users: ["explorer"],
    examples: 7
  }, {
    n: 19,
    name: "Tiers / Levels",
    cats: ["retention"],
    desc: "A ladder of ranks earned through sustained use, where each step up renews the reason to keep climbing.",
    tags: ["progression", "status"],
    users: ["achiever", "competitor"],
    examples: 10
  }, {
    n: 20,
    name: "Collections / Sets",
    cats: ["retention"],
    desc: "Items grouped into sets that feel incomplete until finished, with the missing piece pulling users back.",
    tags: ["collection", "retention"],
    users: ["explorer"],
    examples: 6
  }, {
    n: 21,
    name: "Teams / Guilds",
    cats: ["social"],
    desc: "Persistent groups that share goals and accountability, so a user's return is owed partly to teammates.",
    tags: ["social", "retention"],
    users: ["socializer"],
    examples: 8
  }, {
    n: 22,
    name: "Login Calendar",
    cats: ["retention"],
    desc: "A monthly grid that fills in with each visit, making an unbroken record of attendance worth protecting.",
    tags: ["habit", "retention"],
    users: ["achiever"],
    examples: 9
  }];
  const fmt = s => s.charAt(0).toUpperCase() + s.slice(1);
  const SearchIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "7"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  }));
  const LockIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "4",
    y: "11",
    width: "16",
    height: "10",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V8a4 4 0 0 1 8 0v3"
  }));
  function FilterRow({
    active,
    dot,
    label,
    onClick
  }) {
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "frow" + (active ? " frow--active" : ""),
      "aria-pressed": active,
      onClick: onClick
    }, dot !== undefined && /*#__PURE__*/React.createElement("span", {
      className: "frow__dot",
      style: {
        background: dot
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "frow__label"
    }, label));
  }
  function MechanicLibCard({
    m
  }) {
    const primary = m.cats[0];
    const locked = m.access !== "free";
    return /*#__PURE__*/React.createElement("a", {
      className: "mlc" + (locked ? " mlc--locked" : ""),
      href: locked ? "#subscribe" : m.href || `#mechanic-${m.n}`
    }, /*#__PURE__*/React.createElement("div", {
      className: "mlc__top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mlc__lead"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mlc__num"
    }, String(m.n).padStart(2, "0")), /*#__PURE__*/React.createElement(Tag, {
      category: primary
    }, CATS[primary].label)), /*#__PURE__*/React.createElement("span", {
      className: "mlc__badge"
    }, locked ? /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      variant: "outline",
      icon: LockIcon
    }, "For subscribers") : /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      variant: "soft"
    }, "Free"))), /*#__PURE__*/React.createElement("h3", {
      className: "mlc__name"
    }, m.name), /*#__PURE__*/React.createElement("p", {
      className: "mlc__desc"
    }, m.desc), /*#__PURE__*/React.createElement("div", {
      className: "mlc__tags"
    }, m.tags.map(t => /*#__PURE__*/React.createElement("span", {
      className: "pillchip",
      key: t
    }, t))), /*#__PURE__*/React.createElement("div", {
      className: "mlc__foot"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mlc__dots"
    }, m.cats.map(c => /*#__PURE__*/React.createElement("span", {
      className: "mlc__dot",
      key: c,
      style: {
        background: CATS[c].color
      },
      title: CATS[c].label
    }))), /*#__PURE__*/React.createElement("span", {
      className: "mlc__examples"
    }, m.examples, " examples")));
  }

  /** Mechanics library: floating filter panel on the left, 2-up card grid on the right. */
  function MechanicsPage() {
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState("all");
    const [contexts, setContexts] = useState([]);
    const [users, setUsers] = useState([]);
    const toggle = (list, setList, value) => setList(list.includes(value) ? list.filter(v => v !== value) : [...list, value]);
    const pickCategory = key => setCategory(c => c === key ? "all" : key);
    const results = useMemo(() => {
      const q = query.trim().toLowerCase();
      return MECHANICS.filter(m => {
        if (q && !(m.name.toLowerCase().includes(q) || m.desc.toLowerCase().includes(q))) return false;
        if (category !== "all" && !m.cats.includes(category)) return false;
        if (contexts.length && !m.tags.some(t => contexts.includes(t))) return false;
        if (users.length && !m.users.some(u => users.includes(u))) return false;
        return true;
      });
    }, [query, category, contexts, users]);
    const active = query || category !== "all" || contexts.length || users.length;
    const clearAll = () => {
      setQuery("");
      setCategory("all");
      setContexts([]);
      setUsers([]);
    };
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "band--tight lib-head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow lib-head__eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", null, "Mechanics library"), /*#__PURE__*/React.createElement("p", null, "The building blocks behind the apps and games people keep coming back to. Each mechanic comes with its psychology, the players it fits, and real examples from the library."))), /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "lib-layout"
    }, /*#__PURE__*/React.createElement("aside", {
      className: "lib-filters"
    }, /*#__PURE__*/React.createElement("form", {
      className: "filters",
      onSubmit: e => e.preventDefault(),
      "aria-label": "Filter mechanics"
    }, /*#__PURE__*/React.createElement("div", {
      className: "filters__head"
    }, /*#__PURE__*/React.createElement("span", {
      className: "filters__title"
    }, "Filters"), /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "filters__clear",
      onClick: clearAll,
      disabled: !active
    }, "Clear all")), /*#__PURE__*/React.createElement(Input, {
      "aria-label": "Search mechanics",
      placeholder: "Search mechanics",
      value: query,
      onChange: e => setQuery(e.target.value),
      leadingIcon: SearchIcon
    }), /*#__PURE__*/React.createElement("div", {
      className: "fgroup",
      role: "group",
      "aria-label": "Category"
    }, /*#__PURE__*/React.createElement("span", {
      className: "fgroup__label"
    }, "Category"), /*#__PURE__*/React.createElement(FilterRow, {
      active: category === "all",
      dot: "var(--ink-400)",
      label: "All",
      onClick: () => setCategory("all")
    }), Object.entries(CATS).map(([key, c]) => /*#__PURE__*/React.createElement(FilterRow, {
      key: key,
      active: category === key,
      dot: c.color,
      label: c.label,
      onClick: () => pickCategory(key)
    }))), /*#__PURE__*/React.createElement("div", {
      className: "fgroup",
      role: "group",
      "aria-label": "Product context"
    }, /*#__PURE__*/React.createElement("span", {
      className: "fgroup__label"
    }, "Product context"), CONTEXTS.map(t => /*#__PURE__*/React.createElement(FilterRow, {
      key: t,
      active: contexts.includes(t),
      label: fmt(t),
      onClick: () => toggle(contexts, setContexts, t)
    }))), /*#__PURE__*/React.createElement("div", {
      className: "fgroup",
      role: "group",
      "aria-label": "User type"
    }, /*#__PURE__*/React.createElement("span", {
      className: "fgroup__label"
    }, "User type"), Object.entries(USER_TYPES).map(([key, u]) => /*#__PURE__*/React.createElement(FilterRow, {
      key: key,
      active: users.includes(key),
      dot: u.color,
      label: u.label,
      onClick: () => toggle(users, setUsers, key)
    }))))), /*#__PURE__*/React.createElement("section", {
      "aria-label": "Mechanics"
    }, /*#__PURE__*/React.createElement("div", {
      className: "lib-resultbar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "lib-resultbar__count"
    }, /*#__PURE__*/React.createElement("b", null, results.length), " of ", MECHANICS.length, " mechanics"), active ? /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "filters__clear",
      onClick: clearAll
    }, "Reset filters") : /*#__PURE__*/React.createElement("span", {
      className: "lib-resultbar__hint"
    }, "Updated weekly")), results.length ? /*#__PURE__*/React.createElement("div", {
      className: "lib-grid"
    }, results.map(m => /*#__PURE__*/React.createElement(MechanicLibCard, {
      key: m.n,
      m: m
    }))) : /*#__PURE__*/React.createElement("div", {
      className: "lib-empty"
    }, "No mechanics match those filters. Try removing one.")))));
  }
  Object.assign(GBSite, {
    MechanicsPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MechanicsLibrary.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Report.jsx
try { (() => {
/* Website kit — Category report (Gamification in Finance). A single category
   report landing: header, headline stats, the apps analyzed, a numbered chapter
   index, a full-report CTA card, and a ranked "opportunities at a glance" list.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const GBSite = window.GBSite = window.GBSite || {};
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  const RightIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }));
  const REPORT = {
    label: "Category Report · 2026",
    title: "Gamification in Finance",
    overview: "Banking, investing, and budgeting apps have quietly become some of the most gamified products people use every day. This report maps how fifteen leading finance apps apply the mechanics in our framework: what the category already leans on, where the patterns have hardened into convention, and which mechanics remain wide open for a product willing to try them. Every finding is drawn from the live apps and measured against the twenty-two-mechanic framework.",
    stats: [{
      value: "15",
      label: "Apps analyzed"
    }, {
      value: "22",
      label: "Mechanics mapped"
    }, {
      value: "7",
      label: "Chapters"
    }],
    apps: [{
      ab: "Rv",
      name: "Revolut"
    }, {
      ab: "Mo",
      name: "Monzo"
    }, {
      ab: "CA",
      name: "Cash App"
    }, {
      ab: "Rb",
      name: "Robinhood"
    }, {
      ab: "Ch",
      name: "Chime"
    }, {
      ab: "Ac",
      name: "Acorns"
    }, {
      ab: "Kl",
      name: "Klarna"
    }, {
      ab: "PP",
      name: "PayPal"
    }, {
      ab: "Nu",
      name: "Nubank"
    }, {
      ab: "Ve",
      name: "Venmo"
    }, {
      ab: "St",
      name: "Stash"
    }, {
      ab: "Pl",
      name: "Plum"
    }, {
      ab: "Cl",
      name: "Cleo"
    }, {
      ab: "Sp",
      name: "Step"
    }, {
      ab: "Cu",
      name: "Current"
    }],
    chapters: [{
      title: "The state of gamification in finance",
      desc: "Where the category stands today, and why money apps reach for game mechanics at all."
    }, {
      title: "Streaks and the savings habit",
      desc: "How finance apps borrow the daily streak to turn saving into a routine worth protecting."
    }, {
      title: "Progress, goals, and the budgeting loop",
      desc: "Goal bars and milestones that make an abstract balance feel close enough to chase."
    }, {
      title: "Rewards, cashback, and variable payoffs",
      desc: "Where finance leans on variable rewards, and the line between delight and dark pattern."
    }, {
      title: "Social proof and money",
      desc: "Leaderboards, peers, and the uneasy place competition holds in personal finance."
    }, {
      title: "Onboarding the nervous first-time user",
      desc: "Activation goals and guided setup for a category where trust is the first hurdle."
    }, {
      title: "The open opportunities",
      desc: "The mechanics finance has barely touched, and what it would take to use them well."
    }],
    cta: {
      title: "Read the full Finance report",
      desc: "Seven chapters, fifteen apps, and a working list of the mechanics most worth trying in a finance product, each with annotated examples from the apps that do it best.",
      stats: [{
        value: "7",
        label: "Chapters"
      }, {
        value: "15",
        label: "Apps"
      }, {
        value: "48",
        label: "Examples"
      }, {
        value: "16",
        label: "Opportunities"
      }]
    },
    opportunities: [{
      name: "Streak / Streak Bonus",
      desc: "Reward consecutive days of saving or logging a transaction.",
      nov: "low"
    }, {
      name: "Milestone Rewards",
      desc: "Mark a savings goal at meaningful balance thresholds.",
      nov: "low"
    }, {
      name: "Progress Bar",
      desc: "Show how close a goal balance sits to its target.",
      nov: "low"
    }, {
      name: "Tiers / Levels",
      desc: "Status tiers that unlock perks as a balance grows.",
      nov: "low"
    }, {
      name: "Referral Rewards",
      desc: "A two-sided incentive for inviting a friend to join.",
      nov: "low"
    }, {
      name: "Daily Reward",
      desc: "A small bonus for opening the app and checking in.",
      nov: "mid"
    }, {
      name: "Loss Aversion",
      desc: "Frame a lapsed streak or missed round-up as ground given up.",
      nov: "mid"
    }, {
      name: "Variable Rewards",
      desc: "Randomized cashback or a surprise boost on a deposit.",
      nov: "mid"
    }, {
      name: "Quests / Missions",
      desc: "Guided tasks like setting up direct deposit, paid on completion.",
      nov: "mid"
    }, {
      name: "Badges / Achievements",
      desc: "Collectible markers for reaching financial milestones.",
      nov: "mid"
    }, {
      name: "Gifting",
      desc: "Send a small amount or a boost to another user.",
      nov: "mid"
    }, {
      name: "Leaderboards",
      desc: "Rank saving or investing streaks against a peer cohort.",
      nov: "high"
    }, {
      name: "Season Pass",
      desc: "A timed track of rewards for sustained engagement.",
      nov: "high"
    }, {
      name: "Social Challenges",
      desc: "Group savings goals pursued with friends.",
      nov: "high"
    }, {
      name: "Collections / Sets",
      desc: "Complete a set of money habits to earn a reward.",
      nov: "high"
    }, {
      name: "Limited-Time Events",
      desc: "Short windows with boosted rates or rewards.",
      nov: "high"
    }]
  };
  const NOV_LABEL = {
    low: "Low",
    mid: "Mid",
    high: "High"
  };
  function ReportPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "rpt-head",
      "aria-labelledby": "rpt-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "index.html"
    }, "Reports"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Finance")), /*#__PURE__*/React.createElement("div", {
      className: "rpt-label"
    }, REPORT.label), /*#__PURE__*/React.createElement("h1", {
      id: "rpt-h"
    }, REPORT.title), /*#__PURE__*/React.createElement("p", {
      className: "rpt-overview"
    }, REPORT.overview), /*#__PURE__*/React.createElement("div", {
      className: "rpt-stats"
    }, REPORT.stats.map(s => /*#__PURE__*/React.createElement("div", {
      className: "rpt-stat",
      key: s.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__num"
    }, s.value), /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__label"
    }, s.label)))), /*#__PURE__*/React.createElement("div", {
      className: "rpt-apps",
      "aria-label": "Apps analyzed in this report"
    }, REPORT.apps.map(a => /*#__PURE__*/React.createElement("span", {
      className: "rpt-app",
      key: a.name,
      title: a.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-app__ab",
      "aria-hidden": "true"
    }, a.ab), /*#__PURE__*/React.createElement("span", {
      className: "sr-only"
    }, a.name)))))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight",
      "aria-labelledby": "toc-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What the report covers"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "toc-h"
    }, "Seven chapters"), /*#__PURE__*/React.createElement("div", {
      className: "rpt-covers"
    }, /*#__PURE__*/React.createElement("ol", {
      className: "rpt-chapters"
    }, REPORT.chapters.map((c, i) => /*#__PURE__*/React.createElement("li", {
      className: "rpt-chapter",
      key: c.title
    }, /*#__PURE__*/React.createElement("a", {
      className: "rpt-chapter__link",
      href: `#chapter-${i + 1}`
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-chapter__n"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
      className: "rpt-chapter__body"
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-chapter__title"
    }, c.title), /*#__PURE__*/React.createElement("span", {
      className: "rpt-chapter__desc"
    }, c.desc)), /*#__PURE__*/React.createElement("span", {
      className: "rpt-chapter__go",
      "aria-hidden": "true"
    }, ArrowIcon))))), /*#__PURE__*/React.createElement("div", {
      className: "rpt-cta"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rpt-cta__head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rpt-cta__k"
    }, "The full report"), /*#__PURE__*/React.createElement("h3", {
      className: "rpt-cta__t"
    }, REPORT.cta.title), /*#__PURE__*/React.createElement("p", {
      className: "rpt-cta__p"
    }, REPORT.cta.desc), /*#__PURE__*/React.createElement("a", {
      className: "rpt-cta__go",
      href: "#chapter-1"
    }, "Start reading ", RightIcon)), /*#__PURE__*/React.createElement("div", {
      className: "rpt-cta__stats"
    }, REPORT.cta.stats.map(s => /*#__PURE__*/React.createElement("div", {
      className: "rpt-stat rpt-stat--onink",
      key: s.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__num"
    }, s.value), /*#__PURE__*/React.createElement("span", {
      className: "rpt-stat__label"
    }, s.label)))))))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight",
      style: {
        paddingTop: 0
      },
      "aria-labelledby": "opp-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Opportunities at a glance"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "opp-h"
    }, "Mechanics for finance apps, ranked by novelty"), /*#__PURE__*/React.createElement("p", {
      className: "rpt-opps-note"
    }, "Novelty is how untapped each mechanic is in finance today, from ", /*#__PURE__*/React.createElement("b", null, "Low"), " (already conventional) to ", /*#__PURE__*/React.createElement("b", null, "High"), " (barely touched, and worth the first move)."), /*#__PURE__*/React.createElement("ol", {
      className: "rpt-opps"
    }, REPORT.opportunities.map((o, i) => /*#__PURE__*/React.createElement("li", {
      className: "rpt-opp",
      key: o.name
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-opp__n"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
      className: "rpt-opp__main"
    }, /*#__PURE__*/React.createElement("span", {
      className: "rpt-opp__name"
    }, o.name), /*#__PURE__*/React.createElement("span", {
      className: "rpt-opp__desc"
    }, o.desc)), /*#__PURE__*/React.createElement("span", {
      className: `rpt-nov rpt-nov--${o.nov}`
    }, NOV_LABEL[o.nov])))))));
  }
  Object.assign(GBSite, {
    ReportPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Report.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteChrome.jsx
try { (() => {
/* Website kit chrome. Loaded as a Babel script in index.html (not via the DS
   bundle), so it reads React + DS primitives from globals and attaches its own
   components to window.GBSite. */
(function () {
  const React = window.React;
  const {
    useState
  } = React;
  const {
    Button,
    Input
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const LOGO = "../../assets/logo/gamebiz-logo.svg";
  const LOGO_INK = "../../assets/logo/gamebiz-logo-ink.svg";
  const NAV = [{
    label: "Library",
    href: "#library",
    children: [{
      label: "Mechanics",
      href: "#mechanics",
      desc: "The core building blocks, with the psychology behind each one."
    }, {
      label: "Systems",
      href: "#systems",
      desc: "How mechanics combine into the loops that keep players coming back."
    }, {
      label: "Cheatsheets",
      href: "#cheatsheets",
      desc: "Practical guides for putting mechanics into your product."
    }, {
      label: "Glossary",
      href: "#glossary",
      desc: "Plain-language definitions for every term we use."
    }]
  }, {
    label: "Case studies",
    href: "#case-studies"
  }, {
    label: "Reports",
    href: "#reports",
    children: [{
      label: "Gamification for finance",
      href: "#reports-finance",
      desc: "What banking and fintech apps rely on, and where the openings are."
    }, {
      label: "Gamification for fitness",
      href: "#reports-fitness",
      desc: "How health and fitness apps build lasting habits."
    }, {
      label: "Gamification for productivity",
      href: "#reports-productivity",
      desc: "What keeps users returning to tools and trackers."
    }]
  }, {
    label: "Work with us",
    href: "#work"
  }];
  function Caret() {
    return /*#__PURE__*/React.createElement("svg", {
      className: "nav__caret",
      width: "14",
      height: "14",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "6 9 12 15 18 9"
    }));
  }

  /** Primary site navigation. Sticky, paper, hairline rule. Three groups, two with
   *  dropdown menus (hover and keyboard-focus on desktop). Collapses to a drawer
   *  below 1024px. Subscribe is the one accent action. */
  function SiteNav({
    current
  }) {
    const [open, setOpen] = useState(false);
    const isCurrent = href => current && href === `#${current}` ? "page" : undefined;
    return /*#__PURE__*/React.createElement("header", {
      className: "nav"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container nav__in"
    }, /*#__PURE__*/React.createElement("a", {
      className: "nav__brand",
      href: "#top",
      "aria-label": "GameBiz home"
    }, /*#__PURE__*/React.createElement("img", {
      className: "nav__logo",
      src: window.__resources && window.__resources.gbLogo || LOGO,
      alt: "GameBiz",
      width: "100",
      height: "22"
    })), /*#__PURE__*/React.createElement("span", {
      className: "nav__fresh"
    }, /*#__PURE__*/React.createElement("span", {
      className: "pip"
    }), "Updated weekly"), /*#__PURE__*/React.createElement("div", {
      className: "nav__spacer"
    }), /*#__PURE__*/React.createElement("nav", {
      className: "nav__links",
      "aria-label": "Primary"
    }, NAV.map(item => item.children ? /*#__PURE__*/React.createElement("div", {
      className: "nav__item",
      key: item.label
    }, /*#__PURE__*/React.createElement("a", {
      className: "nav__link nav__trigger",
      href: item.href,
      "aria-haspopup": "true",
      "aria-current": isCurrent(item.href)
    }, item.label, /*#__PURE__*/React.createElement(Caret, null)), /*#__PURE__*/React.createElement("div", {
      className: "nav__menu",
      role: "menu",
      "aria-label": item.label
    }, item.children.map(c => /*#__PURE__*/React.createElement("a", {
      key: c.label,
      role: "menuitem",
      href: c.href
    }, /*#__PURE__*/React.createElement("span", {
      className: "nav__menu-t"
    }, c.label), /*#__PURE__*/React.createElement("span", {
      className: "nav__menu-d"
    }, c.desc))))) : /*#__PURE__*/React.createElement("a", {
      key: item.label,
      className: "nav__link",
      href: item.href,
      "aria-current": isCurrent(item.href)
    }, item.label))), /*#__PURE__*/React.createElement("div", {
      className: "nav__actions"
    }, /*#__PURE__*/React.createElement("a", {
      className: "nav__link",
      href: "#login"
    }, "Log in"), /*#__PURE__*/React.createElement("a", {
      className: "nav__link",
      href: "#subscribe"
    }, "Subscribe")), /*#__PURE__*/React.createElement("button", {
      className: "nav__burger",
      "aria-label": open ? "Close menu" : "Open menu",
      "aria-expanded": open,
      onClick: () => setOpen(v => !v)
    }, /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "20",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      "aria-hidden": "true"
    }, open ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "18",
      y1: "6",
      x2: "6",
      y2: "18"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "6",
      y1: "6",
      x2: "18",
      y2: "18"
    })) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "6",
      x2: "21",
      y2: "6"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "12",
      x2: "21",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "18",
      x2: "21",
      y2: "18"
    }))))), /*#__PURE__*/React.createElement("div", {
      className: "nav__drawer",
      "data-open": open,
      role: "dialog",
      "aria-label": "Menu",
      "aria-hidden": !open
    }, NAV.map(item => /*#__PURE__*/React.createElement("div", {
      className: "nav__drawer-group",
      key: item.label
    }, /*#__PURE__*/React.createElement("a", {
      className: "nav__drawer-head",
      href: item.href,
      onClick: () => setOpen(false)
    }, item.label), item.children && /*#__PURE__*/React.createElement("div", {
      className: "nav__drawer-sub"
    }, item.children.map(c => /*#__PURE__*/React.createElement("a", {
      key: c.label,
      href: c.href,
      onClick: () => setOpen(false)
    }, /*#__PURE__*/React.createElement("span", {
      className: "nav__menu-t"
    }, c.label), /*#__PURE__*/React.createElement("span", {
      className: "nav__menu-d"
    }, c.desc)))))), /*#__PURE__*/React.createElement("div", {
      className: "nav__drawer-actions"
    }, /*#__PURE__*/React.createElement("a", {
      className: "nav__link",
      href: "#login",
      onClick: () => setOpen(false)
    }, "Log in"), /*#__PURE__*/React.createElement("a", {
      className: "nav__link",
      href: "#subscribe",
      onClick: () => setOpen(false)
    }, "Subscribe"))));
  }

  /** Newsletter signup: one field, one sentence on what subscribers get. */
  function NewsletterBlock() {
    return /*#__PURE__*/React.createElement("section", {
      className: "band band--sheet",
      "aria-labelledby": "newsletter-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "newsletter"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
      id: "newsletter-h"
    }, "Three new case studies every week"), /*#__PURE__*/React.createElement("p", null, "Each week we add three fresh app breakdowns to the library. We'll send them straight to your inbox, dated, with a line on what makes each one worth your time.")), /*#__PURE__*/React.createElement("form", {
      className: "newsletter__form",
      onSubmit: e => e.preventDefault()
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Email",
      size: "lg",
      type: "email",
      placeholder: "you@company.com",
      "aria-label": "Email address"
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      type: "submit"
    }, "Subscribe")))));
  }
  const FOOTER_COLS = [{
    h: "Library",
    links: ["Mechanics", "Apps", "Systems", "Cheatsheets", "Glossary"]
  }, {
    h: "Practice",
    links: ["Work with us", "Reports"]
  }, {
    h: "Account",
    links: ["Subscribe", "Log in"]
  }];

  /** Footer: all navigation, the one-liner, contact, freshness, copyright. */
  function SiteFooter() {
    return /*#__PURE__*/React.createElement("footer", {
      className: "footer",
      id: "footer"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "footer__top"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
      className: "footer__brand-logo",
      src: window.__resources && window.__resources.gbLogoInk || LOGO_INK,
      alt: "GameBiz",
      width: "120",
      height: "24"
    }), /*#__PURE__*/React.createElement("p", {
      className: "footer__desc"
    }, "We study how the best apps and games keep their players, mechanic by mechanic, and help your team apply what fits your product, so your users stay, engage, and grow.")), /*#__PURE__*/React.createElement("div", {
      className: "footer__cols"
    }, FOOTER_COLS.map(c => /*#__PURE__*/React.createElement("div", {
      className: "footer__col",
      key: c.h
    }, /*#__PURE__*/React.createElement("h4", null, c.h), c.links.map(l => /*#__PURE__*/React.createElement("a", {
      key: l,
      href: "#"
    }, l)))))), /*#__PURE__*/React.createElement("div", {
      className: "footer__bottom"
    }, /*#__PURE__*/React.createElement("span", {
      className: "footer__fresh"
    }, /*#__PURE__*/React.createElement("span", {
      className: "pip"
    }), "Updated weekly \xB7 last addition Jun 6, 2026"), /*#__PURE__*/React.createElement("span", {
      className: "footer__meta"
    }, /*#__PURE__*/React.createElement("a", {
      className: "footer__email",
      href: "mailto:hello@gamebiz.co"
    }, "hello@gamebiz.co"), /*#__PURE__*/React.createElement("span", {
      className: "footer__sep",
      "aria-hidden": "true"
    }, "\xB7"), "\xA9 2026 GameBiz Consulting"))));
  }
  Object.assign(GBSite, {
    SiteNav,
    NewsletterBlock,
    SiteFooter
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteChrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Subscribe.jsx
try { (() => {
/* Website kit — Subscribe page. Friction-free entry to the library, with the free
   tier explained honestly. Hero + placeholder checkout moment (no transaction),
   what's inside with live counts, an honest free/full comparison (no prices, no
   decoy, no "most popular"), the weekly cadence as pure evidence, and one line of
   reassurance. Loaded as a Babel script; reads DS primitives, attaches to GBSite. */
(function () {
  const React = window.React;
  const {
    useState,
    useEffect
  } = React;
  const {
    Button,
    Input
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const CheckIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }));
  const CloseIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }));
  const MailIcon = /*#__PURE__*/React.createElement("i", {
    "data-lucide": "mail"
  });
  const INSIDE = [{
    count: "25",
    label: "App case studies",
    desc: "Full breakdowns, mechanic by mechanic, with annotated screenshots."
  }, {
    count: "22",
    label: "Mechanics",
    desc: "Every building block, with the psychology behind it and where it fits."
  }, {
    count: "25",
    label: "System maps",
    desc: "How each app's mechanics connect into the loops that bring players back."
  }, {
    count: "6",
    label: "Cheatsheets",
    desc: "Step-by-step guides your team can build straight from."
  }, {
    count: "15",
    label: "Glossary terms",
    desc: "Plain-language definitions for every term the library uses."
  }];
  const FREE = ["The Royal Match case study, in full", "A preview of every other case study, mechanic, and system map", "The opening of each cheatsheet", "The complete glossary"];
  const FULL = ["Every case study, mechanic, system map, and cheatsheet, in full", "Every system map, complete with its connections and requirements", "New app breakdowns added every week", "The complete glossary"];
  const NEW_THIS_WEEK = [{
    title: "Monopoly Go: event pacing breakdown",
    date: "Jun 6, 2026"
  }, {
    title: "Finch: gentle self-care streaks",
    date: "Jun 4, 2026"
  }, {
    title: "BeReal: the social window",
    date: "Jun 2, 2026"
  }];

  /* The placeholder checkout moment. A calm, dismissible sheet — the start of a
     subscription, designed before payments exist. Never traps; Esc or the scrim
     closes it. */
  function CheckoutSheet({
    open,
    onClose
  }) {
    const [done, setDone] = useState(false);
    useEffect(() => {
      if (!open) return;
      const onKey = e => {
        if (e.key === "Escape") onClose();
      };
      document.addEventListener("keydown", onKey);
      return () => document.removeEventListener("keydown", onKey);
    }, [open, onClose]);
    useEffect(() => {
      if (!open) setDone(false);
    }, [open]);
    if (!open) return null;
    return /*#__PURE__*/React.createElement("div", {
      className: "sub-sheet",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "sheet-h",
      onMouseDown: onClose
    }, /*#__PURE__*/React.createElement("div", {
      className: "sub-sheet__card",
      onMouseDown: e => e.stopPropagation()
    }, /*#__PURE__*/React.createElement("button", {
      className: "sub-sheet__close",
      onClick: onClose,
      "aria-label": "Close"
    }, CloseIcon), !done ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "Start your subscription"), /*#__PURE__*/React.createElement("h2", {
      id: "sheet-h",
      className: "sub-sheet__title"
    }, "Save your place in the library"), /*#__PURE__*/React.createElement("p", {
      className: "sub-sheet__p"
    }, "Checkout opens soon. Leave your email and we'll set up your account the moment it's ready \u2014 full access from your first sign-in."), /*#__PURE__*/React.createElement("form", {
      className: "sub-sheet__form",
      onSubmit: e => {
        e.preventDefault();
        setDone(true);
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Email",
      size: "lg",
      type: "email",
      required: true,
      placeholder: "you@company.com",
      leadingIcon: MailIcon,
      "aria-label": "Email address"
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      type: "submit"
    }, "Continue"))) : /*#__PURE__*/React.createElement("div", {
      className: "sub-sheet__done"
    }, /*#__PURE__*/React.createElement("span", {
      className: "sub-sheet__check",
      "aria-hidden": "true"
    }, CheckIcon), /*#__PURE__*/React.createElement("h2", {
      className: "sub-sheet__title"
    }, "You're on the list"), /*#__PURE__*/React.createElement("p", {
      className: "sub-sheet__p"
    }, "We'll email you the moment checkout opens. Until then, the Royal Match case study and every preview are yours to read."), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      as: "a",
      href: "case-study-royal-match.html"
    }, "Read the free case study"))));
  }

  /** Subscribe page body. */
  function SubscribePage() {
    const [open, setOpen] = useState(false);
    const openSheet = e => {
      if (e) e.preventDefault();
      setOpen(true);
    };
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "sub-hero",
      "aria-labelledby": "sub-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sub-hero__in"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", {
      id: "sub-h"
    }, "The reference library for how the best apps and games build engagement."), /*#__PURE__*/React.createElement("p", {
      className: "sub-hero__sub"
    }, "Full access to every case study, mechanic, system map, and cheatsheet. New apps added every week."), /*#__PURE__*/React.createElement("div", {
      className: "sub-hero__cta"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      as: "a",
      href: "#start",
      onClick: openSheet
    }, "Subscribe"), /*#__PURE__*/React.createElement("a", {
      className: "sub-hero__alt",
      href: "login.html"
    }, "Already a subscriber? Log in"))))), /*#__PURE__*/React.createElement("section", {
      className: "band band--sheet",
      "aria-labelledby": "inside-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What's inside"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "inside-h"
    }, "Five kinds of reference, one library"), /*#__PURE__*/React.createElement("div", {
      className: "sub-inside"
    }, INSIDE.map(c => /*#__PURE__*/React.createElement("div", {
      className: "sub-inside__card",
      key: c.label
    }, /*#__PURE__*/React.createElement("span", {
      className: "sub-inside__count"
    }, c.count), /*#__PURE__*/React.createElement("span", {
      className: "sub-inside__label"
    }, c.label), /*#__PURE__*/React.createElement("span", {
      className: "sub-inside__desc"
    }, c.desc)))))), /*#__PURE__*/React.createElement("section", {
      className: "band",
      "aria-labelledby": "tiers-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Free and full"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "tiers-h"
    }, "What you can read, either way"), /*#__PURE__*/React.createElement("div", {
      className: "sub-tiers"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sub-tier"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sub-tier__head"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "sub-tier__name"
    }, "Free"), /*#__PURE__*/React.createElement("p", {
      className: "sub-tier__note"
    }, "No account needed to start reading.")), /*#__PURE__*/React.createElement("ul", {
      className: "sub-tier__list"
    }, FREE.map(f => /*#__PURE__*/React.createElement("li", {
      key: f
    }, /*#__PURE__*/React.createElement("span", {
      className: "sub-tier__check",
      "aria-hidden": "true"
    }, CheckIcon), f))), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      as: "a",
      href: "case-study-royal-match.html"
    }, "Read the free case study")), /*#__PURE__*/React.createElement("div", {
      className: "sub-tier sub-tier--full"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sub-tier__head"
    }, /*#__PURE__*/React.createElement("h3", {
      className: "sub-tier__name"
    }, "Full access"), /*#__PURE__*/React.createElement("p", {
      className: "sub-tier__note"
    }, "Everything, plus every new addition.")), /*#__PURE__*/React.createElement("ul", {
      className: "sub-tier__list"
    }, FULL.map(f => /*#__PURE__*/React.createElement("li", {
      key: f
    }, /*#__PURE__*/React.createElement("span", {
      className: "sub-tier__check",
      "aria-hidden": "true"
    }, CheckIcon), f))), /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      as: "a",
      href: "#start",
      onClick: openSheet
    }, "Subscribe"))))), /*#__PURE__*/React.createElement("section", {
      className: "band band--sunken",
      "aria-labelledby": "cadence-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "The cadence"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "cadence-h"
    }, "New this week"), /*#__PURE__*/React.createElement("div", {
      className: "feed sub-feed"
    }, NEW_THIS_WEEK.map(it => /*#__PURE__*/React.createElement("div", {
      className: "feed__row",
      key: it.title
    }, /*#__PURE__*/React.createElement("span", {
      className: "feed__main"
    }, /*#__PURE__*/React.createElement("span", {
      className: "feed__title"
    }, it.title)), /*#__PURE__*/React.createElement("span", {
      className: "feed__date"
    }, it.date)))))), /*#__PURE__*/React.createElement("section", {
      className: "sub-reassure"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("p", null, "Cancel anytime, keep what you've learned."))), /*#__PURE__*/React.createElement(CheckoutSheet, {
      open: open,
      onClose: () => setOpen(false)
    }));
  }
  Object.assign(GBSite, {
    SubscribePage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Subscribe.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SystemDetail.jsx
try { (() => {
/* Website kit — System detail page (App system: Duolingo). The signature asset
   made interactive: a node-based map of one app's mechanics with typed, labeled
   connections, "+" tap targets that open a connection-detail modal, a legend, and
   a flat mechanic list as the mobile fallback.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    useState,
    useEffect
  } = React;
  const {
    Tag
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const CAT_COLOR = {
    retention: "var(--cat-retention)",
    monetization: "var(--cat-monetization)",
    social: "var(--cat-social)"
  };
  const CAT_LABEL = {
    retention: "Retention",
    monetization: "Monetization",
    social: "Social"
  };
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));
  const ArrowRight = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }));
  const CloseIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }));

  /* The Duolingo system. Nodes are the mechanics; x/y are percentages on a
     1000x560 conceptual canvas. `spine` marks the core-action anchor. */
  /* The Duolingo system laid out as a center-hub hexagon: the spine anchor (Daily
     lesson) sits at the center, the other six mechanics on a flat-top hexagon,
     ordered so the mechanic-to-mechanic links fall on adjacent edges. x/y are
     percentages on a 1000x560 conceptual canvas. */
  const NODES = [{
    id: "lesson",
    label: "Daily lesson",
    cat: "retention",
    x: 50,
    y: 50,
    spine: true,
    href: "#",
    desc: "The core action. A short, gamified practice session, and the one thing the app asks of you each day."
  }, {
    id: "loss",
    label: "Loss aversion",
    cat: "retention",
    x: 32,
    y: 16,
    href: "#",
    desc: "Your streak is shown as something already earned and at risk, so you act to keep it rather than to chase more."
  }, {
    id: "streak",
    label: "Streak",
    cat: "retention",
    x: 68,
    y: 16,
    href: "mechanic-streak.html",
    desc: "A count of consecutive days you have practiced, framed so the number itself feels worth protecting."
  }, {
    id: "quests",
    label: "Daily quests",
    cat: "retention",
    x: 86,
    y: 50,
    href: "#",
    desc: "Small, named goals refreshed each day that point you toward the right actions and pay out the moment you finish."
  }, {
    id: "gems",
    label: "Gems",
    cat: "monetization",
    x: 68,
    y: 84,
    href: "#",
    desc: "The soft currency you earn through play and spend on refills and boosts, linking effort to convenience."
  }, {
    id: "hearts",
    label: "Hearts",
    cat: "monetization",
    x: 32,
    y: 84,
    href: "#",
    desc: "A spendable resource lost to mistakes, metering how much you can practice before a wait or a purchase."
  }, {
    id: "league",
    label: "Leagues",
    cat: "social",
    x: 14,
    y: 50,
    href: "#",
    desc: "A weekly ranked table that sets your XP beside a cohort of other learners, turning practice into standing."
  }];

  /* Connections carry a `type` (spine | mechanic | retention | monetization | social),
     a short on-line `label`, and the modal `name` + `effect` (effect on the user). */
  const CONNECTIONS = [{
    from: "lesson",
    to: "streak",
    type: "spine",
    label: "advances",
    name: "Daily lesson advances the streak",
    effect: "Completing today's lesson ticks the streak forward, so a single session quietly becomes a chain you will not want to break."
  }, {
    from: "streak",
    to: "loss",
    type: "retention",
    label: "protected by",
    name: "The streak is protected by loss aversion",
    effect: "A longer streak raises the cost of missing a day, and loss aversion turns that cost into the reason you come back tomorrow."
  }, {
    from: "lesson",
    to: "hearts",
    type: "monetization",
    label: "spends",
    name: "Lessons spend hearts",
    effect: "Mistakes in a lesson cost hearts, adding a gentle price to careless practice and a moment where a user might wait or pay."
  }, {
    from: "lesson",
    to: "league",
    type: "social",
    label: "ranks in",
    name: "Lessons rank you in a league",
    effect: "Every lesson's XP feeds your weekly league position, so the same practice that builds the habit also fuels the competition."
  }, {
    from: "streak",
    to: "quests",
    type: "mechanic",
    label: "bundled with",
    name: "Streak and quests share the daily view",
    effect: "Quests sit beside the streak in the same daily screen, so the habit you protect and the tasks you chase reinforce each other."
  }, {
    from: "quests",
    to: "gems",
    type: "monetization",
    label: "rewards",
    name: "Quests reward gems",
    effect: "Finishing quests pays out gems, converting small daily goals into a currency you can feel accumulating session over session."
  }, {
    from: "hearts",
    to: "gems",
    type: "monetization",
    label: "refilled by",
    name: "Hearts are refilled by gems",
    effect: "Running out of hearts sends you to gems to refill, the point where the currency you earned turns into convenience you buy."
  }];
  const LINE_TYPE = {
    spine: "App spine",
    mechanic: "Mechanic connection",
    retention: "Retention",
    monetization: "Monetization",
    social: "Social"
  };
  const TYPE_COLOR = {
    spine: "var(--ink-600)",
    mechanic: "var(--ink-400)",
    retention: "var(--cat-retention)",
    monetization: "var(--cat-monetization)",
    social: "var(--cat-social)"
  };
  const W = 1000,
    H = 560;
  const byId = Object.fromEntries(NODES.map(n => [n.id, n]));

  /* Quadratic-curve geometry shared by the SVG path and the chip placement. The
     chip sits at parameter t along the curve (default mid), tuned per connection
     so the bubbles never overlap each other or a node. */
  function geom(c) {
    const a = byId[c.from],
      b = byId[c.to];
    const x1 = a.x / 100 * W,
      y1 = a.y / 100 * H;
    const x2 = b.x / 100 * W,
      y2 = b.y / 100 * H;
    const mx = (x1 + x2) / 2,
      my = (y1 + y2) / 2;
    const cy = my - Math.min(40, Math.abs(x2 - x1) * 0.18);
    const t = c.t != null ? c.t : 0.5,
      it = 1 - t;
    const ax = it * it * x1 + 2 * it * t * mx + t * t * x2;
    const ay = it * it * y1 + 2 * it * t * cy + t * t * y2;
    return {
      d: `M ${x1} ${y1} Q ${mx} ${cy} ${x2} ${y2}`,
      apex: {
        x: ax / W * 100,
        y: ay / H * 100
      }
    };
  }
  function InteractiveMap({
    onOpen
  }) {
    return /*#__PURE__*/React.createElement("div", {
      className: "smap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "smap__paper"
    }), /*#__PURE__*/React.createElement("svg", {
      className: "smap__svg",
      viewBox: `0 0 ${W} ${H}`,
      preserveAspectRatio: "none"
    }, CONNECTIONS.map((c, i) => /*#__PURE__*/React.createElement("path", {
      key: i,
      className: `smap__line smap__line--${c.type}`,
      d: geom(c).d
    }))), NODES.map(n => /*#__PURE__*/React.createElement("a", {
      key: n.id,
      href: n.href,
      className: "smap__node" + (n.spine ? " smap__node--spine" : ""),
      style: {
        left: n.x + "%",
        top: n.y + "%"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "smap__cat"
    }, /*#__PURE__*/React.createElement("span", {
      className: "smap__dot",
      style: {
        background: CAT_COLOR[n.cat]
      }
    }), CAT_LABEL[n.cat]), /*#__PURE__*/React.createElement("span", {
      className: "smap__label"
    }, n.label))), CONNECTIONS.map((c, i) => {
      const {
        apex
      } = geom(c);
      return /*#__PURE__*/React.createElement("button", {
        key: i,
        type: "button",
        className: "conn",
        style: {
          left: apex.x + "%",
          top: apex.y + "%"
        },
        onClick: () => onOpen(c),
        "aria-label": `How ${byId[c.from].label} connects to ${byId[c.to].label}`
      }, /*#__PURE__*/React.createElement("span", {
        className: "conn__label"
      }, c.label), /*#__PURE__*/React.createElement("span", {
        className: "conn__plus",
        "aria-hidden": "true"
      }, "+"));
    }));
  }
  const LEGEND = ["spine", "mechanic", "retention", "monetization", "social"];
  function MapLegend() {
    return /*#__PURE__*/React.createElement("div", {
      className: "maplegend",
      "aria-label": "Connection types"
    }, LEGEND.map(t => /*#__PURE__*/React.createElement("span", {
      className: "maplegend__item",
      key: t
    }, /*#__PURE__*/React.createElement("span", {
      className: `maplegend__sw maplegend__sw--line maplegend__sw--${t}`
    }), LINE_TYPE[t])));
  }

  /* Mobile fallback: a flat list of the mechanics, each with category, name, and a
     description paragraph. */
  function MechanicList() {
    return /*#__PURE__*/React.createElement("div", {
      className: "syslist"
    }, NODES.map(n => /*#__PURE__*/React.createElement("div", {
      className: "sysrow",
      key: n.id
    }, /*#__PURE__*/React.createElement("div", {
      className: "sysrow__head"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: n.cat,
      dot: true
    }, CAT_LABEL[n.cat]), /*#__PURE__*/React.createElement("span", {
      className: "sysrow__name"
    }, n.label)), /*#__PURE__*/React.createElement("p", null, n.desc))));
  }
  function ConnectionModal({
    conn,
    onClose
  }) {
    useEffect(() => {
      const onKey = e => {
        if (e.key === "Escape") onClose();
      };
      document.addEventListener("keydown", onKey);
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.removeEventListener("keydown", onKey);
        document.body.style.overflow = prev;
      };
    }, [onClose]);
    const a = byId[conn.from],
      b = byId[conn.to];
    const dashed = conn.type === "mechanic";
    return /*#__PURE__*/React.createElement("div", {
      className: "cmodal",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "cmodal-title"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cmodal__backdrop",
      onClick: onClose
    }), /*#__PURE__*/React.createElement("div", {
      className: "cmodal__dialog"
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "cmodal__close",
      onClick: onClose,
      "aria-label": "Close"
    }, CloseIcon), /*#__PURE__*/React.createElement("span", {
      className: "cmodal__kicker"
    }, /*#__PURE__*/React.createElement("span", {
      className: "conn__bar" + (dashed ? " conn__bar--dashed" : ""),
      style: dashed ? undefined : {
        background: TYPE_COLOR[conn.type]
      }
    }), LINE_TYPE[conn.type], " connection"), /*#__PURE__*/React.createElement("h2", {
      className: "cmodal__title",
      id: "cmodal-title"
    }, conn.name), /*#__PURE__*/React.createElement("div", {
      className: "cmodal__pair"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cmodal__chip"
    }, /*#__PURE__*/React.createElement("span", {
      className: "smap__dot",
      style: {
        background: CAT_COLOR[a.cat]
      }
    }), a.label), /*#__PURE__*/React.createElement("span", {
      className: "cmodal__arrow",
      "aria-hidden": "true"
    }, ArrowRight), /*#__PURE__*/React.createElement("span", {
      className: "cmodal__chip"
    }, /*#__PURE__*/React.createElement("span", {
      className: "smap__dot",
      style: {
        background: CAT_COLOR[b.cat]
      }
    }), b.label)), /*#__PURE__*/React.createElement("div", {
      className: "cmodal__elabel"
    }, "Effect on the user"), /*#__PURE__*/React.createElement("p", {
      className: "cmodal__effect"
    }, conn.effect)));
  }

  /** App system detail page: overview, core loop, the interactive map, the key
   *  insight, what makes it work, and a link to the full case study. */
  function SystemDetailPage() {
    const [active, setActive] = useState(null);
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "mech-head",
      "aria-labelledby": "sys-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "systems.html"
    }, "Systems"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "\u203A"), /*#__PURE__*/React.createElement("span", null, "Duolingo")), /*#__PURE__*/React.createElement("div", {
      className: "sys-meta"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: "neutral",
      variant: "outline"
    }, "App"), /*#__PURE__*/React.createElement("span", {
      className: "sys-cat"
    }, /*#__PURE__*/React.createElement("span", {
      className: "sys-cat__dot",
      style: {
        background: CAT_COLOR.retention
      }
    }), "Language learning")), /*#__PURE__*/React.createElement("h1", {
      id: "sys-h"
    }, "The Duolingo system"), /*#__PURE__*/React.createElement("p", {
      className: "mech-head__def"
    }, "How a daily streak, a weekly league, and a small soft economy keep a slow goal, learning a language, alive one short session at a time."))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sys-read"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section",
      style: {
        marginBottom: "clamp(28px, 4vw, 44px)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Overview"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title"
    }, "The design logic"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose"
    }, /*#__PURE__*/React.createElement("p", null, "Duolingo's system is built around one fragile thing worth protecting: the streak. Everything else, the leagues, the hearts, the quests, exists to make the daily return feel earned, social, and a little costly to skip. The logic is to take a slow goal that is easy to abandon, learning a language, and wrap it in faster loops that pay out today while the real progress accrues quietly underneath."))), /*#__PURE__*/React.createElement("div", {
      className: "mech-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Core loop"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title"
    }, "The mechanic sequence"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose"
    }, /*#__PURE__*/React.createElement("p", null, "The loop starts with a single lesson. Finishing it earns XP and advances the streak, which loss aversion immediately reframes as something you could lose. That same XP drops you into a weekly league, so practice doubles as competition. Mistakes spend hearts, and empty hearts point toward gems, which the day's quests are busy paying back. Every path leads to the same place: the next lesson.")))))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight sys-mapsec",
      "aria-labelledby": "map-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "smap-head"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "smap-head__t",
      id: "map-h"
    }, "The system map"), /*#__PURE__*/React.createElement("span", {
      className: "smap-head__hint"
    }, "Tap any + on a connection to see how the two mechanics interact")), /*#__PURE__*/React.createElement("div", {
      className: "smap-stage"
    }, /*#__PURE__*/React.createElement(InteractiveMap, {
      onOpen: setActive
    }), /*#__PURE__*/React.createElement(MapLegend, null)), /*#__PURE__*/React.createElement(MechanicList, null))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sys-insight"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sys-insight__k"
    }, "Key insight"), /*#__PURE__*/React.createElement("p", null, "The streak works less as a prize than as something a user has already built. Once a number feels like theirs, the reason to practice the next day shifts from making progress to keeping what they have, which tends to be a steadier pull than progress on its own.")))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight",
      style: {
        paddingTop: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sys-read"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What makes it work"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title"
    }, "No single mechanic carries the weight"), /*#__PURE__*/React.createElement("div", {
      className: "mech-prose"
    }, /*#__PURE__*/React.createElement("p", null, "The system holds because the load is shared. The streak supplies the reason to return, leagues supply the company, hearts supply the stakes, and quests supply the small wins along the way. Remove any one and the others still stand, which is the difference between a system and a pile of features. The lesson sits at the center of all of them, so the one action the app needs from you is the action every mechanic is quietly arranged around.")))))), /*#__PURE__*/React.createElement("section", {
      className: "band--tight",
      style: {
        paddingTop: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("a", {
      className: "cscard",
      href: "case-studies.html"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cscard__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cscard__k"
    }, "Full case study"), /*#__PURE__*/React.createElement("div", {
      className: "cscard__t"
    }, "See every Duolingo mechanic up close"), /*#__PURE__*/React.createElement("p", {
      className: "cscard__p"
    }, "The case study walks each mechanic in the map with annotated screenshots from the app and the takeaways a product team can use.")), /*#__PURE__*/React.createElement("span", {
      className: "cscard__go"
    }, "Read the case study ", ArrowIcon)))), active && /*#__PURE__*/React.createElement(ConnectionModal, {
      conn: active,
      onClose: () => setActive(null)
    }));
  }
  Object.assign(GBSite, {
    SystemDetailPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SystemDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Systems.jsx
try { (() => {
/* Website kit — Systems index. A grid of the apps whose mechanic loops we have
   mapped, with the app name, a one-line description of what the system achieves,
   and the mechanics the loop runs.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Tag,
    Badge
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const LockIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "4",
    y: "11",
    width: "16",
    height: "10",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V8a4 4 0 0 1 8 0v3"
  }));
  const ArrowIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "17",
    x2: "17",
    y2: "7"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "7 7 17 7 17 17"
  }));

  /* Each system: its nodes ({ label }) are the mechanics the loop runs. */
  const SYSTEMS = [{
    name: "Royal Match",
    type: "Game",
    locked: false,
    active: 1,
    desc: "Turns daily play into spend without ever feeling like a punishment.",
    nodes: {
      A: {
        label: "Lives",
        cat: "monetization"
      },
      B: {
        label: "Daily reward",
        cat: "retention"
      },
      C: {
        label: "Events",
        cat: "monetization"
      },
      D: {
        label: "Season pass",
        cat: "monetization"
      }
    },
    href: "#royal-match"
  }, {
    name: "Duolingo",
    type: "App",
    locked: true,
    active: 0,
    desc: "A streak and loss aversion make a daily lesson feel unmissable.",
    nodes: {
      A: {
        label: "Streak",
        cat: "retention"
      },
      B: {
        label: "Loss aversion",
        cat: "retention"
      },
      C: {
        label: "Leaderboard",
        cat: "social"
      },
      D: {
        label: "Quests",
        cat: "retention"
      }
    }
  }, {
    name: "Monopoly Go",
    type: "Game",
    locked: true,
    active: 0,
    desc: "Dice as a resource keep players cycling back between refills.",
    nodes: {
      A: {
        label: "Dice",
        cat: "monetization"
      },
      B: {
        label: "Collections",
        cat: "retention"
      },
      C: {
        label: "Events",
        cat: "monetization"
      },
      D: {
        label: "Teams",
        cat: "social"
      }
    }
  }, {
    name: "Strava",
    type: "App",
    locked: true,
    active: 0,
    desc: "Segments and social ties turn solo workouts into standing.",
    nodes: {
      A: {
        label: "Segments",
        cat: "social"
      },
      B: {
        label: "Milestones",
        cat: "retention"
      },
      C: {
        label: "Challenges",
        cat: "social"
      },
      D: {
        label: "Badges",
        cat: "retention"
      }
    }
  }, {
    name: "Candy Crush Saga",
    type: "Game",
    locked: true,
    active: 0,
    desc: "Lives and a long map keep the next level one session away.",
    nodes: {
      A: {
        label: "Lives",
        cat: "monetization"
      },
      B: {
        label: "Progress",
        cat: "retention"
      },
      C: {
        label: "Events",
        cat: "monetization"
      },
      D: {
        label: "Daily reward",
        cat: "retention"
      }
    }
  }, {
    name: "Headspace",
    type: "App",
    locked: true,
    active: 0,
    desc: "A run streak makes a meditation habit visible and worth protecting.",
    nodes: {
      A: {
        label: "Streak",
        cat: "retention"
      },
      B: {
        label: "Milestones",
        cat: "retention"
      },
      C: {
        label: "Progress",
        cat: "retention"
      },
      D: {
        label: "Onboarding",
        cat: "retention"
      }
    }
  }, {
    name: "Clash of Clans",
    type: "Game",
    locked: true,
    active: 2,
    desc: "Clans turn a player's return into an obligation to teammates.",
    nodes: {
      A: {
        label: "Clans",
        cat: "social"
      },
      B: {
        label: "Tiers",
        cat: "retention"
      },
      C: {
        label: "Season pass",
        cat: "monetization"
      },
      D: {
        label: "Challenges",
        cat: "social"
      }
    }
  }, {
    name: "Starbucks",
    type: "App",
    locked: true,
    active: 0,
    desc: "Tiers and limited offers make the next order worth tracking.",
    nodes: {
      A: {
        label: "Tiers",
        cat: "retention"
      },
      B: {
        label: "Milestones",
        cat: "retention"
      },
      C: {
        label: "Offers",
        cat: "monetization"
      },
      D: {
        label: "Referral",
        cat: "social"
      }
    }
  }, {
    name: "Coin Master",
    type: "Game",
    locked: true,
    active: 0,
    desc: "A spin's variable reward feeds collections and a social loop.",
    nodes: {
      A: {
        label: "Spin",
        cat: "monetization"
      },
      B: {
        label: "Variable reward",
        cat: "retention"
      },
      C: {
        label: "Collections",
        cat: "retention"
      },
      D: {
        label: "Gifting",
        cat: "social"
      }
    }
  }];
  function SystemCard({
    sys
  }) {
    const mechanics = Object.values(sys.nodes).map(n => n.label);
    return /*#__PURE__*/React.createElement("a", {
      className: "csc" + (sys.locked ? " csc--locked" : ""),
      href: sys.href || "#subscribe"
    }, /*#__PURE__*/React.createElement("div", {
      className: "csc__top"
    }, /*#__PURE__*/React.createElement(Tag, {
      category: "neutral",
      variant: "outline"
    }, sys.type), /*#__PURE__*/React.createElement("span", {
      className: "csc__badge"
    }, sys.locked ? /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      variant: "outline",
      icon: LockIcon
    }, "For subscribers") : /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      variant: "soft"
    }, "Free"))), /*#__PURE__*/React.createElement("h3", {
      className: "csc__name"
    }, sys.name), /*#__PURE__*/React.createElement("p", {
      className: "csc__desc"
    }, sys.desc), /*#__PURE__*/React.createElement("div", {
      className: "csc__tags"
    }, mechanics.map(m => /*#__PURE__*/React.createElement("span", {
      className: "pillchip",
      key: m
    }, m))), /*#__PURE__*/React.createElement("div", {
      className: "csc__foot"
    }, /*#__PURE__*/React.createElement("span", {
      className: "csc__count"
    }, /*#__PURE__*/React.createElement("b", null, mechanics.length), " mechanics linked"), /*#__PURE__*/React.createElement("span", {
      className: "csc__go"
    }, sys.locked ? "Subscribe to read" : "Explore the map", " ", ArrowIcon)));
  }

  /** Systems index: the signature asset, every app's loop drawn in the house language. */
  function SystemsPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "cs-head",
      "aria-labelledby": "sys-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("nav", {
      className: "crumb",
      "aria-label": "Breadcrumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#library"
    }, "Library"), /*#__PURE__*/React.createElement("span", {
      className: "crumb__sep",
      "aria-hidden": "true"
    }, "/"), /*#__PURE__*/React.createElement("span", null, "Systems")), /*#__PURE__*/React.createElement("div", {
      className: "eyebrow cs-head__eyebrow"
    }, "The library"), /*#__PURE__*/React.createElement("h1", {
      id: "sys-h"
    }, "Systems"), /*#__PURE__*/React.createElement("p", {
      className: "cs-head__def"
    }, "A system is the ", /*#__PURE__*/React.createElement("b", null, "loop"), ", not the parts. A system map shows how one app's mechanics connect and feed each other: the streak that protects a reward, the reward that pulls the next session. Each map is drawn in our house language, nodes for mechanics and red lines for the connections that carry the most weight."))), /*#__PURE__*/React.createElement("div", {
      className: "container cs-wrap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cs-bar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__count"
    }, /*#__PURE__*/React.createElement("b", null, SYSTEMS.length), " system maps"), /*#__PURE__*/React.createElement("span", {
      className: "cs-bar__hint"
    }, "Updated weekly")), /*#__PURE__*/React.createElement("div", {
      className: "csgrid"
    }, SYSTEMS.map(s => /*#__PURE__*/React.createElement(SystemCard, {
      key: s.name,
      sys: s
    })))));
  }
  Object.assign(GBSite, {
    SystemsPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Systems.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/WorkWithUs.jsx
try { (() => {
/* Website kit — Work with us (the consulting engagement). One job: book a
   discovery call. Hero states the visitor's problem in their words; the approach
   explains the differentiator (start from what the app already has) as three
   steps; deliverables are concrete artifacts; a short "who this is for"; and a
   calm closing call to action. No pricing, testimonials, urgency, or game
   iconography.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
  const React = window.React;
  const {
    Button
  } = window.GameBizDesignSystem_1aad9e;
  const GBSite = window.GBSite = window.GBSite || {};
  const DownIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "5",
    x2: "12",
    y2: "19"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "6 13 12 19 18 13"
  }));
  const CheckIcon = /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }));
  const STEPS = [{
    h: "Discovery",
    p: "We start with your goals and pain points: where users stall, what should happen instead."
  }, {
    h: "Analysis",
    p: "We map your app's features against our 22-mechanic framework and study what your category uses, misses, and where the openings are."
  }, {
    h: "Build together",
    p: "Working sessions with your product team, ending in an evidence-backed roadmap: which mechanics, why, what they require, in what order."
  }];
  const DELIVERABLES = [{
    h: "The feature and mechanic map of your app",
    p: "Every feature you already ship, mapped against the 22-mechanic framework, so you can see what your product is quietly already doing."
  }, {
    h: "The category comparison",
    p: "What apps in your category rely on, what they leave untouched, and the specific openings that comparison reveals for you."
  }, {
    h: "The prioritized roadmap",
    p: "The mechanics worth building, in order, each with what it requires of your product and why it earns its place."
  }];

  /** Work with us page body. */
  function WorkWithUsPage() {
    return /*#__PURE__*/React.createElement("main", {
      id: "main"
    }, /*#__PURE__*/React.createElement("section", {
      className: "ww-hero",
      "aria-labelledby": "ww-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ww-hero__in"
    }, /*#__PURE__*/React.createElement("div", {
      className: "eyebrow"
    }, "Work with us"), /*#__PURE__*/React.createElement("h1", {
      id: "ww-h"
    }, "Your users sign up.", /*#__PURE__*/React.createElement("br", null), "Then they drift away."), /*#__PURE__*/React.createElement("p", {
      className: "ww-hero__sub"
    }, "We help product teams turn engagement into retention and conversion, using mechanics proven across hundreds of the world's best apps and games."), /*#__PURE__*/React.createElement("div", {
      className: "ww-hero__cta"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      as: "a",
      href: "#discovery"
    }, "Book a discovery call"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      as: "a",
      href: "#approach",
      trailingIcon: DownIcon
    }, "See how we work"))))), /*#__PURE__*/React.createElement("section", {
      className: "band band--sheet",
      id: "approach",
      "aria-labelledby": "appr-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ww-approach"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ww-approach__lede"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "The approach"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "appr-h"
    }, "We start from what your app already has"), /*#__PURE__*/React.createElement("p", {
      className: "ww-lede"
    }, "We don't arrive with a list of features to bolt on. We study the features you already have, your users, and your category, then find the mechanics that will take root in your product. A mechanic that works brilliantly in one app fails in another; the difference is what's underneath it.")), /*#__PURE__*/React.createElement("ol", {
      className: "ww-steps"
    }, STEPS.map((s, i) => /*#__PURE__*/React.createElement("li", {
      className: "ww-step",
      key: s.h
    }, /*#__PURE__*/React.createElement("span", {
      className: "ww-step__num",
      "aria-hidden": "true"
    }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("div", {
      className: "ww-step__text"
    }, /*#__PURE__*/React.createElement("h3", null, s.h), /*#__PURE__*/React.createElement("p", null, s.p)))))))), /*#__PURE__*/React.createElement("section", {
      className: "band",
      "aria-labelledby": "deliv-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "What you walk away with"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "deliv-h"
    }, "Artifacts, not promises"), /*#__PURE__*/React.createElement("div", {
      className: "ww-deliv"
    }, DELIVERABLES.map(d => /*#__PURE__*/React.createElement("div", {
      className: "ww-deliv__item",
      key: d.h
    }, /*#__PURE__*/React.createElement("span", {
      className: "ww-deliv__check",
      "aria-hidden": "true"
    }, CheckIcon), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", null, d.h), /*#__PURE__*/React.createElement("p", null, d.p))))))), /*#__PURE__*/React.createElement("section", {
      className: "band",
      "aria-labelledby": "who-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ww-who"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mech-section__kicker"
    }, "Who this is for"), /*#__PURE__*/React.createElement("h2", {
      className: "mech-section__title",
      id: "who-h"
    }, "Product teams in any category"), /*#__PURE__*/React.createElement("p", {
      className: "ww-who__p"
    }, "Finance, education, health, culture \u2014 anywhere engagement matters. You don't need to know anything about game mechanics, or even use the word. Understanding which ones fit your product is exactly what we're for.")))), /*#__PURE__*/React.createElement("section", {
      className: "band band--ink ww-final",
      id: "discovery",
      "aria-labelledby": "final-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ww-final__in"
    }, /*#__PURE__*/React.createElement("h2", {
      id: "final-h"
    }, "Book a discovery call"), /*#__PURE__*/React.createElement("p", null, "A conversation about your goals and your app. No preparation needed."), /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      as: "a",
      href: "mailto:hello@gamebiz.studio"
    }, "Book a discovery call")))));
  }
  Object.assign(GBSite, {
    WorkWithUsPage
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/WorkWithUs.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Card = __ds_scope.Card;

__ds_ns.LockedNotice = __ds_scope.LockedNotice;

__ds_ns.MechanicCard = __ds_scope.MechanicCard;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.SystemMap = __ds_scope.SystemMap;

__ds_ns.AnnotatedScreenshot = __ds_scope.AnnotatedScreenshot;

__ds_ns.Input = __ds_scope.Input;

})();

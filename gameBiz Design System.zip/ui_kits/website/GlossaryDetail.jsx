/* Website kit — Glossary item detail (Loss Aversion). Title block with slug and
   full definition, a "Where you see this in practice" section of linked mechanic
   cards, and a sidebar with related mechanics, more terms, and an export action.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { MechanicCard } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const TERM = {
  term: "Loss Aversion",
  category: "retention",
  categoryLabel: "Retention",
  definition:
    "Loss aversion is the finding that a loss feels roughly twice as powerful as an equivalent gain — losing ten dollars stings more than finding ten pleases. People will work harder to avoid giving something up than to acquire something of the same value. In products, the lever is framing: once progress, status, or a resource is presented as already belonging to the user, the prospect of losing it becomes a stronger motivator than the promise of more. A streak isn't compelling because of what the next day adds; it's compelling because a missed day takes the whole count away.",
  /* Mechanics that put the principle to work. */
  practice: [
    { number: 1, category: "retention", name: "Streak / Streak Bonus",
      definition: "The count is framed as something already earned, so a missed day reads as ground given up rather than a reward skipped.",
      contextTags: ["Habit", "Retention"], href: "mechanic-streak.html" },
    { number: 9, category: "monetization", name: "Energy / Lives",
      definition: "Once the resource runs low, users act to avoid losing access to play — fear of being locked out drives the refill.",
      contextTags: ["Pacing", "Games"], href: "mechanics.html" },
    { number: 22, category: "retention", name: "Login Calendar",
      definition: "A grid that fills with each visit turns attendance into a record, and a single gap breaks something the user can see they built.",
      contextTags: ["Habit", "Retention"], href: "mechanics.html" },
  ],
  relatedMechanics: [
    { name: "Streak / Streak Bonus", cat: "retention", href: "mechanic-streak.html" },
    { name: "Energy / Lives", cat: "monetization", href: "mechanics.html" },
    { name: "Login Calendar", cat: "retention", href: "mechanics.html" },
    { name: "Season Pass", cat: "monetization", href: "mechanics.html" },
  ],
  moreTerms: [
    { name: "Sunk Cost", href: "glossary-sunk-cost.html" },
    { name: "Scarcity", href: "glossary-scarcity.html" },
    { name: "FOMO", href: "glossary-fomo.html" },
    { name: "Endowed Progress", href: "glossary-endowed-progress.html" },
  ],
};

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);

function TitleBlock() {
  return (
    <section className="cs-head sheet-head" aria-labelledby="term-h">
      <div className="container">
        <nav className="crumb" aria-label="Breadcrumb">
          <a href="index.html">Library</a>
          <span className="crumb__sep" aria-hidden="true">/</span>
          <a href="glossary.html">Glossary</a>
          <span className="crumb__sep" aria-hidden="true">/</span>
          <span>{TERM.term}</span>
        </nav>
        <div className="sheet-head__slug">
          <span className="eyebrow">Glossary term</span>
          <span className="sheet-head__dot" aria-hidden="true">·</span>
          <span className="eyebrow eyebrow--muted">{TERM.categoryLabel}</span>
        </div>
        <h1 id="term-h">{TERM.term}</h1>
        <p className="cs-head__def term-def">{TERM.definition}</p>
      </div>
    </section>
  );
}

function Practice() {
  return (
    <section aria-labelledby="practice-h">
      <div className="mech-section__kicker">Where you see this in practice</div>
      <h2 className="mech-section__title" id="practice-h">The mechanics that lean on it</h2>
      <div className="practice-grid">
        {TERM.practice.map((m) => <MechanicCard key={m.name} {...m} />)}
      </div>
    </section>
  );
}

function Sidebar() {
  return (
    <aside className="mech-aside" aria-label="Related">
      <div className="amod">
        <h3>Related mechanics</h3>
        <div className="amod__list">
          {TERM.relatedMechanics.map((m) => (
            <a className="amod__item" href={m.href} key={m.name}>
              <span className="amod__dot" style={{ background: `var(--cat-${m.cat})` }} />
              <span className="amod__name">{m.name}</span>
            </a>
          ))}
        </div>
      </div>

      <div className="amod">
        <h3>More terms</h3>
        <div className="amod__list">
          {TERM.moreTerms.map((t) => (
            <a className="amod__item" href={t.href} key={t.name}>
              <span className="amod__name">{t.name}</span>
            </a>
          ))}
        </div>
        <a className="amod__viewall" href="glossary.html">View all terms {ArrowIcon}</a>
      </div>
    </aside>
  );
}

/** Glossary item detail page body. */
function GlossaryDetailPage() {
  return (
    <main id="main">
      <TitleBlock />
      <div className="container">
        <div className="mech-body">
          <div className="mech-main">
            <Practice />
          </div>
          <Sidebar />
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { GlossaryDetailPage });
})();

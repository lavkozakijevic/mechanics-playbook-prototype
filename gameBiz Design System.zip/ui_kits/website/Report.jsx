/* Website kit — Category report (Gamification in Finance). A single category
   report landing: header, headline stats, the apps analyzed, a numbered chapter
   index, a full-report CTA card, and a ranked "opportunities at a glance" list.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const GBSite = (window.GBSite = window.GBSite || {});

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);
const RightIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
);

const REPORT = {
  label: "Category Report · 2026",
  title: "Gamification in Finance",
  overview:
    "Banking, investing, and budgeting apps have quietly become some of the most gamified products people use every day. This report maps how fifteen leading finance apps apply the mechanics in our framework: what the category already leans on, where the patterns have hardened into convention, and which mechanics remain wide open for a product willing to try them. Every finding is drawn from the live apps and measured against the twenty-two-mechanic framework.",
  stats: [
    { value: "15", label: "Apps analyzed" },
    { value: "22", label: "Mechanics mapped" },
    { value: "7", label: "Chapters" },
  ],
  apps: [
    { ab: "Rv", name: "Revolut" }, { ab: "Mo", name: "Monzo" }, { ab: "CA", name: "Cash App" },
    { ab: "Rb", name: "Robinhood" }, { ab: "Ch", name: "Chime" }, { ab: "Ac", name: "Acorns" },
    { ab: "Kl", name: "Klarna" }, { ab: "PP", name: "PayPal" }, { ab: "Nu", name: "Nubank" },
    { ab: "Ve", name: "Venmo" }, { ab: "St", name: "Stash" }, { ab: "Pl", name: "Plum" },
    { ab: "Cl", name: "Cleo" }, { ab: "Sp", name: "Step" }, { ab: "Cu", name: "Current" },
  ],
  chapters: [
    { title: "The state of gamification in finance", desc: "Where the category stands today, and why money apps reach for game mechanics at all." },
    { title: "Streaks and the savings habit", desc: "How finance apps borrow the daily streak to turn saving into a routine worth protecting." },
    { title: "Progress, goals, and the budgeting loop", desc: "Goal bars and milestones that make an abstract balance feel close enough to chase." },
    { title: "Rewards, cashback, and variable payoffs", desc: "Where finance leans on variable rewards, and the line between delight and dark pattern." },
    { title: "Social proof and money", desc: "Leaderboards, peers, and the uneasy place competition holds in personal finance." },
    { title: "Onboarding the nervous first-time user", desc: "Activation goals and guided setup for a category where trust is the first hurdle." },
    { title: "The open opportunities", desc: "The mechanics finance has barely touched, and what it would take to use them well." },
  ],
  cta: {
    title: "Read the full Finance report",
    desc: "Seven chapters, fifteen apps, and a working list of the mechanics most worth trying in a finance product, each with annotated examples from the apps that do it best.",
    stats: [
      { value: "7", label: "Chapters" },
      { value: "15", label: "Apps" },
      { value: "48", label: "Examples" },
      { value: "16", label: "Opportunities" },
    ],
  },
  opportunities: [
    { name: "Streak / Streak Bonus", desc: "Reward consecutive days of saving or logging a transaction.", nov: "low" },
    { name: "Milestone Rewards", desc: "Mark a savings goal at meaningful balance thresholds.", nov: "low" },
    { name: "Progress Bar", desc: "Show how close a goal balance sits to its target.", nov: "low" },
    { name: "Tiers / Levels", desc: "Status tiers that unlock perks as a balance grows.", nov: "low" },
    { name: "Referral Rewards", desc: "A two-sided incentive for inviting a friend to join.", nov: "low" },
    { name: "Daily Reward", desc: "A small bonus for opening the app and checking in.", nov: "mid" },
    { name: "Loss Aversion", desc: "Frame a lapsed streak or missed round-up as ground given up.", nov: "mid" },
    { name: "Variable Rewards", desc: "Randomized cashback or a surprise boost on a deposit.", nov: "mid" },
    { name: "Quests / Missions", desc: "Guided tasks like setting up direct deposit, paid on completion.", nov: "mid" },
    { name: "Badges / Achievements", desc: "Collectible markers for reaching financial milestones.", nov: "mid" },
    { name: "Gifting", desc: "Send a small amount or a boost to another user.", nov: "mid" },
    { name: "Leaderboards", desc: "Rank saving or investing streaks against a peer cohort.", nov: "high" },
    { name: "Season Pass", desc: "A timed track of rewards for sustained engagement.", nov: "high" },
    { name: "Social Challenges", desc: "Group savings goals pursued with friends.", nov: "high" },
    { name: "Collections / Sets", desc: "Complete a set of money habits to earn a reward.", nov: "high" },
    { name: "Limited-Time Events", desc: "Short windows with boosted rates or rewards.", nov: "high" },
  ],
};

const NOV_LABEL = { low: "Low", mid: "Mid", high: "High" };

function ReportPage() {
  return (
    <main id="main">
      {/* Header */}
      <section className="rpt-head" aria-labelledby="rpt-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="index.html">Reports</a>
            <span className="crumb__sep" aria-hidden="true">/</span>
            <span>Finance</span>
          </nav>
          <div className="rpt-label">{REPORT.label}</div>
          <h1 id="rpt-h">{REPORT.title}</h1>
          <p className="rpt-overview">{REPORT.overview}</p>

          {/* Stats row */}
          <div className="rpt-stats">
            {REPORT.stats.map((s) => (
              <div className="rpt-stat" key={s.label}>
                <span className="rpt-stat__num">{s.value}</span>
                <span className="rpt-stat__label">{s.label}</span>
              </div>
            ))}
          </div>

          {/* App icon row */}
          <div className="rpt-apps" aria-label="Apps analyzed in this report">
            {REPORT.apps.map((a) => (
              <span className="rpt-app" key={a.name} title={a.name}>
                <span className="rpt-app__ab" aria-hidden="true">{a.ab}</span>
                <span className="sr-only">{a.name}</span>
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* What the report covers: chapters (left) + full-report CTA card (right) */}
      <section className="band--tight" aria-labelledby="toc-h">
        <div className="container">
          <div className="mech-section__kicker">What the report covers</div>
          <h2 className="mech-section__title" id="toc-h">Seven chapters</h2>
          <div className="rpt-covers">
            <ol className="rpt-chapters">
              {REPORT.chapters.map((c, i) => (
                <li className="rpt-chapter" key={c.title}>
                  <a className="rpt-chapter__link" href={`#chapter-${i + 1}`}>
                    <span className="rpt-chapter__n">{String(i + 1).padStart(2, "0")}</span>
                    <span className="rpt-chapter__body">
                      <span className="rpt-chapter__title">{c.title}</span>
                      <span className="rpt-chapter__desc">{c.desc}</span>
                    </span>
                    <span className="rpt-chapter__go" aria-hidden="true">{ArrowIcon}</span>
                  </a>
                </li>
              ))}
            </ol>

            <div className="rpt-cta">
              <div className="rpt-cta__head">
                <div className="rpt-cta__k">The full report</div>
                <h3 className="rpt-cta__t">{REPORT.cta.title}</h3>
                <p className="rpt-cta__p">{REPORT.cta.desc}</p>
                <a className="rpt-cta__go" href="#chapter-1">Start reading {RightIcon}</a>
              </div>
              <div className="rpt-cta__stats">
                {REPORT.cta.stats.map((s) => (
                  <div className="rpt-stat rpt-stat--onink" key={s.label}>
                    <span className="rpt-stat__num">{s.value}</span>
                    <span className="rpt-stat__label">{s.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Opportunities at a glance */}
      <section className="band--tight" style={{ paddingTop: 0 }} aria-labelledby="opp-h">
        <div className="container">
          <div className="mech-section__kicker">Opportunities at a glance</div>
          <h2 className="mech-section__title" id="opp-h">Mechanics for finance apps, ranked by novelty</h2>
          <p className="rpt-opps-note">Novelty is how untapped each mechanic is in finance today, from <b>Low</b> (already conventional) to <b>High</b> (barely touched, and worth the first move).</p>
          <ol className="rpt-opps">
            {REPORT.opportunities.map((o, i) => (
              <li className="rpt-opp" key={o.name}>
                <span className="rpt-opp__n">{String(i + 1).padStart(2, "0")}</span>
                <span className="rpt-opp__main">
                  <span className="rpt-opp__name">{o.name}</span>
                  <span className="rpt-opp__desc">{o.desc}</span>
                </span>
                <span className={`rpt-nov rpt-nov--${o.nov}`}>{NOV_LABEL[o.nov]}</span>
              </li>
            ))}
          </ol>
        </div>
      </section>
    </main>
  );
}

Object.assign(GBSite, { ReportPage });
})();

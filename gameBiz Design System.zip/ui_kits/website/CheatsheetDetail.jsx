/* Website kit — Cheatsheet detail page ("Adding a streak without punishing lapses").
   Title block, five numbered steps (each with a guidance paragraph that names
   real apps inline plus a row of linked app references), and a sidebar with
   related mechanics and the apps featured, linked to their case studies.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Badge } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const IconArrow = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
);

/* App reference targets. Every app named in the guide resolves through here so
   inline mentions and the sidebar both point at the same case study. */
const APPS = {
  Duolingo:  { cat: "Education",    href: "case-studies.html#duolingo" },
  Headspace: { cat: "Health",      href: "case-studies.html#headspace" },
  Finch:     { cat: "Health",      href: "case-studies.html#finch" },
  Calm:      { cat: "Health",      href: "case-studies.html#calm" },
  Snapchat:  { cat: "Social",      href: "case-studies.html#snapchat" },
};

/* An inline app mention — a quiet link that resolves to the app's case study. */
function App({ name }) {
  const a = APPS[name];
  return <a className="applink" href={a ? a.href : "case-studies.html"}>{name}</a>;
}

const SHEET = {
  n: 2,
  category: "retention",
  title: "Adding a streak without punishing lapses",
  intro:
    "A streak is one of the most reliable ways to turn a product into a daily habit — and one of the easiest to get wrong. Push too hard on the reset and a single missed day reads as failure, and the user who cared most is the one who leaves. This guide walks through building a streak that earns the return without making one bad day a reason to quit.",
  steps: [
    {
      title: "Start the count only after the first real win",
      body: (
        <p>
          A streak is only worth protecting once there is something to protect. Wait until a
          user has felt the core value before the counter appears — <App name="Duolingo" /> holds
          its streak back until the first lesson is complete, and <App name="Headspace" /> begins
          a run streak the day a user finishes their first session, not the day they sign up.
          Introduce it too early and the number means nothing; the user has invested nothing yet,
          so there is no loss in walking away.
        </p>
      ),
      apps: ["Duolingo", "Headspace"],
    },
    {
      title: "Set a daily target low enough to keep on a bad day",
      body: (
        <p>
          The streak survives on the days a user almost skips. Pick a target they can clear in a
          minute or two, even when motivation is gone. <App name="Duolingo" /> keeps lessons
          short enough that protecting the count feels nearly free, and <App name="Calm" /> counts
          any session — a meditation, a Sleep Story, a single breathing exercise — so the bar to
          keep the streak alive is whatever the user has time for tonight.
        </p>
      ),
      apps: ["Duolingo", "Calm"],
    },
    {
      title: "Build the safety net before the streak gets long",
      body: (
        <p>
          The longer a streak runs, the more a reset hurts — and the more likely it is to end the
          habit for good. Ship a forgiveness mechanic before users have months on the line.{" "}
          <App name="Duolingo" />'s Streak Freeze quietly spends to cover a missed day, and its
          weekend amnesty forgives the occasional slip without the user ever asking. The freeze is
          not a leak in the system; it is what lets a streak survive real life.
        </p>
      ),
      apps: ["Duolingo"],
    },
    {
      title: "Frame a miss as a pause, not a failure",
      body: (
        <p>
          When a streak does break, the words around it decide whether the user comes back. Avoid
          language that scolds. <App name="Finch" /> wraps the whole loop in care for a virtual
          pet, so a missed day reads as the pet needing attention rather than the user failing a
          test, and <App name="Headspace" /> keeps its tone encouraging even at zero. The same
          reset, framed kindly, is the difference between a guilty return and no return at all.
        </p>
      ),
      apps: ["Finch", "Headspace"],
    },
    {
      title: "Reward the milestones, not just the daily tick",
      body: (
        <p>
          A streak that only ever increments by one gets quiet over time. Give the count fresh
          meaning at thresholds. <App name="Headspace" /> marks 10, 30, and 100 days with
          milestones that make the journey visible, while <App name="Snapchat" /> escalates the
          flame and emoji beside a Snapstreak as it grows. Each marker is a small new reason to
          keep going, layered on top of the habit the streak already built.
        </p>
      ),
      apps: ["Headspace", "Snapchat"],
    },
  ],
  relatedMechanics: [
    { name: "Streak / Streak Bonus", cat: "retention", href: "mechanic-streak.html" },
    { name: "Loss Aversion", cat: "retention", href: "mechanics.html" },
    { name: "Daily Reward", cat: "retention", href: "mechanics.html" },
    { name: "Login Calendar", cat: "retention", href: "mechanics.html" },
  ],
};

/* The featured apps, in the order they first appear, for the sidebar list. */
const FEATURED = ["Duolingo", "Headspace", "Calm", "Finch", "Snapchat"];

function TitleBlock() {
  return (
    <section className="cs-head sheet-head" aria-labelledby="sheet-h">
      <div className="container">
        <nav className="crumb" aria-label="Breadcrumb">
          <a href="index.html">Library</a>
          <span className="crumb__sep" aria-hidden="true">/</span>
          <a href="cheatsheets.html">Cheatsheets</a>
          <span className="crumb__sep" aria-hidden="true">/</span>
          <span>Streaks without punishing lapses</span>
        </nav>
        <div className="sheet-head__slug">
          <span className="eyebrow">Cheatsheet {String(SHEET.n).padStart(2, "0")}</span>
          <span className="sheet-head__dot" aria-hidden="true">·</span>
          <span className="eyebrow eyebrow--muted">Retention</span>
        </div>
        <h1 id="sheet-h">{SHEET.title}</h1>
        <p className="cs-head__def">{SHEET.intro}</p>
        <div className="sheet-head__meta">
          <Badge tone="ok" variant="soft">Free guide</Badge>
          <span className="sheet-head__count"><b>{SHEET.steps.length}</b> steps</span>
        </div>
      </div>
    </section>
  );
}

function Steps() {
  return (
    <section aria-labelledby="steps-h">
      <div className="mech-section__kicker">The guide</div>
      <h2 className="mech-section__title" id="steps-h">Five steps to a forgiving streak</h2>
      <ol className="steps">
        {SHEET.steps.map((s, i) => (
          <li className="step" key={s.title}>
            <span className="step__n">{String(i + 1).padStart(2, "0")}</span>
            <div className="step__main">
              <h3 className="step__title">{s.title}</h3>
              <div className="step__body">{s.body}</div>
              <div className="step__refs">
                <span className="step__refs-label">Seen in</span>
                {s.apps.map((a) => (
                  <a className="refchip" href={APPS[a] ? APPS[a].href : "case-studies.html"} key={a}>{a}</a>
                ))}
              </div>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

function Sidebar() {
  return (
    <aside className="mech-aside" aria-label="Related">
      <div className="amod">
        <h3>Related mechanics</h3>
        <div className="amod__list">
          {SHEET.relatedMechanics.map((m) => (
            <a className="amod__item" href={m.href} key={m.name}>
              <span className="amod__dot" style={{ background: `var(--cat-${m.cat})` }} />
              <span className="amod__name">{m.name}</span>
            </a>
          ))}
        </div>
      </div>
      <div className="amod">
        <h3>Apps in this cheatsheet</h3>
        <div className="amod__list">
          {FEATURED.map((a) => (
            <a className="amod__item" href={APPS[a].href} key={a}>
              <span className="amod__name">{a}</span>
              <span className="amod__meta">{APPS[a].cat}</span>
            </a>
          ))}
        </div>
      </div>
    </aside>
  );
}

/** Cheatsheet detail page body. */
function CheatsheetDetailPage() {
  return (
    <main id="main">
      <TitleBlock />
      <div className="container">
        <div className="mech-body">
          <div className="mech-main">
            <Steps />
          </div>
          <Sidebar />
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { CheatsheetDetailPage });
})();

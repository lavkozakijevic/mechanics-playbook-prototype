/* Website kit — Glossary index. Title block plus a grid of term cards, each with
   a term name, a truncated definition, and the mechanics it relates to. Cards
   link to individual glossary item detail pages.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const GBSite = (window.GBSite = window.GBSite || {});

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);

/* The 15 terms, alphabetical. `cat` colours the letter marker; `mechanics` are
   the related mechanic tags; the card links to glossary-<slug>.html. */
const TERMS = [
  { term: "Anchoring", cat: "monetization",
    def: "The first number a user sees becomes the reference every later price is judged against. Show the higher tier first and the one you want them to pick reads as a deal.",
    mechanics: ["Season Pass", "Cosmetics"] },
  { term: "Commitment & Consistency", cat: "retention",
    def: "Once a user takes a small, visible step, they act to stay consistent with it. A tiny first commitment makes the larger one that follows feel like keeping their word.",
    mechanics: ["Onboarding Goal", "Streak"] },
  { term: "Endowed Progress", cat: "retention",
    def: "People work harder toward a goal when handed a head start. A loyalty card stamped twice on day one feels closer to finished than an identical empty one.",
    mechanics: ["Progress Bar", "Login Calendar"] },
  { term: "Flow State", cat: "retention",
    def: "The absorbed focus that arrives when challenge and skill stay in balance. Tune difficulty to the user and the next action pulls them along without friction.",
    mechanics: ["Quests / Missions", "Tiers / Levels"] },
  { term: "FOMO", cat: "monetization",
    def: "The fear of missing out: the unease that others are getting a reward you won't. A countdown or a limited drop turns idle interest into a reason to act now.",
    mechanics: ["Limited-Time Events", "Daily Reward"] },
  { term: "Fresh Start Effect", cat: "retention",
    def: "People are most motivated to pursue goals at temporal landmarks — a Monday, a birthday, a new month. Time a prompt to one and the intent is already there.",
    mechanics: ["Streak", "Season Pass"] },
  { term: "Goal Gradient", cat: "retention",
    def: "Effort accelerates as a goal draws closer. The nearer the finish line appears, the faster users move toward it, so make the final stretch feel within reach.",
    mechanics: ["Progress Bar", "Milestone Rewards"] },
  { term: "Loss Aversion", cat: "retention",
    def: "A loss hurts about twice as much as the same-size gain feels good. Framing progress as already earned and at risk makes users act to keep it rather than chase more.",
    mechanics: ["Streak", "Energy / Lives"] },
  { term: "Operant Conditioning", cat: "retention",
    def: "Behaviour followed by a reward repeats; behaviour followed by nothing fades. The timing and pattern of rewards shape the habit more than their size.",
    mechanics: ["Variable Rewards", "Daily Reward"] },
  { term: "Reciprocity", cat: "social",
    def: "A gift creates a quiet pull to give something back. Offer real value first and users grow more willing to subscribe, refer a friend, or return the favour.",
    mechanics: ["Gifting", "Referral Rewards"] },
  { term: "Scarcity", cat: "monetization",
    def: "Limited supply or a closing window raises perceived value. When something might run out, users weigh it more heavily and decide faster than they otherwise would.",
    mechanics: ["Limited-Time Events", "Energy / Lives"] },
  { term: "Social Proof", cat: "social",
    def: "People read others' behaviour to decide their own. Showing what peers are doing — counts, streaks, leaderboards — lowers the bar to follow along.",
    mechanics: ["Leaderboards", "Social Challenges"] },
  { term: "Sunk Cost", cat: "retention",
    def: "The more a user has invested, the harder it becomes to walk away. Visible accumulated progress makes quitting feel like throwing that investment out.",
    mechanics: ["Streak", "Collections / Sets"] },
  { term: "Variable Reward", cat: "retention",
    def: "Rewards that vary in size and timing keep the next outcome uncertain. That uncertainty is exactly what makes checking one more time feel worth it.",
    mechanics: ["Mystery Reward", "Variable Rewards"] },
  { term: "Zeigarnik Effect", cat: "retention",
    def: "Unfinished tasks linger in the mind more than finished ones. A half-complete profile or progress bar creates a small tension users feel compelled to resolve.",
    mechanics: ["Progress Bar", "Onboarding Goal"] },
];

function TermCard({ t }) {
  return (
    <a className="gcard" href={`glossary-${slug(t.term)}.html`}>
      <div className="gcard__top">
        <span className="gcard__letter" style={{ color: `var(--cat-${t.cat})` }}>{t.term.charAt(0)}</span>
        <span className="gcard__go" aria-hidden="true">{ArrowIcon}</span>
      </div>
      <h3 className="gcard__name">{t.term}</h3>
      <p className="gcard__def">{t.def}</p>
      <div className="gcard__tags">
        {t.mechanics.map((m) => <span className="pillchip" key={m}>{m}</span>)}
      </div>
    </a>
  );
}

/** Glossary index: plain-language definitions, each linked to its mechanics. */
function GlossaryPage() {
  return (
    <main id="main">
      <section className="cs-head" aria-labelledby="gloss-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="index.html">Library</a>
            <span className="crumb__sep" aria-hidden="true">/</span>
            <span>Glossary</span>
          </nav>
          <div className="eyebrow cs-head__eyebrow">The library</div>
          <h1 id="gloss-h">Glossary</h1>
          <p className="cs-head__def">
            Plain-language definitions for the psychology behind the mechanics. Every term is the
            <i> why</i> under a pattern you'll meet across the library — the reason a streak holds or
            a price reads as a deal — and links straight to the mechanics that put it to work.
          </p>
        </div>
      </section>

      <div className="container cs-wrap">
        <div className="cs-bar">
          <span className="cs-bar__count"><b>{TERMS.length}</b> terms</span>
          <span className="cs-bar__hint">Updated weekly</span>
        </div>

        <div className="glossgrid">
          {TERMS.map((t) => <TermCard key={t.term} t={t} />)}
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { GlossaryPage });
})();

/* Website kit — Case study detail (Royal Match, full breakdown). A long-form,
   single-app breakdown: header, mechanics-observed chips, the core loop, a section
   per mechanic (observed / presented / worth noting / key findings / screenshots),
   how the mechanics connect, the key insight, numbered takeaways, and a sticky
   table-of-contents sidebar with scroll-spy.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { useState, useEffect } = React;
const { Tag } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const CAT_COLOR = { retention: "var(--cat-retention)", monetization: "var(--cat-monetization)", social: "var(--cat-social)" };
const CAT_LABEL = { retention: "Retention", monetization: "Monetization", social: "Social" };

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);
const LinkIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7" /><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7" />
  </svg>
);
const PairIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="13 6 19 12 13 18" /><polyline points="11 6 5 12 11 18" />
  </svg>
);

const APP = {
  name: "Royal Match",
  category: "Casual game",
  icon: "RM",
  overview:
    "Royal Match is a match-3 saga puzzle that has stayed near the top of the casual charts by being unusually disciplined about its loop. This breakdown takes the live game apart mechanic by mechanic: what each one does, how it is presented to the player, and how the four core mechanics are sequenced so the next session always has a reason to start. The throughline is restraint — nothing here is novel, but the order in which it arrives is.",
};

const MECHANICS = [
  {
    id: "lives", cat: "monetization", name: "Energy / Lives", href: "mechanics.html",
    observed:
      "The player begins with five lives and loses one each time a board is failed. When the meter empties, play stops until a life regenerates on a fixed timer, or the player refills early. The resource governs how long a single sitting can run before the game asks something of the player.",
    presented:
      "The lives meter is pinned to the top bar at all times, with a live countdown to the next refill. The out-of-lives moment is handled as a modal rather than a dead end, offering three paths in a deliberate order: wait, ask friends, or buy.",
    noting:
      "The regeneration timer is tuned to feel survivable yet long enough that a refill is tempting at the exact moment motivation peaks — immediately after a loss, when the player most wants one more try.",
    findings: [
      "Lives turn a difficulty spike into a pricing moment without touching the puzzle itself.",
      "The wait is always visible, so the cost of stopping stays concrete.",
      "Wait, ask, buy are ordered to surface the social option before the paid one.",
    ],
    shots: ["Lives meter in top bar", "Out-of-lives modal", "Early-refill offer"],
  },
  {
    id: "daily-reward", cat: "retention", name: "Daily Reward", href: "mechanics.html",
    observed:
      "Opening the app on a new day surfaces a reward before the player has done anything to earn it. The bonus escalates across consecutive days and resets to the start if a day is missed.",
    presented:
      "The reward animates onto a calendar overlay the instant the home screen loads. The days ahead are visible in the same view, showing both what an unbroken streak is worth and what a skipped day would forfeit.",
    noting:
      "The reward is given, not earned — no task gates it. The pull lives entirely in the escalation and the visible forfeit, not in the size of any single day's gift.",
    findings: [
      "The reward precedes the ask, so the session opens in credit.",
      "A visible escalating row makes skipping read as a loss, not a neutral choice.",
      "Nothing gates the bonus, which lowers the bar to re-engage after a lapse.",
    ],
    shots: ["Daily bonus calendar", "Seven-day reward", "Streak reset prompt"],
  },
  {
    id: "limited-time-events", cat: "monetization", name: "Limited-Time Events", href: "mechanics.html",
    observed:
      "Short, themed events run for a few days on top of the base game, each with its own boards, a leaderboard, and rewards that vanish when the timer ends. They appear and disappear on a cadence rather than running continuously.",
    presented:
      "A countdown frames the whole event as already expiring. A tiered reward track shows the next prize sitting just beyond the player's current progress, so there is always a near target.",
    noting:
      "Events are spaced to punctuate the steady loop rather than replace it. The scarcity reads as genuinely special precisely because the rest of the game is always available.",
    findings: [
      "A defined window concentrates attention and spend into a burst.",
      "The tiered track keeps a reward within reach at every moment.",
      "Spacing protects the events from fatiguing into background noise.",
    ],
    shots: ["Event hub", "Tiered reward track", "Final-hours banner"],
  },
  {
    id: "season-pass", cat: "monetization", name: "Season Pass", href: "mechanics.html",
    observed:
      "A multi-week pass offers two parallel reward tracks: a free track earned through ordinary play and a paid track that rewards the same play with more. Progress on both is driven by the same in-game actions.",
    presented:
      "Both tracks are shown side by side, with the paid track's richer rewards visible but locked. The player earns on the free track first, well before any prompt to upgrade appears.",
    noting:
      "The upgrade is offered only after the free track has already paid out, so the decision is framed as keeping value the player can see rather than gambling on value they cannot.",
    findings: [
      "Free-track rewards prove the system works before any spend is asked.",
      "The visible locked track frames the upgrade as keeping value, not unlocking a gate.",
      "A single purchase converts the whole loop's effort into a richer return.",
    ],
    shots: ["King's Pass tracks", "Locked paid tier", "Upgrade prompt"],
  },
];

const CONNECTIONS = [
  {
    a: "Energy / Lives", b: "Daily Reward",
    desc: "The daily reward frequently hands out lives or a refill, so the bonus that pulls the player back also tops up the very resource the session will spend. The return is rewarded with exactly the fuel the next sitting needs.",
    label: "These two mechanics share the same activation moment.",
  },
  {
    a: "Limited-Time Events", b: "Season Pass",
    desc: "Event play feeds pass progress, so the burst of a timed event also advances the slow track of the season. A short-term reason to play doubles as long-term progress without the player having to choose between them.",
    label: "The event is a fast loop nested inside the pass's slow loop.",
  },
  {
    a: "Energy / Lives", b: "Limited-Time Events",
    desc: "Events draw on the same life meter as the base game, so heightened event motivation raises the value of every refill. The scarcity of a closing window meets the scarcity of lives at the moment the player least wants to stop.",
    label: "Two kinds of scarcity stack on a single shared resource.",
  },
];

const INSIGHT = {
  observation:
    "Royal Match never asks for anything before it has given something. Every spend moment is preceded by a mechanic that has already delivered visible value, so a purchase reads as protecting what the player holds rather than acquiring what they don't.",
  works:
    "The four mechanics share one resource and one action. Lives meter the puzzle, the daily reward refills lives, events raise the value of lives, and the pass collects all of it into a single upgrade. No mechanic stands alone, and the puzzle sits at the center of every loop.",
};

const TAKEAWAYS = [
  "Meter the core experience with a single, visible resource before layering anything else on top of it.",
  "Give value before asking for it — the daily reward and the free pass track both pay out first.",
  "Use scarcity in bursts against a steady baseline, so timed events feel special instead of constant.",
  "Connect mechanics through a shared resource, so each one quietly raises the value of the others.",
];

/* Table-of-contents sections, in document order. */
const TOC = [
  { id: "overview", label: "Overview" },
  { id: "mechanics-observed", label: "Mechanics observed" },
  { id: "how-it-works", label: "How it works" },
  ...MECHANICS.map((m) => ({ id: `m-${m.id}`, label: m.name, sub: true })),
  { id: "how-they-connect", label: "How they connect" },
  { id: "key-insight", label: "Key insight" },
  { id: "key-takeaways", label: "Key takeaways" },
];

function Shot({ label }) {
  return (
    <figure className="shot">
      <div className="shot__frame"><span className="shot__ph">screenshot</span></div>
      <figcaption className="shot__cap">{label}</figcaption>
    </figure>
  );
}

function Toc({ active }) {
  return (
    <aside className="cs-toc" aria-label="On this page">
      <a className="cs-toc__back" href="case-studies.html">{"\u2190"} All case studies</a>
      <div className="cs-toc__label">On this page</div>
      <nav className="cs-toc__nav">
        {TOC.map((t) => (
          <a
            key={t.id}
            href={`#${t.id}`}
            className={"cs-toc__link" + (t.sub ? " cs-toc__link--sub" : "") + (active === t.id ? " is-active" : "")}
          >
            {t.label}
          </a>
        ))}
      </nav>
    </aside>
  );
}

function MechanicSection({ m }) {
  return (
    <section className="cs-msec" id={`m-${m.id}`} aria-labelledby={`m-${m.id}-h`}>
      <div className="cs-msec__head">
        <div className="cs-msec__meta">
          <Tag category={m.cat} dot>{CAT_LABEL[m.cat]}</Tag>
          <h2 className="cs-msec__name" id={`m-${m.id}-h`}>{m.name}</h2>
        </div>
        <a className="cs-msec__link" href={m.href}>Full mechanic page {ArrowIcon}</a>
      </div>

      <div className="cs-msec__body">
        <div className="cs-sub">
          <h3 className="cs-sub__h">What was observed</h3>
          <p>{m.observed}</p>
        </div>
        <div className="cs-sub">
          <h3 className="cs-sub__h">How it is presented</h3>
          <p>{m.presented}</p>
        </div>
        <div className="cs-sub">
          <h3 className="cs-sub__h">What is worth noting</h3>
          <p>{m.noting}</p>
        </div>
        <div className="cs-sub">
          <h3 className="cs-sub__h">Key findings</h3>
          <ul className="cs-findings">
            {m.findings.map((f, i) => <li key={i}>{f}</li>)}
          </ul>
        </div>
      </div>

      <div className="shotgallery">
        {m.shots.map((s) => <Shot key={s} label={s} />)}
      </div>
    </section>
  );
}

/** Case study full-breakdown page body. */
function CaseStudyDetailPage() {
  const [active, setActive] = useState("overview");

  useEffect(() => {
    const ids = TOC.map((t) => t.id);
    const onScroll = () => {
      const line = window.innerHeight * 0.3;
      let current = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top - line <= 0) current = id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <main id="main">
      <div className="container">
        <div className="cs-layout">
          <Toc active={active} />

          <div className="cs-main">
            {/* Header */}
            <header className="cs-hd" id="overview">
              <nav className="crumb" aria-label="Breadcrumb">
                <a href="case-studies.html">Case studies</a>
                <span className="crumb__sep" aria-hidden="true">/</span>
                <span>{APP.name}</span>
                <span className="crumb__sep" aria-hidden="true">/</span>
                <span>Full breakdown</span>
              </nav>
              <div className="cs-hd__row">
                <div className="cs-hd__icon" aria-hidden="true">{APP.icon}</div>
                <div className="cs-hd__heads">
                  <Tag category="neutral" variant="outline">{APP.category}</Tag>
                  <h1 className="cs-hd__title">{APP.name} {"\u2014"} Full Breakdown</h1>
                </div>
              </div>
              <p className="cs-hd__overview">{APP.overview}</p>
            </header>

            {/* Mechanics observed */}
            <section className="cs-sec" id="mechanics-observed" aria-labelledby="mo-h">
              <div className="mech-section__kicker">Mechanics observed</div>
              <h2 className="mech-section__title" id="mo-h">Four mechanics carry the loop</h2>
              <div className="cs-chips">
                {MECHANICS.map((m) => (
                  <a className="cs-chip" href={`#m-${m.id}`} key={m.id}>
                    <span className="cs-chip__dot" style={{ background: CAT_COLOR[m.cat] }} />
                    <span className="cs-chip__name">{m.name}</span>
                    <span className="cs-chip__cat">{CAT_LABEL[m.cat]}</span>
                  </a>
                ))}
              </div>
            </section>

            {/* How it works */}
            <section className="cs-sec" id="how-it-works" aria-labelledby="hiw-h">
              <div className="mech-section__kicker">How it works</div>
              <h2 className="mech-section__title" id="hiw-h">The core loop</h2>
              <div className="mech-prose cs-prose">
                <p>
                  The loop starts and ends with the puzzle. A board costs a life to attempt; clearing it
                  advances the map and pays out small rewards, while failing it spends the life and nudges
                  the player toward a refill. The daily reward tops the meter back up on the next open,
                  events raise the stakes of every board for a few days at a time, and the season pass
                  quietly banks all of that play toward a larger reward.
                </p>
                <p>
                  Every mechanic routes back to the same action: open the game and play a board. Lives
                  decide the pace, the daily reward supplies the reason to return, events supply intensity,
                  and the pass supplies a destination. None of them changes the puzzle — they change what
                  the puzzle is worth, and when.
                </p>
              </div>
            </section>

            {/* Mechanic sections */}
            {MECHANICS.map((m) => <MechanicSection key={m.id} m={m} />)}

            {/* How they connect */}
            <section className="cs-sec" id="how-they-connect" aria-labelledby="htc-h">
              <div className="mech-section__kicker">How they connect</div>
              <h2 className="mech-section__title" id="htc-h">Where the mechanics meet</h2>
              <div className="cs-conns">
                {CONNECTIONS.map((c, i) => (
                  <div className="cs-conn" key={i}>
                    <h3 className="cs-conn__h">{c.a} <span className="cs-conn__x" aria-hidden="true">{"\u00d7"}</span> {c.b}</h3>
                    <p className="cs-conn__d">{c.desc}</p>
                    <div className="cs-conn__label"><span className="cs-conn__icon" aria-hidden="true">{PairIcon}</span>{c.label}</div>
                  </div>
                ))}
              </div>
            </section>

            {/* Key insight */}
            <section className="cs-sec" id="key-insight" aria-labelledby="ki-h">
              <div className="mech-section__kicker">Key insight</div>
              <h2 className="mech-section__title" id="ki-h">What the system teaches</h2>
              <div className="cs-insight">
                <div className="cs-insight__part">
                  <h3 className="cs-insight__h">The single most instructive observation</h3>
                  <p>{INSIGHT.observation}</p>
                </div>
                <div className="cs-insight__part">
                  <h3 className="cs-insight__h">What makes the system work</h3>
                  <p>{INSIGHT.works}</p>
                </div>
              </div>
            </section>

            {/* Key takeaways */}
            <section className="cs-sec" id="key-takeaways" aria-labelledby="kt-h">
              <div className="mech-section__kicker">For your product</div>
              <h2 className="mech-section__title" id="kt-h">Key takeaways</h2>
              <ol className="cs-takelist">
                {TAKEAWAYS.map((t, i) => (
                  <li className="cs-take" key={i}>
                    <span className="cs-take__n">{String(i + 1).padStart(2, "0")}</span>
                    <p>{t}</p>
                  </li>
                ))}
              </ol>
            </section>
          </div>
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { CaseStudyDetailPage });
})();

/* Website kit — Industry report intro chapter (Finance Apps). The opening chapter
   of a multi-part report: a floating chapter nav, the header and overview, the ten
   apps analyzed, the headline findings, per-mechanic observations, two short
   narrative sections, the five goal chapters as cards, and next-chapter nav.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const GBSite = (window.GBSite = window.GBSite || {});

const CAT_COLOR = { retention: "var(--cat-retention)", monetization: "var(--cat-monetization)", social: "var(--cat-social)" };

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);
const RightIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
);

const APPS = [
  { ab: "Rv", name: "Revolut", cat: "Neobank" },
  { ab: "Mo", name: "Monzo", cat: "Neobank" },
  { ab: "Ch", name: "Chime", cat: "Neobank" },
  { ab: "Nu", name: "Nubank", cat: "Neobank" },
  { ab: "Ac", name: "Acorns", cat: "Micro-investing" },
  { ab: "Rb", name: "Robinhood", cat: "Investing" },
  { ab: "Cl", name: "Cleo", cat: "Budgeting assistant" },
  { ab: "Pl", name: "Plum", cat: "Savings" },
  { ab: "YN", name: "YNAB", cat: "Expense tracker" },
  { ab: "Sp", name: "Step", cat: "Teen banking" },
];

const STATS = [
  { value: "10", label: "Apps analyzed" },
  { value: "14", label: "Mechanics observed" },
  { value: "6", label: "Used by the majority" },
  { value: "3", label: "Barely touched" },
];

const OBSERVATIONS = [
  { name: "Progress Bar", cat: "retention", prevalence: "9 of 10 apps",
    desc: "Almost every app visualizes a savings goal or a budget as a bar. It is the category's default way to make an abstract balance feel close enough to act on." },
  { name: "Milestone Rewards", cat: "retention", prevalence: "7 of 10 apps",
    desc: "Goal thresholds, round-number balances, and the first thousand saved are marked with a small celebration that gives the number meaning beyond the figure itself." },
  { name: "Streak / Streak Bonus", cat: "retention", prevalence: "5 of 10 apps",
    desc: "Half the set rewards consecutive days of saving or logging a transaction, borrowing the daily-habit loop almost directly from consumer apps outside finance." },
  { name: "Loss Aversion", cat: "retention", prevalence: "4 of 10 apps",
    desc: "A few apps frame a broken streak or a missed round-up as something already earned and given up, rather than a neutral action simply skipped." },
  { name: "Variable Rewards", cat: "monetization", prevalence: "3 of 10 apps",
    desc: "Surprise cashback and randomized boosts appear in a handful of apps, concentrated around deposits and referrals where the uncertainty does the most work." },
  { name: "Leaderboards", cat: "social", prevalence: "2 of 10 apps",
    desc: "Rare, and used cautiously. Ranking money behaviour against peers sits uneasily in a category built on privacy, so where it appears it is opt-in and anonymized." },
];

const GOALS = [
  { n: 1, title: "Activation", desc: "Get a nervous first-time user to their first meaningful action.", href: "report-finance-goal-1.html" },
  { n: 2, title: "Habit", desc: "Turn an occasional check-in into a daily or weekly routine.", href: "report-finance-goal-2.html" },
  { n: 3, title: "Saving", desc: "Make putting money aside feel rewarding rather than restrictive.", href: "report-finance-goal-3.html" },
  { n: 4, title: "Engagement", desc: "Keep users exploring features beyond the balance screen.", href: "report-finance-goal-4.html" },
  { n: 5, title: "Advocacy", desc: "Turn satisfied users into referrers and reviewers.", href: "report-finance-goal-5.html" },
];

/* Floating chapter nav: intro (current), the five goal chapters, takeaways. */
const NAV = [
  { label: "Introduction", href: "#intro", current: true },
  ...GOALS.map((g) => ({ n: String(g.n).padStart(2, "0"), label: g.title, href: g.href, sub: true })),
  { label: "Takeaways", href: "report-finance-takeaways.html" },
];

function ChapterNav() {
  return (
    <aside className="cs-toc" aria-label="Report chapters">
      <a className="cs-toc__back" href="index.html#reports">{"\u2190"} All reports</a>
      <div className="cs-toc__label">Finance Apps {"\u00b7"} 2026</div>
      <nav className="cs-toc__nav">
        {NAV.map((t) => (
          <a key={t.label} href={t.href} className={"cs-toc__link" + (t.sub ? " cs-toc__link--sub" : "") + (t.current ? " is-active" : "")}>
            {t.n ? <span className="cs-toc__n">{t.n}</span> : null}{t.label}
          </a>
        ))}
      </nav>
    </aside>
  );
}

/** Industry report intro chapter body. */
function IndustryReportPage() {
  return (
    <main id="main">
      <div className="container">
        <div className="cs-layout">
          <ChapterNav />

          <div className="cs-main">
            {/* Header */}
            <header className="ir-hd" id="intro">
              <nav className="crumb" aria-label="Breadcrumb">
                <a href="index.html#reports">Reports</a>
                <span className="crumb__sep" aria-hidden="true">/</span>
                <span>Finance Apps</span>
              </nav>
              <div className="rpt-label">Industry Report {"\u00b7"} 2026</div>
              <h1 className="ir-hd__title">Gamification across finance apps</h1>
              <div className="ir-overview">
                <p>
                  We pulled apart ten of the finance apps people open most and read each one against the
                  twenty-two-mechanic framework. This opening chapter sets out what the category looks like
                  as a whole: which mechanics have become table stakes, which remain rare, and where the
                  honest openings are for a product willing to move first.
                </p>
                <p>
                  The rest of the report is organized by goal rather than by app. Each chapter takes one
                  thing a finance product is usually trying to do, from activating a nervous newcomer to
                  earning a referral, and shows the mechanics that serve it best, with examples drawn from
                  the apps below.
                </p>
              </div>
            </header>

            {/* App grid */}
            <section className="ir-sec" aria-labelledby="apps-h">
              <div className="mech-section__kicker">The 10 apps we analyzed</div>
              <h2 className="mech-section__title" id="apps-h">A cross-section of the category</h2>
              <div className="ir-apps">
                {APPS.map((a) => (
                  <div className="ir-appcard" key={a.name}>
                    <span className="ir-appcard__icon" aria-hidden="true">{a.ab}</span>
                    <span className="ir-appcard__name">{a.name}</span>
                    <span className="ir-appcard__cat">{a.cat}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* What we found: stats + mechanic observations */}
            <section className="ir-sec" aria-labelledby="found-h">
              <div className="mech-section__kicker">What we found</div>
              <h2 className="mech-section__title" id="found-h">The shape of the category</h2>
              <div className="ir-stats">
                {STATS.map((s) => (
                  <div className="rpt-stat" key={s.label}>
                    <span className="rpt-stat__num">{s.value}</span>
                    <span className="rpt-stat__label">{s.label}</span>
                  </div>
                ))}
              </div>

              <div className="ir-obs">
                {OBSERVATIONS.map((o) => (
                  <div className="ir-ob" key={o.name}>
                    <div className="ir-ob__head">
                      <span className="ir-ob__dot" style={{ background: CAT_COLOR[o.cat] }} />
                      <span className="ir-ob__name">{o.name}</span>
                      <span className="ir-ob__prev">{o.prevalence}</span>
                    </div>
                    <p className="ir-ob__desc">{o.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* What this means */}
            <section className="ir-sec" aria-labelledby="mean-h">
              <div className="mech-section__kicker">What this means</div>
              <h2 className="mech-section__title" id="mean-h">A category that gamifies progress, not competition</h2>
              <div className="mech-prose ir-prose">
                <p>
                  Finance apps have settled on a narrow, comfortable slice of the framework. The mechanics
                  that show progress — bars, milestones, the occasional streak — are everywhere, because
                  they map cleanly onto money goals and carry no real risk to trust. The mechanics that
                  involve other people, or chance, are treated with caution.
                </p>
                <p>
                  That caution is mostly warranted, but it has left real ground unused. Social and
                  variable-reward mechanics are rare precisely because they are hard to do tastefully in
                  finance, which is exactly why an app that gets them right has so little company.
                </p>
              </div>
            </section>

            {/* How to read this report */}
            <section className="ir-sec" aria-labelledby="how-h">
              <div className="mech-section__kicker">How to read this report</div>
              <h2 className="mech-section__title" id="how-h">Start with your goal, not your roadmap</h2>
              <div className="mech-prose ir-prose">
                <p>
                  Each of the five chapters ahead is built around a single goal. Find the one closest to
                  what your product is trying to do right now, and read that chapter first. Every mechanic
                  in it is rated for how well it fits the goal and how novel it would feel in finance, with
                  a real example from one of the ten apps.
                </p>
              </div>
            </section>

            {/* Goal chapter cards */}
            <section className="ir-sec" aria-labelledby="chapters-h">
              <div className="mech-section__kicker">The chapters</div>
              <h2 className="mech-section__title" id="chapters-h">Five goals</h2>
              <div className="ir-goals">
                {GOALS.map((g) => (
                  <a className="ir-goalcard" href={g.href} key={g.n}>
                    <span className="ir-goalcard__k">Goal {g.n}</span>
                    <span className="ir-goalcard__t">{g.title}</span>
                    <span className="ir-goalcard__d">{g.desc}</span>
                    <span className="ir-goalcard__go" aria-hidden="true">{ArrowIcon}</span>
                  </a>
                ))}
              </div>
            </section>

            {/* Next chapter */}
            <a className="ir-next" href={GOALS[0].href}>
              <span className="ir-next__k">Next chapter</span>
              <span className="ir-next__t">Goal 1: {GOALS[0].title} {RightIcon}</span>
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { IndustryReportPage });
})();

/* Website kit — Systems index. A grid of the apps whose mechanic loops we have
   mapped, with the app name, a one-line description of what the system achieves,
   and the mechanics the loop runs.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Tag, Badge } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const LockIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);
const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);

/* Each system: its nodes ({ label }) are the mechanics the loop runs. */
const SYSTEMS = [
  {
    name: "Royal Match", type: "Game", locked: false, active: 1,
    desc: "Turns daily play into spend without ever feeling like a punishment.",
    nodes: { A: { label: "Lives", cat: "monetization" }, B: { label: "Daily reward", cat: "retention" }, C: { label: "Events", cat: "monetization" }, D: { label: "Season pass", cat: "monetization" } },
    href: "#royal-match",
  },
  {
    name: "Duolingo", type: "App", locked: true, active: 0,
    desc: "A streak and loss aversion make a daily lesson feel unmissable.",
    nodes: { A: { label: "Streak", cat: "retention" }, B: { label: "Loss aversion", cat: "retention" }, C: { label: "Leaderboard", cat: "social" }, D: { label: "Quests", cat: "retention" } },
  },
  {
    name: "Monopoly Go", type: "Game", locked: true, active: 0,
    desc: "Dice as a resource keep players cycling back between refills.",
    nodes: { A: { label: "Dice", cat: "monetization" }, B: { label: "Collections", cat: "retention" }, C: { label: "Events", cat: "monetization" }, D: { label: "Teams", cat: "social" } },
  },
  {
    name: "Strava", type: "App", locked: true, active: 0,
    desc: "Segments and social ties turn solo workouts into standing.",
    nodes: { A: { label: "Segments", cat: "social" }, B: { label: "Milestones", cat: "retention" }, C: { label: "Challenges", cat: "social" }, D: { label: "Badges", cat: "retention" } },
  },
  {
    name: "Candy Crush Saga", type: "Game", locked: true, active: 0,
    desc: "Lives and a long map keep the next level one session away.",
    nodes: { A: { label: "Lives", cat: "monetization" }, B: { label: "Progress", cat: "retention" }, C: { label: "Events", cat: "monetization" }, D: { label: "Daily reward", cat: "retention" } },
  },
  {
    name: "Headspace", type: "App", locked: true, active: 0,
    desc: "A run streak makes a meditation habit visible and worth protecting.",
    nodes: { A: { label: "Streak", cat: "retention" }, B: { label: "Milestones", cat: "retention" }, C: { label: "Progress", cat: "retention" }, D: { label: "Onboarding", cat: "retention" } },
  },
  {
    name: "Clash of Clans", type: "Game", locked: true, active: 2,
    desc: "Clans turn a player's return into an obligation to teammates.",
    nodes: { A: { label: "Clans", cat: "social" }, B: { label: "Tiers", cat: "retention" }, C: { label: "Season pass", cat: "monetization" }, D: { label: "Challenges", cat: "social" } },
  },
  {
    name: "Starbucks", type: "App", locked: true, active: 0,
    desc: "Tiers and limited offers make the next order worth tracking.",
    nodes: { A: { label: "Tiers", cat: "retention" }, B: { label: "Milestones", cat: "retention" }, C: { label: "Offers", cat: "monetization" }, D: { label: "Referral", cat: "social" } },
  },
  {
    name: "Coin Master", type: "Game", locked: true, active: 0,
    desc: "A spin's variable reward feeds collections and a social loop.",
    nodes: { A: { label: "Spin", cat: "monetization" }, B: { label: "Variable reward", cat: "retention" }, C: { label: "Collections", cat: "retention" }, D: { label: "Gifting", cat: "social" } },
  },
];

function SystemCard({ sys }) {
  const mechanics = Object.values(sys.nodes).map((n) => n.label);
  return (
    <a className={"csc" + (sys.locked ? " csc--locked" : "")} href={sys.href || "#subscribe"}>
      <div className="csc__top">
        <Tag category="neutral" variant="outline">{sys.type}</Tag>
        <span className="csc__badge">
          {sys.locked
            ? <Badge tone="neutral" variant="outline" icon={LockIcon}>For subscribers</Badge>
            : <Badge tone="ok" variant="soft">Free</Badge>}
        </span>
      </div>

      <h3 className="csc__name">{sys.name}</h3>
      <p className="csc__desc">{sys.desc}</p>

      <div className="csc__tags">
        {mechanics.map((m) => <span className="pillchip" key={m}>{m}</span>)}
      </div>

      <div className="csc__foot">
        <span className="csc__count"><b>{mechanics.length}</b> mechanics linked</span>
        <span className="csc__go">{sys.locked ? "Subscribe to read" : "Explore the map"} {ArrowIcon}</span>
      </div>
    </a>
  );
}

/** Systems index: the signature asset, every app's loop drawn in the house language. */
function SystemsPage() {
  return (
    <main id="main">
      <section className="cs-head" aria-labelledby="sys-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="#library">Library</a>
            <span className="crumb__sep" aria-hidden="true">/</span>
            <span>Systems</span>
          </nav>
          <div className="eyebrow cs-head__eyebrow">The library</div>
          <h1 id="sys-h">Systems</h1>
          <p className="cs-head__def">
            A system is the <b>loop</b>, not the parts. A system map shows how one app's mechanics
            connect and feed each other: the streak that protects a reward, the reward that pulls the
            next session. Each map is drawn in our house language, nodes for mechanics and red lines
            for the connections that carry the most weight.
          </p>
        </div>
      </section>

      <div className="container cs-wrap">
        <div className="cs-bar">
          <span className="cs-bar__count"><b>{SYSTEMS.length}</b> system maps</span>
          <span className="cs-bar__hint">Updated weekly</span>
        </div>

        <div className="csgrid">
          {SYSTEMS.map((s) => <SystemCard key={s.name} sys={s} />)}
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { SystemsPage });
})();

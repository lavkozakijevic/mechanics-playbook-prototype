/* Website kit — Mechanic detail page (Streak / Streak Bonus).
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Tag } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

/* ---- inline icons (static page, but inline SVG is re-render safe) ---- */
const IconKey = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="7.5" cy="15.5" r="4.5" /><path d="M10.7 12.3 21 2" /><path d="m16 7 3 3" /><path d="m18 5 3 3" />
  </svg>
);
const IconAlert = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);
const IconArrow = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
);

/* ---- mechanic content ---- */
const MECH = {
  n: 1,
  name: "Streak / Streak Bonus",
  category: "retention",
  categoryLabel: "Retention",
  definition: "A counter that increments each time a user completes a defined action within a set time window, typically once per day. Miss the window and the count resets.",
  bestFor: [{ label: "Achiever", color: "var(--cat-social)" }, { label: "Competitor", color: "var(--red-600)" }],
  context: ["Activation", "Retention", "Habit"],
  drivers: ["Consistency", "Loss aversion", "Progress"],
  how: "A streak turns a string of repeated actions into a single number worth protecting. Each day a user completes the target action, the count climbs; miss the window and it resets to zero. The mechanic works because the growing number reframes a daily choice as something the user has already invested in — the longer the streak, the more there is to keep by continuing, and the easier it is to justify one more day.",
  principle: "The value isn't a reward at the end — it's the count itself. Once a streak is long enough to feel earned, protecting it becomes its own motivation.",
  watch: "A reset that feels unfair can end the habit for good. Without a freeze or repair option, one missed day can turn a committed user into a churned one.",
  variants: [
    { name: "Simple streak", desc: "A single consecutive-day counter tied to one core action. The clearest version, and the easiest to grasp at a glance." },
    { name: "Streak freeze / repair", desc: "A safety net that pauses or restores a streak after a miss, protecting the user's investment when life gets in the way." },
    { name: "Streak milestones", desc: "Rewards or new visuals unlocked at thresholds like 7, 30, and 100 days, giving the count fresh meaning as it grows." },
    { name: "Per-habit streaks", desc: "Separate streaks for each tracked activity, so progress in one area never depends on another." },
  ],
  lifecycle: "Streaks earn their keep just after activation — once a user has felt the core value, but before the habit is set. Introduce one too early and there's nothing to protect; too late and the routine is already formed.",
  pairedWith: [
    { name: "Daily Reward", cat: "retention" },
    { name: "Loss Aversion", cat: "retention" },
    { name: "Milestone Rewards", cat: "retention" },
    { name: "Login Calendar", cat: "retention" },
  ],
  playerTypes: [
    { label: "Achiever", color: "var(--cat-social)", note: "primary fit" },
    { label: "Competitor", color: "var(--red-600)", note: "with leaderboards" },
  ],
};

const NARR = ["How they use it", "Why it works", "The detail", "Takeaway"];

const STUDIES = [
  { app: "Duolingo", cat: "Education", screens: ["Streak counter", "Streak freeze", "Day 365"],
    body: [
      "The streak counter sits in the corner of every screen and fires a celebration the moment a lesson is finished.",
      "Lessons are short, so the bar to keep a streak alive is low — which makes the growing count feel almost free to protect.",
      "Streak Freeze and a weekend amnesty quietly forgive the occasional miss, keeping long streaks from collapsing on one bad day.",
      "Pair an easy daily target with a forgiving safety net, and a streak can run for years." ] },
  { app: "Snapchat", cat: "Social", screens: ["Friend flames", "Streak count", "Expiry timer"],
    body: [
      "Snapstreaks count the consecutive days two friends exchange snaps, shown as a flame and a number beside a name.",
      "The streak belongs to a relationship, not one person — so social obligation, not just habit, keeps it alive.",
      "An hourglass warns when a streak is about to expire, prompting a last-minute snap to save it.",
      "Tie a streak to another person and you add accountability the app never has to enforce itself." ] },
  { app: "Headspace", cat: "Health", screens: ["Home streak", "Milestone", "Run streak"],
    body: [
      "A run streak counts consecutive days a user completes any meditation, surfaced on the home tab.",
      "It reframes a calm, optional practice as a commitment worth keeping, nudging the next session.",
      "Milestones at 10, 30 and 100 days mark the journey without punishing a missed day too harshly.",
      "Even gentle, wellbeing-first products can use streaks — as long as the tone stays encouraging." ] },
  { app: "Finch", cat: "Health", screens: ["Pet home", "Daily goals", "Streak summary"],
    body: [
      "Daily self-care goals build a streak that helps a virtual pet grow, tying the count to a character.",
      "Caring for the pet, not raw discipline, carries the habit — the streak feels like nurture, not pressure.",
      "Missed days are framed kindly, with no harsh reset language, protecting users having a hard week.",
      "A streak wrapped in care can motivate the exact users a competitive streak would scare off." ] },
  { app: "Strava", cat: "Fitness", screens: ["Weekly streak", "Activity log", "Challenge"],
    body: [
      "Weekly and monthly activity streaks reward athletes for logging a minimum amount of training.",
      "For committed athletes the streak aligns with goals they already hold — it amplifies intent rather than inventing it.",
      "Streaks live alongside challenges and kudos, so social proof reinforces the personal count.",
      "When users already want the behavior, a streak turns motivation into measurable momentum." ] },
  { app: "Apple Fitness", cat: "Health", screens: ["Activity rings", "Awards", "Perfect month"],
    body: [
      "Closing all three activity rings every day builds a streak, with awards for perfect weeks and months.",
      "The rings make the daily goal visual and unambiguous — you can see at a glance whether today counts.",
      "Monthly and special-event awards give the streak fresh targets beyond the daily close.",
      "A clear, visual daily goal makes the streak self-explanatory and hard to ignore." ] },
  { app: "Habitica", cat: "Productivity", screens: ["Dailies", "Character", "Streak count"],
    body: [
      "Habits and dailies build streaks that feed an RPG character's stats, health and gold.",
      "Breaking a streak costs the character real in-game health, making the stakes feel tangible.",
      "Players can buy back missed days or schedule rest, softening the penalty for planned breaks.",
      "Attach a streak to something the user has invested in, and a miss carries genuine weight." ] },
  { app: "BeReal", cat: "Social", screens: ["Daily prompt", "Profile streak", "Calendar"],
    body: [
      "Posting every day when the notification fires builds a streak shown on the profile.",
      "The single daily window makes the action specific and shared — everyone's streak ticks at once.",
      "Miss the window and the streak ends, keeping the once-a-day promise honest.",
      "A fixed daily moment turns a streak into a shared ritual rather than a private grind." ] },
  { app: "Calm", cat: "Health", screens: ["Daily streak", "Session list", "Reminder"],
    body: [
      "A daily streak tracks consecutive days with any session — a meditation, a Sleep Story, or a breathe exercise.",
      "Counting any session, not one specific act, keeps the streak easy to maintain and low-pressure.",
      "Gentle reminders and a visible count nudge the next session without nagging.",
      "Broaden what counts toward a streak and more users keep it alive." ] },
  { app: "Forest", cat: "Productivity", screens: ["Focus timer", "Forest view", "Streak stats"],
    body: [
      "Consecutive days of focused sessions grow a streak alongside a forest of planted trees.",
      "The streak and the growing forest are two views of the same effort, doubling the sense of progress.",
      "Leaving a focus session early withers a tree, making the cost of breaking concentration visible.",
      "Visualize the streak as something that accumulates, and the progress becomes its own reward." ] },
  { app: "WaterMinder", cat: "Health", screens: ["Daily goal", "Hydration log", "Streak ring"],
    body: [
      "Meeting a daily hydration goal builds a streak shown beside the day's water total.",
      "A concrete, measurable goal makes 'did today count?' a simple yes or no.",
      "Reminders through the day keep the goal — and the streak — top of mind.",
      "Clear, quantifiable daily goals make even the simplest streak effective." ] },
];

function Overview() {
  return (
    <section className="band--tight mech-head">
      <div className="container">
        <nav className="crumb" aria-label="Breadcrumb">
          <a href="index.html">Home</a><span className="crumb__sep">/</span>
          <a href="mechanics.html">Mechanics</a><span className="crumb__sep">/</span>
          <span>{MECH.name}</span>
        </nav>
        <div className="mech-head__tagrow">
          <span className="mech-head__num">{String(MECH.n).padStart(2, "0")}</span>
          <Tag category={MECH.category}>{MECH.categoryLabel}</Tag>
        </div>
        <h1>{MECH.name}</h1>
        <p className="mech-head__def">{MECH.definition}</p>
        <div className="metarow">
          <div className="metacol">
            <span className="metacol__label">Best for</span>
            <div className="metachips">
              {MECH.bestFor.map((p) => (
                <span className="metachip" key={p.label}><span className="metachip__dot" style={{ background: p.color }} />{p.label}</span>
              ))}
            </div>
          </div>
          <div className="metacol">
            <span className="metacol__label">Context</span>
            <div className="metachips">{MECH.context.map((c) => <span className="metachip" key={c}>{c}</span>)}</div>
          </div>
          <div className="metacol">
            <span className="metacol__label">Motivation drivers</span>
            <div className="metachips">{MECH.drivers.map((d) => <span className="metachip" key={d}>{d}</span>)}</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  return (
    <section aria-labelledby="how-h">
      <div className="mech-section__kicker">How it works</div>
      <h2 className="mech-section__title" id="how-h">One number, worth protecting</h2>
      <div className="mech-prose"><p>{MECH.how}</p></div>
      <div className="callouts">
        <div className="callout callout--principle">
          <span className="callout__label">{IconKey} Core principle</span>
          <p>{MECH.principle}</p>
        </div>
        <div className="callout callout--watch">
          <span className="callout__label">{IconAlert} Watch out for</span>
          <p>{MECH.watch}</p>
        </div>
      </div>
    </section>
  );
}

function Variants() {
  return (
    <section aria-labelledby="var-h">
      <div className="mech-section__kicker">Structural variants</div>
      <h2 className="mech-section__title" id="var-h">Four ways to build it</h2>
      <div className="variants">
        {MECH.variants.map((v, i) => (
          <div className="variant" key={v.name}>
            <span className="variant__n">{String(i + 1).padStart(2, "0")}</span>
            <div><h4>{v.name}</h4><p>{v.desc}</p></div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Lifecycle() {
  return (
    <section className="lifecycle" aria-label="Lifecycle placement">
      <div className="lifecycle__label">Lifecycle placement</div>
      <p>{MECH.lifecycle}</p>
    </section>
  );
}

function CaseStudies() {
  return (
    <section aria-labelledby="cs-h">
      <div className="mech-section__kicker">Case studies · {STUDIES.length}</div>
      <h2 className="mech-section__title" id="cs-h">Seen in the wild</h2>
      <div className="cstudies">
        {STUDIES.map((s) => (
          <article className="cstudy" id={`cstudy-${slug(s.app)}`} key={s.app}>
            <div className="cstudy__head">
              <span className="cstudy__app">{s.app}</span>
              <Tag category="neutral">{s.cat}</Tag>
            </div>
            <div className="cstudy__thumbs">
              {s.screens.map((sc) => (
                <div className="cthumb" key={sc}>{sc}</div>
              ))}
            </div>
            <div className="cstudy__narr">
              {s.body.map((b, i) => (
                <div key={i}><div className="narr__label">{NARR[i]}</div><p>{b}</p></div>
              ))}
            </div>
            <div className="cstudy__foot">
              <a className="cstudy__link" href={`#cstudy-${slug(s.app)}`}>View full case study {IconArrow}</a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Sidebar() {
  return (
    <aside className="mech-aside" aria-label="Related">
      <div className="amod">
        <h3>Often paired with</h3>
        <div className="amod__list">
          {MECH.pairedWith.map((m) => (
            <a className="amod__item" href="mechanics.html" key={m.name}>
              <span className="amod__dot" style={{ background: `var(--cat-${m.cat})` }} />
              <span className="amod__name">{m.name}</span>
            </a>
          ))}
        </div>
      </div>
      <div className="amod">
        <h3>Player types</h3>
        <div className="amod__list">
          {MECH.playerTypes.map((p) => (
            <div className="amod__item" key={p.label}>
              <span className="amod__dot" style={{ background: p.color }} />
              <span className="amod__name">{p.label}</span>
              <span className="amod__meta">{p.note}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="amod">
        <h3>Seen in</h3>
        <div className="amod__list">
          {STUDIES.map((s) => (
            <a className="amod__item" href={`#cstudy-${slug(s.app)}`} key={s.app}>
              <span className="amod__name">{s.app}</span>
              <span className="amod__meta">{s.cat}</span>
            </a>
          ))}
        </div>
      </div>
    </aside>
  );
}

/** Mechanic detail page body. */
function MechanicDetailPage() {
  return (
    <main id="main">
      <Overview />
      <div className="container">
        <div className="mech-body">
          <div className="mech-main">
            <HowItWorks />
            <Variants />
            <Lifecycle />
            <CaseStudies />
          </div>
          <Sidebar />
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { MechanicDetailPage });
})();

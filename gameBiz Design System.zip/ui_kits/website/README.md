# Website UI kit

A high-fidelity recreation of the GameBiz marketing site, built from the design-system primitives. This is the brand's public surface: the place a cold CMO, PM, or founder lands and, within five seconds, understands what we offer, how it helps them, and what to do next.

The kit follows the page-requirements guide (`uploads/page-requirements-guide.md`) and the BrandScript order: the visitor's problem, then us as the guide, then the plan, then the proof.

## Screens

| File | Surface | Status |
|---|---|---|
| `index.html` | **Homepage** — the full marketing page | Built |
| _Mechanic detail, App case study, Reports, Work With Us…_ | Other surfaces from the page guide | Planned next |

The homepage composes these section components:

- **SiteChrome.jsx** — `SiteNav` (sticky, collapses to a drawer below 900px), `NewsletterBlock`, `SiteFooter`.
- **HomeTop.jsx** — `Hero` (problem + promise, with a live system map as evidence), `ProofStrip` (library stats + freshness), `ThePlan` (the three BrandScript steps), `CaseStudySpotlight` (Royal Match, free, the transitional CTA).
- **HomeBottom.jsx** — `LibraryPreview` (featured mechanics), `SystemShowcase` (one large signature map), `NewThisWeek` (dated additions, proving cadence), `WorkWithUsBridge` (the hire-us bridge).

Every section reuses design-system components (`Button`, `Tag`, `Badge`, `Input`, `StatBlock`, `MechanicCard`, `SystemMap`, `AnnotatedScreenshot`) rather than re-implementing them. Each kit file is an IIFE-wrapped Babel script that reads the DS primitives from `window.GameBizDesignSystem_1aad9e` and attaches its own sections to `window.GBSite`. Other screens in this kit load the same files and read from the same global.

## How it renders

`index.html` loads React, Babel, and `../../_ds_bundle.js` (the DS primitives), then loads `SiteChrome.jsx`, `HomeTop.jsx`, and `HomeBottom.jsx` as `<script type="text/babel">` tags. Those attach the sections to `window.GBSite`; the final inline script mounts the homepage into `#root`. Lucide icons are created after mount. The DS section components are intentionally NOT in the compiled bundle (the compiler only bundles `Name.jsx` files whose export matches the filename), so the kit ships its own sections as Babel scripts. For production, precompile these and drop the in-browser transform.

## Responsive behavior

Mobile-first, verified with no horizontal overflow from 390px up. Breakpoints (in `site.css`):

- **< 600 (phone):** single column; nav collapses to a drawer; proof strip 2-up.
- **600–899 (large phone / portrait tablet):** proof strip 4-up; mechanic grid 2-up; footer 3 columns.
- **900–1279 (landscape tablet / laptop):** full inline nav; hero, spotlight, showcase, and work bridge go two-column; mechanic grid and plan 3-up; footer 4 columns.
- **1280+ (desktop):** wider gutters.
- **1680+ (widescreen):** content relaxes to 1180px and bands gain vertical air so the archive breathes instead of stretching.

Type scales fluidly with `clamp()`; touch targets are at least 40px; keyboard focus is visible everywhere; `prefers-reduced-motion` is respected via the design system's motion layer.

## SEO

The markup is semantic and search-ready: one `<h1>`, ordered headings, `<header>/<nav>/<main>/<section>/<footer>` landmarks, `aria-label`/`aria-labelledby` on sections, alt text on images, a meta description, canonical link, Open Graph and Twitter tags, and Organization JSON-LD in the head.

**Production caveat:** this kit renders content client-side with in-browser Babel, which is great for a design preview but not for production SEO or performance. For the real build, render these components server-side or pre-render them at build time (Next.js / Astro / similar), drop the in-browser Babel transform, and precompile the bundle. The component structure is already organized to make that move clean.

## Promoting to a starting point

`index.html` is tagged as a `@dsCard` so it previews in the Design System tab. To let consuming projects seed a new design from it, change its first-line comment to `<!-- @startingPoint section="Website" subtitle="Marketing homepage" viewport="1320x900" -->`.

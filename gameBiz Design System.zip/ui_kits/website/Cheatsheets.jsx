/* Website kit — Cheatsheets index. Title block, six cheatsheet cards (each with
   an access badge, description, related mechanic tags, and a step count), and a
   "more coming" notice listing planned topics.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Badge } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);
const LockIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);

/* The six cheatsheets. `access`: "free" is open to everyone; "full" needs the
   library subscription. `steps` is the number of steps in the guide. */
const SHEETS = [
  {
    n: 1, title: "Choosing the right mechanic for your goal", access: "full", steps: 6,
    desc: "A short decision guide that maps a goal, like activation or retention, to the mechanics worth trying first.",
    tags: ["Onboarding Goal", "Streak", "Leaderboards"],
    href: "#cheatsheet-choosing",
  },
  {
    n: 2, title: "Adding a streak without punishing lapses", access: "free", steps: 5,
    desc: "How to build a streak that earns the return without making a single missed day feel like a reason to quit.",
    tags: ["Streak", "Loss Aversion", "Login Calendar"],
    href: "cheatsheet-streak.html",
  },
  {
    n: 3, title: "Designing a season pass that converts", access: "full", steps: 9,
    desc: "The structure of a free and paid track that rewards play first and asks for the upgrade once the value is clear.",
    tags: ["Season Pass", "Milestone Rewards", "Cosmetics"],
  },
  {
    n: 4, title: "Setting up leaderboards people actually use", access: "full", steps: 7,
    desc: "How to size leagues, set the reset cadence, and tier players so competition stays motivating instead of discouraging.",
    tags: ["Leaderboards", "Tiers / Levels", "Social Challenges"],
  },
  {
    n: 5, title: "Building a daily reward loop", access: "full", steps: 6,
    desc: "An escalating reward for opening the app each day, paced so the next session always has a reason to start.",
    tags: ["Daily Reward", "Login Calendar", "Variable Rewards"],
  },
  {
    n: 6, title: "Running a limited-time event", access: "full", steps: 8,
    desc: "How to use a short, themed window to concentrate attention and spend without burning out your players.",
    tags: ["Limited-Time Events", "Quests", "Energy / Lives"],
  },
];

/* Planned cheatsheets, shown in the "more coming" notice. */
const UPCOMING = [
  "Gifting loops that grow without spam",
  "Onboarding goals that reach value fast",
  "Pricing energy and lives fairly",
  "Referral rewards that pay both sides",
  "Collections that pull players back",
  "Quests that point to the right actions",
];

function SheetCard({ s }) {
  const locked = s.access !== "free";
  return (
    <a className={"csc" + (locked ? " csc--locked" : "")} href={locked ? "#subscribe" : (s.href || "#subscribe")}>
      <div className="csc__top">
        <span className="csc__index">Cheatsheet {String(s.n).padStart(2, "0")}</span>
        <span className="csc__badge">
          {locked
            ? <Badge tone="neutral" variant="outline" icon={LockIcon}>For subscribers</Badge>
            : <Badge tone="ok" variant="soft">Free</Badge>}
        </span>
      </div>

      <h3 className="csc__name">{s.title}</h3>
      <p className="csc__desc">{s.desc}</p>

      <div className="csc__tags">
        {s.tags.map((t) => <span className="pillchip" key={t}>{t}</span>)}
      </div>

      <div className="csc__foot">
        <span className="csc__count"><b>{s.steps}</b> steps</span>
        <span className="csc__go">{s.access === "free" ? "Open the guide" : "Subscribe to read"} {ArrowIcon}</span>
      </div>
    </a>
  );
}

/** Cheatsheets index: the practitioner's quick reference, six guides plus what's next. */
function CheatsheetsPage() {
  return (
    <main id="main">
      <section className="cs-head" aria-labelledby="cheat-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="#library">Library</a>
            <span className="crumb__sep" aria-hidden="true">/</span>
            <span>Cheatsheets</span>
          </nav>
          <div className="eyebrow cs-head__eyebrow">The library</div>
          <h1 id="cheat-h">Cheatsheets</h1>
          <p className="cs-head__def">
            Quick, practical guides for putting a mechanic into your product. Each one is a short
            sequence of steps, drawn from the apps in the library, that takes you from the idea to a
            version your team can build. Start with the free guide, the rest come with the full library.
          </p>
        </div>
      </section>

      <div className="container cs-wrap">
        <div className="cs-bar">
          <span className="cs-bar__count"><b>{SHEETS.length}</b> cheatsheets</span>
          <span className="cs-bar__hint">Updated weekly</span>
        </div>

        <div className="csgrid">
          {SHEETS.map((s) => <SheetCard key={s.n} s={s} />)}
        </div>
      </div>

      <section className="band--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="comingnote">
            <div className="comingnote__head">
              <div className="comingnote__k">More coming</div>
              <h2>The next cheatsheets in the queue</h2>
              <p>We add guides as the library grows. These are the topics we are writing next, each built the same way, from real implementations.</p>
            </div>
            <ul className="comingnote__list">
              {UPCOMING.map((t) => (
                <li className="comingitem" key={t}>
                  <span className="comingitem__soon">Planned</span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}

Object.assign(GBSite, { CheatsheetsPage });
})();

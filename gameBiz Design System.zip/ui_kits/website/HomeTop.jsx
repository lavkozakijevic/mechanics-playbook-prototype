/* Website kit — top homepage sections. Loaded as a Babel script; reads DS
   primitives from the namespace, attaches sections to window.GBSite. */
(function () {
const React = window.React;
const { Button, Badge, Tag, Card, AnnotatedScreenshot } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const CAROUSEL = [
  { app: "Duolingo", mechanic: "Streaks", cat: "retention", screen: "Streak screen", title: "How Duolingo applies streaks to make returning feel worth it" },
  { app: "Royal Match", mechanic: "Daily reward", cat: "monetization", screen: "Daily reward modal", title: "How Royal Match applies daily rewards to open every session" },
  { app: "Monopoly Go", mechanic: "Event pacing", cat: "monetization", screen: "Live event board", title: "How Monopoly Go applies timed events to keep momentum up" },
  { app: "Finch", mechanic: "Gentle streaks", cat: "retention", screen: "Daily check-in", title: "How Finch applies gentle streaks to build a kind habit" },
  { app: "BeReal", mechanic: "Social window", cat: "social", screen: "Daily window prompt", title: "How BeReal applies a daily window to spark posting" },
  { app: "Strava", mechanic: "Leaderboards", cat: "social", screen: "Segment leaderboard", title: "How Strava applies leaderboards to turn routes into a friendly race" },
];

/** Hero: the promise, in the visitor's language, beside a self-sliding carousel
 *  of real mechanics drawn from the library. */
function Hero() {
  const loop = CAROUSEL.concat(CAROUSEL);
  return (
    <section className="hero" id="top" aria-labelledby="hero-h">
      <div className="container hero__grid">
        <div className="hero__body">
          <div className="eyebrow hero__eyebrow">Explore gamification options for your app</div>
          <h1 id="hero-h">Power up your app with proven game mechanics</h1>
          <p className="hero__sub">See how the best apps and games turn everyday features into habits. We break down each mechanic, map how they fit together, and help your team apply the ones that suit your product.</p>
          <div className="hero__cta">
            <Button variant="primary" size="lg" as="a" href="#mechanics">Explore the library</Button>
            <Button variant="secondary" size="lg" as="a" href="#work">Work with us</Button>
          </div>
        </div>
        <div className="hero__evidence">
          <div className="carousel" aria-label="Mechanics from the library">
            <div className="carousel__track">
              {loop.map((m, i) => (
                <article className="mcard" key={i} aria-hidden={i >= CAROUSEL.length ? "true" : undefined}>
                  <div className="mcard__shot">{m.app} · {m.screen}</div>
                  <div className="mcard__body">
                    <Tag category={m.cat} dot>{m.mechanic}</Tag>
                    <p className="mcard__title">{m.title}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const APPS = [
  { name: "Duolingo", mark: "Du" },
  { name: "Royal Match", mark: "RM" },
  { name: "Monopoly Go", mark: "MG" },
  { name: "Finch", mark: "Fi" },
  { name: "BeReal", mark: "Be" },
  { name: "Strava", mark: "St" },
  { name: "Headspace", mark: "Hs" },
  { name: "Revolut", mark: "Re" },
  { name: "Calm", mark: "Ca" },
  { name: "Notion", mark: "No" },
];

/** Logo strip: a sample of the apps studied in the library, as 60×60 marks. */
function LogoStrip() {
  return (
    <section className="band band--tight band--sheet" aria-label="Apps in the library">
      <div className="container">
        <p className="logostrip__lead">A few of the apps in the library</p>
        <div className="logostrip">
          {APPS.map((a) => (
            <span className="applogo" key={a.name} role="img" aria-label={a.name} title={a.name}>{a.mark}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

const LIB = [
  { count: "25", h: "Case studies", p: "Full breakdowns of how real apps build engagement, mechanic by mechanic.", link: "Browse case studies", href: "#case-studies" },
  { count: "25", h: "Systems", p: "How mechanics combine into the loops that keep players coming back.", link: "Explore systems", href: "#systems" },
  { count: "6", h: "Cheatsheets", p: "Practical implementation guides your team can build straight from.", link: "Open cheatsheets", href: "#cheatsheets" },
];

/** Library contents: what's inside, as three counted cards. */
function LibraryContents() {
  return (
    <section className="band" id="library" aria-labelledby="lib-contents-h">
      <div className="container">
        <div className="sec-head">
          <h2 className="sec-head__t" id="lib-contents-h">What's inside the library</h2>
        </div>
        <div className="libgrid">
          {LIB.map((c) => (
            <Card key={c.h} className="libcard">
              <div className="libcard__count">{c.count}</div>
              <h3>{c.h}</h3>
              <p>{c.p}</p>
              <a className="libcard__link" href={c.href}>{c.link} <i data-lucide="arrow-right" /></a>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

/** Free case study spotlight: Royal Match, open to everyone. The transitional
 *  call to action, with a screenshot and a line describing it. */
function CaseStudySpotlight() {
  return (
    <section className="band band--sunken" id="case-studies" aria-labelledby="spot-h">
      <div className="container">
        <div className="spotlight">
          <div className="spotlight__body">
            <div className="eyebrow">Free case study</div>
            <h2 id="spot-h">See exactly what a full breakdown looks like</h2>
            <div className="spotlight__meta">
              <Badge tone="accent" variant="solid">Free</Badge>
              <Tag category="monetization" dot>Monetization</Tag>
              <span style={{ font: "var(--type-data)", fontSize: 12, color: "var(--text-muted)" }}>Royal Match · analyzed Jun 2026</span>
            </div>
            <p>Royal Match keeps players coming back without a single leaderboard. We mapped every mechanic it uses, why each one works, and what your app needs in place to borrow it well. The whole breakdown is open, no account required.</p>
            <Button variant="primary" size="lg" as="a" href="#royal-match" trailingIcon={<i data-lucide="arrow-up-right" />}>Read the Royal Match breakdown</Button>
          </div>
          <div className="spotlight__evidence">
            <AnnotatedScreenshot
              appName="Royal Match"
              screenLabel="Daily reward modal"
              date="Analyzed Jun 2026"
              alt="Royal Match daily reward"
              caption="The daily reward lands the moment the screen opens, so the next session already has a reason to start."
            />
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(GBSite, { Hero, LogoStrip, LibraryContents, CaseStudySpotlight });
})();

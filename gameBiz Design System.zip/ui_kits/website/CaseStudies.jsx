/* Website kit — Case studies (apps index). Title block defining a "system",
   then a 3-up grid of system cards, one per analyzed app/game.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Tag, Badge } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

/* Lucide-style inline glyphs (created inline so they render before the CDN
   pass and never turn red). */
const LockIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);
const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);

/* Apps and games studied as systems. `locked` = behind the subscription
   (a dimmed preview, not a wall); Royal Match stays open to everyone.
   `tags` are a few of the mechanics from the 22-mechanic framework;
   `mechanics` is the full count. */
const STUDIES = [
  {
    id: "RM", name: "Royal Match", type: "Game", locked: false, mechanics: 9,
    desc: "Royal Match keeps a saga puzzle moving with lives that meter each session and limited-time events that concentrate spend.",
    tags: ["Energy / Lives", "Limited-Time Events", "Season Pass", "Daily Reward"],
    href: "#royal-match",
  },
  {
    id: "Du", name: "Duolingo", type: "App", locked: true, mechanics: 11,
    desc: "Duolingo pairs a visible streak with loss aversion, so a single missed day reads as real ground given up.",
    tags: ["Streak", "Loss Aversion", "Leaderboards", "Quests"],
  },
  {
    id: "MG", name: "Monopoly Go", type: "Game", locked: true, mechanics: 10,
    desc: "Monopoly Go runs on dice as a spendable resource, with collections and timed events pulling players back between refills.",
    tags: ["Energy / Lives", "Collections / Sets", "Limited-Time Events", "Teams / Guilds"],
  },
  {
    id: "St", name: "Strava", type: "App", locked: true, mechanics: 8,
    desc: "Strava turns solo workouts into standing, ranking segments against peers and tying milestones to the people you follow.",
    tags: ["Leaderboards", "Milestone Rewards", "Social Challenges", "Badges"],
  },
  {
    id: "CC", name: "Candy Crush Saga", type: "Game", locked: true, mechanics: 9,
    desc: "Candy Crush paces play with lives and a long progress map, so the next level always sits one short session away.",
    tags: ["Energy / Lives", "Progress Bar", "Daily Reward", "Limited-Time Events"],
  },
  {
    id: "Hs", name: "Headspace", type: "App", locked: true, mechanics: 7,
    desc: "Headspace protects a meditation habit with a run streak and milestone markers that make consistency visible.",
    tags: ["Streak", "Milestone Rewards", "Progress Bar", "Onboarding Goal"],
  },
  {
    id: "CoC", name: "Clash of Clans", type: "Game", locked: true, mechanics: 12,
    desc: "Clash of Clans anchors retention in clans, where shared goals make a player's return owed partly to teammates.",
    tags: ["Teams / Guilds", "Tiers / Levels", "Season Pass", "Social Challenges"],
  },
  {
    id: "Sb", name: "Starbucks", type: "App", locked: true, mechanics: 8,
    desc: "Starbucks Rewards converts everyday purchases into tiers and limited offers that make the next order worth tracking.",
    tags: ["Tiers / Levels", "Milestone Rewards", "Limited-Time Events", "Referral Rewards"],
  },
  {
    id: "CM", name: "Coin Master", type: "Game", locked: true, mechanics: 10,
    desc: "Coin Master builds sessions on a spin with variable rewards, then collections and gifting keep the social loop turning.",
    tags: ["Variable Rewards", "Collections / Sets", "Gifting", "Daily Reward"],
  },
];

function SystemCard({ s }) {
  return (
    <a className={"csc" + (s.locked ? " csc--locked" : "")} href={s.href || "#subscribe"}>
      <div className="csc__top">
        <Tag category="neutral" variant="outline">{s.type}</Tag>
        <span className="csc__badge">
          {s.locked
            ? <Badge tone="neutral" variant="outline" icon={LockIcon}>For subscribers</Badge>
            : <Badge tone="ok" variant="soft">Free</Badge>}
        </span>
      </div>

      <h3 className="csc__name">{s.name}</h3>

      <p className="csc__desc">{s.desc}</p>

      <div className="csc__tags">
        {s.tags.map((t) => <span className="pillchip" key={t}>{t}</span>)}
      </div>

      <div className="csc__foot">
        <span className="csc__count"><b>{s.mechanics}</b> mechanics mapped</span>
        <span className="csc__go">{s.locked ? "Subscribe to read" : "View case study"} {ArrowIcon}</span>
      </div>
    </a>
  );
}

/** Case studies: the apps index, each app studied as a system. */
function CaseStudiesPage() {
  const free = STUDIES.filter((s) => !s.locked).length;
  return (
    <main id="main">
      <section className="cs-head" aria-labelledby="cs-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="#library">Library</a>
            <span className="crumb__sep" aria-hidden="true">/</span>
            <span>Case studies</span>
          </nav>
          <div className="eyebrow cs-head__eyebrow">The library</div>
          <h1 id="cs-h">Case studies</h1>
          <p className="cs-head__def">
            Every app here is studied as a <b>system</b>: the set of mechanics it runs and the way
            they feed each other, like a streak that protects a daily reward, or a leaderboard that
            fuels a season pass. We take each one apart, map it against the 22-mechanic framework,
            and show how the parts hold together.
          </p>
        </div>
      </section>

      <div className="container cs-wrap">
        <div className="cs-bar">
          <span className="cs-bar__count"><b>{STUDIES.length}</b> systems in the library</span>
          <span className="cs-bar__hint">{free} free to read · updated weekly</span>
        </div>

        <div className="csgrid">
          {STUDIES.map((s) => <SystemCard key={s.id} s={s} />)}
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { CaseStudiesPage });
})();

/* Website kit — Subscribe page. Friction-free entry to the library, with the free
   tier explained honestly. Hero + placeholder checkout moment (no transaction),
   what's inside with live counts, an honest free/full comparison (no prices, no
   decoy, no "most popular"), the weekly cadence as pure evidence, and one line of
   reassurance. Loaded as a Babel script; reads DS primitives, attaches to GBSite. */
(function () {
const React = window.React;
const { useState, useEffect } = React;
const { Button, Input } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const CheckIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <polyline points="20 6 9 17 4 12" />
  </svg>
);
const CloseIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);
const MailIcon = <i data-lucide="mail" />;

const INSIDE = [
  { count: "25", label: "App case studies", desc: "Full breakdowns, mechanic by mechanic, with annotated screenshots." },
  { count: "22", label: "Mechanics", desc: "Every building block, with the psychology behind it and where it fits." },
  { count: "25", label: "System maps", desc: "How each app's mechanics connect into the loops that bring players back." },
  { count: "6", label: "Cheatsheets", desc: "Step-by-step guides your team can build straight from." },
  { count: "15", label: "Glossary terms", desc: "Plain-language definitions for every term the library uses." },
];

const FREE = [
  "The Royal Match case study, in full",
  "A preview of every other case study, mechanic, and system map",
  "The opening of each cheatsheet",
  "The complete glossary",
];
const FULL = [
  "Every case study, mechanic, system map, and cheatsheet, in full",
  "Every system map, complete with its connections and requirements",
  "New app breakdowns added every week",
  "The complete glossary",
];

const NEW_THIS_WEEK = [
  { title: "Monopoly Go: event pacing breakdown", date: "Jun 6, 2026" },
  { title: "Finch: gentle self-care streaks", date: "Jun 4, 2026" },
  { title: "BeReal: the social window", date: "Jun 2, 2026" },
];

/* The placeholder checkout moment. A calm, dismissible sheet — the start of a
   subscription, designed before payments exist. Never traps; Esc or the scrim
   closes it. */
function CheckoutSheet({ open, onClose }) {
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  useEffect(() => { if (!open) setDone(false); }, [open]);
  if (!open) return null;
  return (
    <div className="sub-sheet" role="dialog" aria-modal="true" aria-labelledby="sheet-h" onMouseDown={onClose}>
      <div className="sub-sheet__card" onMouseDown={(e) => e.stopPropagation()}>
        <button className="sub-sheet__close" onClick={onClose} aria-label="Close">{CloseIcon}</button>
        {!done ? (
          <React.Fragment>
            <div className="eyebrow">Start your subscription</div>
            <h2 id="sheet-h" className="sub-sheet__title">Save your place in the library</h2>
            <p className="sub-sheet__p">Checkout opens soon. Leave your email and we'll set up your account the moment it's ready — full access from your first sign-in.</p>
            <form className="sub-sheet__form" onSubmit={(e) => { e.preventDefault(); setDone(true); }}>
              <Input label="Email" size="lg" type="email" required placeholder="you@company.com" leadingIcon={MailIcon} aria-label="Email address" />
              <Button variant="accent" size="lg" type="submit">Continue</Button>
            </form>
          </React.Fragment>
        ) : (
          <div className="sub-sheet__done">
            <span className="sub-sheet__check" aria-hidden="true">{CheckIcon}</span>
            <h2 className="sub-sheet__title">You're on the list</h2>
            <p className="sub-sheet__p">We'll email you the moment checkout opens. Until then, the Royal Match case study and every preview are yours to read.</p>
            <Button variant="secondary" size="lg" as="a" href="case-study-royal-match.html">Read the free case study</Button>
          </div>
        )}
      </div>
    </div>
  );
}

/** Subscribe page body. */
function SubscribePage() {
  const [open, setOpen] = useState(false);
  const openSheet = (e) => { if (e) e.preventDefault(); setOpen(true); };

  return (
    <main id="main">
      {/* 1. Hero */}
      <section className="sub-hero" aria-labelledby="sub-h">
        <div className="container">
          <div className="sub-hero__in">
            <div className="eyebrow">The library</div>
            <h1 id="sub-h">The reference library for how the best apps and games build engagement.</h1>
            <p className="sub-hero__sub">Full access to every case study, mechanic, system map, and cheatsheet. New apps added every week.</p>
            <div className="sub-hero__cta">
              <Button variant="accent" size="lg" as="a" href="#start" onClick={openSheet}>Subscribe</Button>
              <a className="sub-hero__alt" href="login.html">Already a subscriber? Log in</a>
            </div>
          </div>
        </div>
      </section>

      {/* 2. What's inside */}
      <section className="band band--sheet" aria-labelledby="inside-h">
        <div className="container">
          <div className="mech-section__kicker">What's inside</div>
          <h2 className="mech-section__title" id="inside-h">Five kinds of reference, one library</h2>
          <div className="sub-inside">
            {INSIDE.map((c) => (
              <div className="sub-inside__card" key={c.label}>
                <span className="sub-inside__count">{c.count}</span>
                <span className="sub-inside__label">{c.label}</span>
                <span className="sub-inside__desc">{c.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Free and full, side by side */}
      <section className="band" aria-labelledby="tiers-h">
        <div className="container">
          <div className="mech-section__kicker">Free and full</div>
          <h2 className="mech-section__title" id="tiers-h">What you can read, either way</h2>
          <div className="sub-tiers">
            <div className="sub-tier">
              <div className="sub-tier__head">
                <h3 className="sub-tier__name">Free</h3>
                <p className="sub-tier__note">No account needed to start reading.</p>
              </div>
              <ul className="sub-tier__list">
                {FREE.map((f) => (
                  <li key={f}><span className="sub-tier__check" aria-hidden="true">{CheckIcon}</span>{f}</li>
                ))}
              </ul>
              <Button variant="secondary" size="lg" as="a" href="case-study-royal-match.html">Read the free case study</Button>
            </div>

            <div className="sub-tier sub-tier--full">
              <div className="sub-tier__head">
                <h3 className="sub-tier__name">Full access</h3>
                <p className="sub-tier__note">Everything, plus every new addition.</p>
              </div>
              <ul className="sub-tier__list">
                {FULL.map((f) => (
                  <li key={f}><span className="sub-tier__check" aria-hidden="true">{CheckIcon}</span>{f}</li>
                ))}
              </ul>
              <Button variant="accent" size="lg" as="a" href="#start" onClick={openSheet}>Subscribe</Button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. The cadence — pure evidence */}
      <section className="band band--sunken" aria-labelledby="cadence-h">
        <div className="container">
          <div className="mech-section__kicker">The cadence</div>
          <h2 className="mech-section__title" id="cadence-h">New this week</h2>
          <div className="feed sub-feed">
            {NEW_THIS_WEEK.map((it) => (
              <div className="feed__row" key={it.title}>
                <span className="feed__main"><span className="feed__title">{it.title}</span></span>
                <span className="feed__date">{it.date}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. One-line reassurance */}
      <section className="sub-reassure">
        <div className="container">
          <p>Cancel anytime, keep what you've learned.</p>
        </div>
      </section>

      <CheckoutSheet open={open} onClose={() => setOpen(false)} />
    </main>
  );
}

Object.assign(GBSite, { SubscribePage });
})();

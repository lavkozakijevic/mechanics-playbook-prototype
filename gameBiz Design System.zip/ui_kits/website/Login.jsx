/* Website kit — Log in page. Minimal to the point of austerity: email + password,
   a Log in button, a forgot-password link, and one quiet line for non-members.
   No imagery, no marketing copy. Email-based entry only (no third-party login).
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Button, Input } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const LOGO_INK = "../../assets/logo/gamebiz-logo-ink.svg";
const MailIcon = <i data-lucide="mail" />;
const LockIcon = <i data-lucide="lock" />;

/** Log in page — a returning subscriber coming back to a tool. */
function LoginPage() {
  return (
    <main className="login" id="main">
      <div className="login__card">
        <a className="login__brand" href="index.html" aria-label="GameBiz home">
          <img src={(window.__resources && window.__resources.gbLogoInk) || LOGO_INK} alt="GameBiz" width="124" height="25" />
        </a>

        <form className="login__form" onSubmit={(e) => e.preventDefault()}>
          <Input label="Email" size="lg" type="email" required placeholder="you@company.com" leadingIcon={MailIcon} autoComplete="email" />
          <div className="login__pw">
            <Input label="Password" size="lg" type="password" required placeholder="Your password" leadingIcon={LockIcon} autoComplete="current-password" />
            <a className="login__forgot" href="#reset">Forgot password</a>
          </div>
          <Button variant="primary" size="lg" type="submit" className="login__submit">Log in</Button>
        </form>
      </div>

      <p className="login__alt">
        Not a subscriber yet? <a href="subscribe.html">See what's inside</a>
      </p>
    </main>
  );
}

Object.assign(GBSite, { LoginPage });
})();

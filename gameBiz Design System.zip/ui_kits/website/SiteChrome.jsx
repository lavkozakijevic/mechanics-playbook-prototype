/* Website kit chrome. Loaded as a Babel script in index.html (not via the DS
   bundle), so it reads React + DS primitives from globals and attaches its own
   components to window.GBSite. */
(function () {
const React = window.React;
const { useState } = React;
const { Button, Input } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const LOGO = "../../assets/logo/gamebiz-logo.svg";
const LOGO_INK = "../../assets/logo/gamebiz-logo-ink.svg";

const NAV = [
  {
    label: "Library",
    href: "#library",
    children: [
      { label: "Mechanics", href: "#mechanics", desc: "The core building blocks, with the psychology behind each one." },
      { label: "Systems", href: "#systems", desc: "How mechanics combine into the loops that keep players coming back." },
      { label: "Cheatsheets", href: "#cheatsheets", desc: "Practical guides for putting mechanics into your product." },
      { label: "Glossary", href: "#glossary", desc: "Plain-language definitions for every term we use." },
    ],
  },
  { label: "Case studies", href: "#case-studies" },
  {
    label: "Reports",
    href: "#reports",
    children: [
      { label: "Gamification for finance", href: "#reports-finance", desc: "What banking and fintech apps rely on, and where the openings are." },
      { label: "Gamification for fitness", href: "#reports-fitness", desc: "How health and fitness apps build lasting habits." },
      { label: "Gamification for productivity", href: "#reports-productivity", desc: "What keeps users returning to tools and trackers." },
    ],
  },
  { label: "Work with us", href: "#work" },
];

function Caret() {
  return (
    <svg className="nav__caret" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

/** Primary site navigation. Sticky, paper, hairline rule. Three groups, two with
 *  dropdown menus (hover and keyboard-focus on desktop). Collapses to a drawer
 *  below 1024px. Subscribe is the one accent action. */
function SiteNav({ current }) {
  const [open, setOpen] = useState(false);
  const isCurrent = (href) => (current && href === `#${current}` ? "page" : undefined);

  return (
    <header className="nav">
      <div className="container nav__in">
        <a className="nav__brand" href="#top" aria-label="GameBiz home">
          <img className="nav__logo" src={(window.__resources && window.__resources.gbLogo) || LOGO} alt="GameBiz" width="100" height="22" />
        </a>
        <span className="nav__fresh"><span className="pip" />Updated weekly</span>

        <div className="nav__spacer" />

        <nav className="nav__links" aria-label="Primary">
          {NAV.map((item) =>
            item.children ? (
              <div className="nav__item" key={item.label}>
                <a className="nav__link nav__trigger" href={item.href} aria-haspopup="true" aria-current={isCurrent(item.href)}>
                  {item.label}<Caret />
                </a>
                <div className="nav__menu" role="menu" aria-label={item.label}>
                  {item.children.map((c) => (
                    <a key={c.label} role="menuitem" href={c.href}>
                      <span className="nav__menu-t">{c.label}</span>
                      <span className="nav__menu-d">{c.desc}</span>
                    </a>
                  ))}
                </div>
              </div>
            ) : (
              <a key={item.label} className="nav__link" href={item.href} aria-current={isCurrent(item.href)}>{item.label}</a>
            )
          )}
        </nav>

        <div className="nav__actions">
          <a className="nav__link" href="#login">Log in</a>
          <a className="nav__link" href="#subscribe">Subscribe</a>
        </div>

        <button
          className="nav__burger"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            {open
              ? <><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></>
              : <><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" /></>}
          </svg>
        </button>
      </div>

      <div className="nav__drawer" data-open={open} role="dialog" aria-label="Menu" aria-hidden={!open}>
        {NAV.map((item) => (
          <div className="nav__drawer-group" key={item.label}>
            <a className="nav__drawer-head" href={item.href} onClick={() => setOpen(false)}>{item.label}</a>
            {item.children && (
              <div className="nav__drawer-sub">
                {item.children.map((c) => (
                  <a key={c.label} href={c.href} onClick={() => setOpen(false)}>
                    <span className="nav__menu-t">{c.label}</span>
                    <span className="nav__menu-d">{c.desc}</span>
                  </a>
                ))}
              </div>
            )}
          </div>
        ))}
        <div className="nav__drawer-actions">
          <a className="nav__link" href="#login" onClick={() => setOpen(false)}>Log in</a>
          <a className="nav__link" href="#subscribe" onClick={() => setOpen(false)}>Subscribe</a>
        </div>
      </div>
    </header>
  );
}

/** Newsletter signup: one field, one sentence on what subscribers get. */
function NewsletterBlock() {
  return (
    <section className="band band--sheet" aria-labelledby="newsletter-h">
      <div className="container">
        <div className="newsletter">
          <div>
            <h2 id="newsletter-h">Three new case studies every week</h2>
            <p>Each week we add three fresh app breakdowns to the library. We'll send them straight to your inbox, dated, with a line on what makes each one worth your time.</p>
          </div>
          <form className="newsletter__form" onSubmit={(e) => e.preventDefault()}>
            <Input label="Email" size="lg" type="email" placeholder="you@company.com" aria-label="Email address" />
            <Button variant="primary" size="lg" type="submit">Subscribe</Button>
          </form>
        </div>
      </div>
    </section>
  );
}

const FOOTER_COLS = [
  { h: "Library", links: ["Mechanics", "Apps", "Systems", "Cheatsheets", "Glossary"] },
  { h: "Practice", links: ["Work with us", "Reports"] },
  { h: "Account", links: ["Subscribe", "Log in"] },
];

/** Footer: all navigation, the one-liner, contact, freshness, copyright. */
function SiteFooter() {
  return (
    <footer className="footer" id="footer">
      <div className="container">
        <div className="footer__top">
          <div>
            <img className="footer__brand-logo" src={(window.__resources && window.__resources.gbLogoInk) || LOGO_INK} alt="GameBiz" width="120" height="24" />
            <p className="footer__desc">We study how the best apps and games keep their players, mechanic by mechanic, and help your team apply what fits your product, so your users stay, engage, and grow.</p>
          </div>
          <div className="footer__cols">
            {FOOTER_COLS.map((c) => (
              <div className="footer__col" key={c.h}>
                <h4>{c.h}</h4>
                {c.links.map((l) => (
                  <a key={l} href="#">{l}</a>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="footer__bottom">
          <span className="footer__fresh"><span className="pip" />Updated weekly · last addition Jun 6, 2026</span>
          <span className="footer__meta">
            <a className="footer__email" href="mailto:hello@gamebiz.co">hello@gamebiz.co</a>
            <span className="footer__sep" aria-hidden="true">·</span>
            © 2026 GameBiz Consulting
          </span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(GBSite, { SiteNav, NewsletterBlock, SiteFooter });
})();

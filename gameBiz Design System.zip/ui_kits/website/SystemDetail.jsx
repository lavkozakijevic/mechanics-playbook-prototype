/* Website kit — System detail page (App system: Duolingo). The signature asset
   made interactive: a node-based map of one app's mechanics with typed, labeled
   connections, "+" tap targets that open a connection-detail modal, a legend, and
   a flat mechanic list as the mobile fallback.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { useState, useEffect } = React;
const { Tag } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const CAT_COLOR = {
  retention: "var(--cat-retention)", monetization: "var(--cat-monetization)", social: "var(--cat-social)",
};
const CAT_LABEL = { retention: "Retention", monetization: "Monetization", social: "Social" };

const ArrowIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
);
const ArrowRight = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
);
const CloseIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

/* The Duolingo system. Nodes are the mechanics; x/y are percentages on a
   1000x560 conceptual canvas. `spine` marks the core-action anchor. */
/* The Duolingo system laid out as a center-hub hexagon: the spine anchor (Daily
   lesson) sits at the center, the other six mechanics on a flat-top hexagon,
   ordered so the mechanic-to-mechanic links fall on adjacent edges. x/y are
   percentages on a 1000x560 conceptual canvas. */
const NODES = [
  { id: "lesson", label: "Daily lesson", cat: "retention", x: 50, y: 50, spine: true, href: "#",
    desc: "The core action. A short, gamified practice session, and the one thing the app asks of you each day." },
  { id: "loss", label: "Loss aversion", cat: "retention", x: 32, y: 16, href: "#",
    desc: "Your streak is shown as something already earned and at risk, so you act to keep it rather than to chase more." },
  { id: "streak", label: "Streak", cat: "retention", x: 68, y: 16, href: "mechanic-streak.html",
    desc: "A count of consecutive days you have practiced, framed so the number itself feels worth protecting." },
  { id: "quests", label: "Daily quests", cat: "retention", x: 86, y: 50, href: "#",
    desc: "Small, named goals refreshed each day that point you toward the right actions and pay out the moment you finish." },
  { id: "gems", label: "Gems", cat: "monetization", x: 68, y: 84, href: "#",
    desc: "The soft currency you earn through play and spend on refills and boosts, linking effort to convenience." },
  { id: "hearts", label: "Hearts", cat: "monetization", x: 32, y: 84, href: "#",
    desc: "A spendable resource lost to mistakes, metering how much you can practice before a wait or a purchase." },
  { id: "league", label: "Leagues", cat: "social", x: 14, y: 50, href: "#",
    desc: "A weekly ranked table that sets your XP beside a cohort of other learners, turning practice into standing." },
];

/* Connections carry a `type` (spine | mechanic | retention | monetization | social),
   a short on-line `label`, and the modal `name` + `effect` (effect on the user). */
const CONNECTIONS = [
  { from: "lesson", to: "streak", type: "spine", label: "advances",
    name: "Daily lesson advances the streak",
    effect: "Completing today's lesson ticks the streak forward, so a single session quietly becomes a chain you will not want to break." },
  { from: "streak", to: "loss", type: "retention", label: "protected by",
    name: "The streak is protected by loss aversion",
    effect: "A longer streak raises the cost of missing a day, and loss aversion turns that cost into the reason you come back tomorrow." },
  { from: "lesson", to: "hearts", type: "monetization", label: "spends",
    name: "Lessons spend hearts",
    effect: "Mistakes in a lesson cost hearts, adding a gentle price to careless practice and a moment where a user might wait or pay." },
  { from: "lesson", to: "league", type: "social", label: "ranks in",
    name: "Lessons rank you in a league",
    effect: "Every lesson's XP feeds your weekly league position, so the same practice that builds the habit also fuels the competition." },
  { from: "streak", to: "quests", type: "mechanic", label: "bundled with",
    name: "Streak and quests share the daily view",
    effect: "Quests sit beside the streak in the same daily screen, so the habit you protect and the tasks you chase reinforce each other." },
  { from: "quests", to: "gems", type: "monetization", label: "rewards",
    name: "Quests reward gems",
    effect: "Finishing quests pays out gems, converting small daily goals into a currency you can feel accumulating session over session." },
  { from: "hearts", to: "gems", type: "monetization", label: "refilled by",
    name: "Hearts are refilled by gems",
    effect: "Running out of hearts sends you to gems to refill, the point where the currency you earned turns into convenience you buy." },
];

const LINE_TYPE = {
  spine: "App spine", mechanic: "Mechanic connection",
  retention: "Retention", monetization: "Monetization", social: "Social",
};
const TYPE_COLOR = {
  spine: "var(--ink-600)", mechanic: "var(--ink-400)",
  retention: "var(--cat-retention)", monetization: "var(--cat-monetization)", social: "var(--cat-social)",
};

const W = 1000, H = 560;
const byId = Object.fromEntries(NODES.map((n) => [n.id, n]));

/* Quadratic-curve geometry shared by the SVG path and the chip placement. The
   chip sits at parameter t along the curve (default mid), tuned per connection
   so the bubbles never overlap each other or a node. */
function geom(c) {
  const a = byId[c.from], b = byId[c.to];
  const x1 = (a.x / 100) * W, y1 = (a.y / 100) * H;
  const x2 = (b.x / 100) * W, y2 = (b.y / 100) * H;
  const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
  const cy = my - Math.min(40, Math.abs(x2 - x1) * 0.18);
  const t = c.t != null ? c.t : 0.5, it = 1 - t;
  const ax = it * it * x1 + 2 * it * t * mx + t * t * x2;
  const ay = it * it * y1 + 2 * it * t * cy + t * t * y2;
  return { d: `M ${x1} ${y1} Q ${mx} ${cy} ${x2} ${y2}`, apex: { x: (ax / W) * 100, y: (ay / H) * 100 } };
}

function InteractiveMap({ onOpen }) {
  return (
    <div className="smap">
      <div className="smap__paper" />
      <svg className="smap__svg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        {CONNECTIONS.map((c, i) => (
          <path key={i} className={`smap__line smap__line--${c.type}`} d={geom(c).d} />
        ))}
      </svg>

      {NODES.map((n) => (
        <a
          key={n.id}
          href={n.href}
          className={"smap__node" + (n.spine ? " smap__node--spine" : "")}
          style={{ left: n.x + "%", top: n.y + "%" }}
        >
          <span className="smap__cat">
            <span className="smap__dot" style={{ background: CAT_COLOR[n.cat] }} />
            {CAT_LABEL[n.cat]}
          </span>
          <span className="smap__label">{n.label}</span>
        </a>
      ))}

      {CONNECTIONS.map((c, i) => {
        const { apex } = geom(c);
        return (
          <button
            key={i}
            type="button"
            className="conn"
            style={{ left: apex.x + "%", top: apex.y + "%" }}
            onClick={() => onOpen(c)}
            aria-label={`How ${byId[c.from].label} connects to ${byId[c.to].label}`}
          >
            <span className="conn__label">{c.label}</span>
            <span className="conn__plus" aria-hidden="true">+</span>
          </button>
        );
      })}
    </div>
  );
}

const LEGEND = ["spine", "mechanic", "retention", "monetization", "social"];

function MapLegend() {
  return (
    <div className="maplegend" aria-label="Connection types">
      {LEGEND.map((t) => (
        <span className="maplegend__item" key={t}>
          <span className={`maplegend__sw maplegend__sw--line maplegend__sw--${t}`} />
          {LINE_TYPE[t]}
        </span>
      ))}
    </div>
  );
}

/* Mobile fallback: a flat list of the mechanics, each with category, name, and a
   description paragraph. */
function MechanicList() {
  return (
    <div className="syslist">
      {NODES.map((n) => (
        <div className="sysrow" key={n.id}>
          <div className="sysrow__head">
            <Tag category={n.cat} dot>{CAT_LABEL[n.cat]}</Tag>
            <span className="sysrow__name">{n.label}</span>
          </div>
          <p>{n.desc}</p>
        </div>
      ))}
    </div>
  );
}

function ConnectionModal({ conn, onClose }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [onClose]);

  const a = byId[conn.from], b = byId[conn.to];
  const dashed = conn.type === "mechanic";
  return (
    <div className="cmodal" role="dialog" aria-modal="true" aria-labelledby="cmodal-title">
      <div className="cmodal__backdrop" onClick={onClose} />
      <div className="cmodal__dialog">
        <button type="button" className="cmodal__close" onClick={onClose} aria-label="Close">{CloseIcon}</button>
        <span className="cmodal__kicker">
          <span className={"conn__bar" + (dashed ? " conn__bar--dashed" : "")} style={dashed ? undefined : { background: TYPE_COLOR[conn.type] }} />
          {LINE_TYPE[conn.type]} connection
        </span>
        <h2 className="cmodal__title" id="cmodal-title">{conn.name}</h2>
        <div className="cmodal__pair">
          <span className="cmodal__chip"><span className="smap__dot" style={{ background: CAT_COLOR[a.cat] }} />{a.label}</span>
          <span className="cmodal__arrow" aria-hidden="true">{ArrowRight}</span>
          <span className="cmodal__chip"><span className="smap__dot" style={{ background: CAT_COLOR[b.cat] }} />{b.label}</span>
        </div>
        <div className="cmodal__elabel">Effect on the user</div>
        <p className="cmodal__effect">{conn.effect}</p>
      </div>
    </div>
  );
}

/** App system detail page: overview, core loop, the interactive map, the key
 *  insight, what makes it work, and a link to the full case study. */
function SystemDetailPage() {
  const [active, setActive] = useState(null);

  return (
    <main id="main">
      {/* System overview block */}
      <section className="mech-head" aria-labelledby="sys-h">
        <div className="container">
          <nav className="crumb" aria-label="Breadcrumb">
            <a href="systems.html">Systems</a>
            <span className="crumb__sep" aria-hidden="true">›</span>
            <span>Duolingo</span>
          </nav>
          <div className="sys-meta">
            <Tag category="neutral" variant="outline">App</Tag>
            <span className="sys-cat"><span className="sys-cat__dot" style={{ background: CAT_COLOR.retention }} />Language learning</span>
          </div>
          <h1 id="sys-h">The Duolingo system</h1>
          <p className="mech-head__def">How a daily streak, a weekly league, and a small soft economy keep a slow goal, learning a language, alive one short session at a time.</p>
        </div>
      </section>

      {/* Overview + core loop */}
      <section className="band--tight">
        <div className="container">
          <div className="sys-read">
            <div className="mech-section" style={{ marginBottom: "clamp(28px, 4vw, 44px)" }}>
            <div className="mech-section__kicker">Overview</div>
            <h2 className="mech-section__title">The design logic</h2>
            <div className="mech-prose">
              <p>Duolingo's system is built around one fragile thing worth protecting: the streak. Everything else, the leagues, the hearts, the quests, exists to make the daily return feel earned, social, and a little costly to skip. The logic is to take a slow goal that is easy to abandon, learning a language, and wrap it in faster loops that pay out today while the real progress accrues quietly underneath.</p>
            </div>
          </div>
            <div className="mech-section">
              <div className="mech-section__kicker">Core loop</div>
              <h2 className="mech-section__title">The mechanic sequence</h2>
              <div className="mech-prose">
                <p>The loop starts with a single lesson. Finishing it earns XP and advances the streak, which loss aversion immediately reframes as something you could lose. That same XP drops you into a weekly league, so practice doubles as competition. Mistakes spend hearts, and empty hearts point toward gems, which the day's quests are busy paying back. Every path leads to the same place: the next lesson.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive system map */}
      <section className="band--tight sys-mapsec" aria-labelledby="map-h">
        <div className="container">
          <div className="smap-head">
            <h2 className="smap-head__t" id="map-h">The system map</h2>
            <span className="smap-head__hint">Tap any + on a connection to see how the two mechanics interact</span>
          </div>
          <div className="smap-stage">
            <InteractiveMap onOpen={setActive} />
            <MapLegend />
          </div>
          <MechanicList />
        </div>
      </section>

      {/* Key insight */}
      <section className="band--tight">
        <div className="container">
          <div className="sys-insight">
            <div className="sys-insight__k">Key insight</div>
            <p>The streak works less as a prize than as something a user has already built. Once a number feels like theirs, the reason to practice the next day shifts from making progress to keeping what they have, which tends to be a steadier pull than progress on its own.</p>
          </div>
        </div>
      </section>

      {/* What makes it work */}
      <section className="band--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="sys-read">
            <div className="mech-section">
              <div className="mech-section__kicker">What makes it work</div>
              <h2 className="mech-section__title">No single mechanic carries the weight</h2>
              <div className="mech-prose">
                <p>The system holds because the load is shared. The streak supplies the reason to return, leagues supply the company, hearts supply the stakes, and quests supply the small wins along the way. Remove any one and the others still stand, which is the difference between a system and a pile of features. The lesson sits at the center of all of them, so the one action the app needs from you is the action every mechanic is quietly arranged around.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case study link */}
      <section className="band--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <a className="cscard" href="case-studies.html">
            <div className="cscard__body">
              <div className="cscard__k">Full case study</div>
              <div className="cscard__t">See every Duolingo mechanic up close</div>
              <p className="cscard__p">The case study walks each mechanic in the map with annotated screenshots from the app and the takeaways a product team can use.</p>
            </div>
            <span className="cscard__go">Read the case study {ArrowIcon}</span>
          </a>
        </div>
      </section>

      {active && <ConnectionModal conn={active} onClose={() => setActive(null)} />}
    </main>
  );
}

Object.assign(GBSite, { SystemDetailPage });
})();

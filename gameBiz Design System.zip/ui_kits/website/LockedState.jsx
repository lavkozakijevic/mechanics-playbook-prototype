/* Website kit — Locked-content state. The treatment a free visitor meets at gated
   content anywhere in the library: a real preview that fades out, then an
   invitation (never a wall). Reuses the DS LockedNotice. Never says "locked",
   "denied", or "premium". The visitor can always keep browsing what's free.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { Tag, LockedNotice } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

/** Locked-content state, shown as it appears in context (a Duolingo breakdown). */
function LockedStatePage() {
  return (
    <main id="main">
      <div className="container">
        <div className="lock-wrap">
          {/* Header — identical to any open breakdown */}
          <header className="cs-hd">
            <nav className="crumb" aria-label="Breadcrumb">
              <a href="case-studies.html">Case studies</a>
              <span className="crumb__sep" aria-hidden="true">/</span>
              <span>Duolingo</span>
              <span className="crumb__sep" aria-hidden="true">/</span>
              <span>Full breakdown</span>
            </nav>
            <div className="cs-hd__row">
              <div className="cs-hd__icon" aria-hidden="true">Du</div>
              <div className="cs-hd__heads">
                <Tag category="neutral" variant="outline">Language app</Tag>
                <h1 className="cs-hd__title">Duolingo {"\u2014"} Full Breakdown</h1>
              </div>
            </div>
            <p className="cs-hd__overview">
              Duolingo turns a daily lesson into a habit almost no other app sustains, and it does it with a
              handful of mechanics working in close concert. This breakdown takes the live app apart piece by
              piece: the streak and the loss aversion that protects it, the hearts that meter practice, the
              leagues that turn solo study into standing.
            </p>
          </header>

          {/* Preview that fades out into the invitation */}
          <div className="lock-preview">
            <section className="lock-sec">
              <div className="mech-section__kicker">Mechanic 01</div>
              <h2 className="mech-section__title">The streak, and what holds it up</h2>
              <div className="mech-prose lock-prose">
                <p>
                  The streak is the most visible thing in the app, and deliberately so. It sits at the top of
                  the home screen as a single number with a flame beside it, and that number is framed not as
                  something you are building but as something you already have. The distinction matters: a
                  count you have earned is a count you can lose, and Duolingo leans on exactly that.
                </p>
                <p>
                  Each completed lesson ticks the streak forward by one. Miss a day and the whole count resets
                  to zero, a consequence the app makes sure you understand well before you are at risk of it.
                  The result is that the cost of skipping a day rises with every day you practice, so the
                  longer your streak, the harder it becomes to break.
                </p>
                <p>
                  Underneath the streak sits a quieter mechanic doing most of the work: loss aversion. The
                  streak would be far weaker if it only promised a reward for returning. What makes it
                  effective is that it frames a missed day as a loss of something concrete and already
                  yours, and a loss looms larger than an equivalent gain.
                </p>
              </div>
            </section>
            <div className="lock-fade" aria-hidden="true" />
          </div>

          {/* The invitation */}
          <div className="lock-invite">
            <LockedNotice
              title="This breakdown is part of the full library"
              primaryLabel="Subscribe for full access"
              primaryHref="subscribe.html"
              secondaryLabel="Read the free case study first"
              secondaryHref="case-study-royal-match.html"
            >
              The rest of this breakdown walks every mechanic in the Duolingo system, with annotated
              screenshots, the connections between them, and what your product needs in place to borrow each
              one. New breakdowns land every week.
            </LockedNotice>
          </div>
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { LockedStatePage });
})();

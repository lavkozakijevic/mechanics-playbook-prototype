/* Website kit — Mechanics Library page. Floating filters + 2-up card grid.
   Loaded as a Babel script; reads DS primitives, attaches to window.GBSite. */
(function () {
const React = window.React;
const { useState, useMemo } = React;
const { Tag, Input, Badge } = window.GameBizDesignSystem_1aad9e;
const GBSite = (window.GBSite = window.GBSite || {});

const CATS = {
  retention:    { label: "Retention",    color: "var(--cat-retention)" },
  monetization: { label: "Monetization", color: "var(--cat-monetization)" },
  social:       { label: "Social",       color: "var(--cat-social)" },
};

/* Player types (Bartle). Dot colors drawn from existing DS tokens. */
const USER_TYPES = {
  achiever:   { label: "Achiever",   color: "var(--cat-social)" },
  explorer:   { label: "Explorer",   color: "var(--cat-monetization)" },
  socializer: { label: "Socializer", color: "var(--cat-retention)" },
  competitor: { label: "Competitor", color: "var(--red-600)" },
};

/* Product-context filters (a curated subset of the tag vocabulary). */
const CONTEXTS = ["activation", "onboarding", "retention", "habit", "progression", "monetization", "growth", "status"];

const MECHANICS = [
  { n: 1,  name: "Streak / Streak Bonus", cats: ["retention"], desc: "A counter that increments each time a user completes a defined action within a set time window, typically once per day.", tags: ["activation", "retention", "habit"], users: ["achiever"], examples: 11, access: "free", href: "mechanic-streak.html" },
  { n: 2,  name: "Daily Reward", cats: ["retention", "monetization"], desc: "A small, escalating gift handed out for opening the app each day, giving the next session a reason to start.", tags: ["habit", "retention"], users: ["achiever"], examples: 14 },
  { n: 3,  name: "Leaderboards", cats: ["social"], desc: "A ranked list that places a user's performance next to their peers, turning effort into visible standing.", tags: ["competition", "social", "status"], users: ["competitor"], examples: 9 },
  { n: 4,  name: "Loss Aversion", cats: ["retention"], desc: "Framing progress as something already earned and at risk, so users act to keep it rather than to chase more.", tags: ["retention", "urgency"], users: ["achiever"], examples: 8 },
  { n: 5,  name: "Gifting", cats: ["social"], desc: "Letting users send small, free value to one another, so the product's growth runs on everyday goodwill.", tags: ["social", "growth"], users: ["socializer"], examples: 7 },
  { n: 6,  name: "Milestone Rewards", cats: ["retention"], desc: "Rewards tied to cumulative progress, marking how far a user has come and what the next marker is worth.", tags: ["progression", "retention"], users: ["achiever"], examples: 10 },
  { n: 7,  name: "Mystery Reward", cats: ["monetization"], desc: "A reward whose contents are revealed only on open, using anticipation to make the moment worth repeating.", tags: ["surprise", "monetization"], users: ["explorer"], examples: 6 },
  { n: 8,  name: "Season Pass", cats: ["monetization", "retention"], desc: "A time-boxed track of rewards unlocked through play, pairing a free tier with a paid one alongside it.", tags: ["monetization", "progression"], users: ["achiever", "competitor"], examples: 12 },
  { n: 9,  name: "Energy / Lives", cats: ["monetization"], desc: "A spendable resource that meters how much a user can play at once, then refills over time or for a fee.", tags: ["pacing", "monetization"], users: ["achiever"], examples: 9 },
  { n: 10, name: "Onboarding Goal", cats: ["retention"], desc: "A clear first objective set in the opening minutes, giving a new user one obvious thing to accomplish.", tags: ["onboarding", "activation"], users: ["achiever", "explorer"], examples: 13 },
  { n: 11, name: "Quests / Missions", cats: ["retention"], desc: "Short, named tasks that point users toward valuable actions and pay out the moment each one is complete.", tags: ["engagement", "progression"], users: ["achiever", "explorer"], examples: 11 },
  { n: 12, name: "Social Challenges", cats: ["social"], desc: "Time-bound goals pursued with or against friends, where the company of others is the reason to keep going.", tags: ["social", "competition"], users: ["socializer", "competitor"], examples: 7 },
  { n: 13, name: "Cosmetics", cats: ["monetization"], desc: "Optional visual items players buy to express themselves, with no effect on the balance of play.", tags: ["monetization", "status"], users: ["explorer", "socializer"], examples: 8 },
  { n: 14, name: "Limited-Time Events", cats: ["monetization", "retention"], desc: "A themed mode available only for a short window, using scarcity to concentrate attention and spend.", tags: ["urgency", "monetization"], users: ["competitor", "achiever"], examples: 10 },
  { n: 15, name: "Progress Bar", cats: ["retention"], desc: "A visible measure of how close a user is to a goal, where the gap left to fill is itself the motivation.", tags: ["progression", "activation"], users: ["achiever"], examples: 12 },
  { n: 16, name: "Badges / Achievements", cats: ["retention"], desc: "Collectible markers awarded for specific feats, giving lasting proof of effort users can display.", tags: ["progression", "status"], users: ["achiever"], examples: 9 },
  { n: 17, name: "Referral Rewards", cats: ["social"], desc: "A two-sided incentive that pays both the inviter and the invited, turning users into a growth channel.", tags: ["growth", "social"], users: ["socializer"], examples: 8 },
  { n: 18, name: "Variable Rewards", cats: ["retention"], desc: "Payouts that vary in size and timing, keeping the next outcome uncertain enough to be worth checking.", tags: ["habit", "retention"], users: ["explorer"], examples: 7 },
  { n: 19, name: "Tiers / Levels", cats: ["retention"], desc: "A ladder of ranks earned through sustained use, where each step up renews the reason to keep climbing.", tags: ["progression", "status"], users: ["achiever", "competitor"], examples: 10 },
  { n: 20, name: "Collections / Sets", cats: ["retention"], desc: "Items grouped into sets that feel incomplete until finished, with the missing piece pulling users back.", tags: ["collection", "retention"], users: ["explorer"], examples: 6 },
  { n: 21, name: "Teams / Guilds", cats: ["social"], desc: "Persistent groups that share goals and accountability, so a user's return is owed partly to teammates.", tags: ["social", "retention"], users: ["socializer"], examples: 8 },
  { n: 22, name: "Login Calendar", cats: ["retention"], desc: "A monthly grid that fills in with each visit, making an unbroken record of attendance worth protecting.", tags: ["habit", "retention"], users: ["achiever"], examples: 9 },
];

const fmt = (s) => s.charAt(0).toUpperCase() + s.slice(1);

const SearchIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);
const LockIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);

function FilterRow({ active, dot, label, onClick }) {
  return (
    <button type="button" className={"frow" + (active ? " frow--active" : "")} aria-pressed={active} onClick={onClick}>
      {dot !== undefined && <span className="frow__dot" style={{ background: dot }} />}
      <span className="frow__label">{label}</span>
    </button>
  );
}

function MechanicLibCard({ m }) {
  const primary = m.cats[0];
  const locked = m.access !== "free";
  return (
    <a className={"mlc" + (locked ? " mlc--locked" : "")} href={locked ? "#subscribe" : (m.href || `#mechanic-${m.n}`)}>
      <div className="mlc__top">
        <span className="mlc__lead">
          <span className="mlc__num">{String(m.n).padStart(2, "0")}</span>
          <Tag category={primary}>{CATS[primary].label}</Tag>
        </span>
        <span className="mlc__badge">
          {locked
            ? <Badge tone="neutral" variant="outline" icon={LockIcon}>For subscribers</Badge>
            : <Badge tone="ok" variant="soft">Free</Badge>}
        </span>
      </div>
      <h3 className="mlc__name">{m.name}</h3>
      <p className="mlc__desc">{m.desc}</p>
      <div className="mlc__tags">
        {m.tags.map((t) => (
          <span className="pillchip" key={t}>{t}</span>
        ))}
      </div>
      <div className="mlc__foot">
        <span className="mlc__dots">
          {m.cats.map((c) => (
            <span className="mlc__dot" key={c} style={{ background: CATS[c].color }} title={CATS[c].label} />
          ))}
        </span>
        <span className="mlc__examples">{m.examples} examples</span>
      </div>
    </a>
  );
}

/** Mechanics library: floating filter panel on the left, 2-up card grid on the right. */
function MechanicsPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [contexts, setContexts] = useState([]);
  const [users, setUsers] = useState([]);

  const toggle = (list, setList, value) =>
    setList(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  const pickCategory = (key) => setCategory((c) => (c === key ? "all" : key));

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MECHANICS.filter((m) => {
      if (q && !(m.name.toLowerCase().includes(q) || m.desc.toLowerCase().includes(q))) return false;
      if (category !== "all" && !m.cats.includes(category)) return false;
      if (contexts.length && !m.tags.some((t) => contexts.includes(t))) return false;
      if (users.length && !m.users.some((u) => users.includes(u))) return false;
      return true;
    });
  }, [query, category, contexts, users]);

  const active = query || category !== "all" || contexts.length || users.length;
  const clearAll = () => { setQuery(""); setCategory("all"); setContexts([]); setUsers([]); };

  return (
    <main id="main">
      <section className="band--tight lib-head">
        <div className="container">
          <div className="eyebrow lib-head__eyebrow">The library</div>
          <h1>Mechanics library</h1>
          <p>The building blocks behind the apps and games people keep coming back to. Each mechanic comes with its psychology, the players it fits, and real examples from the library.</p>
        </div>
      </section>

      <div className="container">
        <div className="lib-layout">
          <aside className="lib-filters">
            <form className="filters" onSubmit={(e) => e.preventDefault()} aria-label="Filter mechanics">
              <div className="filters__head">
                <span className="filters__title">Filters</span>
                <button type="button" className="filters__clear" onClick={clearAll} disabled={!active}>Clear all</button>
              </div>

              <Input
                aria-label="Search mechanics"
                placeholder="Search mechanics"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                leadingIcon={SearchIcon}
              />

              <div className="fgroup" role="group" aria-label="Category">
                <span className="fgroup__label">Category</span>
                <FilterRow active={category === "all"} dot="var(--ink-400)" label="All" onClick={() => setCategory("all")} />
                {Object.entries(CATS).map(([key, c]) => (
                  <FilterRow key={key} active={category === key} dot={c.color} label={c.label} onClick={() => pickCategory(key)} />
                ))}
              </div>

              <div className="fgroup" role="group" aria-label="Product context">
                <span className="fgroup__label">Product context</span>
                {CONTEXTS.map((t) => (
                  <FilterRow key={t} active={contexts.includes(t)} label={fmt(t)} onClick={() => toggle(contexts, setContexts, t)} />
                ))}
              </div>

              <div className="fgroup" role="group" aria-label="User type">
                <span className="fgroup__label">User type</span>
                {Object.entries(USER_TYPES).map(([key, u]) => (
                  <FilterRow key={key} active={users.includes(key)} dot={u.color} label={u.label} onClick={() => toggle(users, setUsers, key)} />
                ))}
              </div>
            </form>
          </aside>

          <section aria-label="Mechanics">
            <div className="lib-resultbar">
              <span className="lib-resultbar__count"><b>{results.length}</b> of {MECHANICS.length} mechanics</span>
              {active ? (
                <button type="button" className="filters__clear" onClick={clearAll}>Reset filters</button>
              ) : (
                <span className="lib-resultbar__hint">Updated weekly</span>
              )}
            </div>

            {results.length ? (
              <div className="lib-grid">
                {results.map((m) => <MechanicLibCard key={m.n} m={m} />)}
              </div>
            ) : (
              <div className="lib-empty">No mechanics match those filters. Try removing one.</div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}

Object.assign(GBSite, { MechanicsPage });
})();
